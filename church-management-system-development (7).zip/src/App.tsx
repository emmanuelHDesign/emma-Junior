import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./lib/auth";
import { Layout } from "./components/Layout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Members from "./pages/Members";
import Presence from "./pages/Presence";
import Cells from "./pages/Cells";
import Tithes from "./pages/Tithes";
import Events from "./pages/Events";
import Communication from "./pages/Communication";
import Departments from "./pages/Departments";
import ScanQR from "./pages/ScanQR";
import AutoScan from "./pages/AutoScan";
import PublicScan from "./pages/PublicScan";
import Installer from "./pages/Installer";
import DimeMobile from "./pages/DimeMobile";
import CellulesQuartiers from "./pages/CellulesQuartiers";
import Live from "./pages/Live";
import Annuaire from "./pages/Annuaire";
import ProfilAnnuaire from "./pages/ProfilAnnuaire";
import Medias from "./pages/Medias";
import Priere from "./pages/Priere";
import EsaieIA from "./pages/EsaieIA";
import Profile from "./pages/Profile";
import Notifications from "./pages/Notifications";
import UsersAdmin from "./pages/UsersAdmin";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  return <Layout>{children}</Layout>;
}

function AppRoutes() {
  return (
    <Routes>
      {/* Routes publiques (sans authentification) */}
      <Route path="/login" element={<Login />} />
      <Route path="/public-scan" element={<PublicScan />} />
      <Route path="/installer" element={<Installer />} />

      {/* Routes protégées */}
      <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/dime-mobile" element={<ProtectedRoute><DimeMobile /></ProtectedRoute>} />
      <Route path="/cellules-quartiers" element={<ProtectedRoute><CellulesQuartiers /></ProtectedRoute>} />
      <Route path="/live" element={<ProtectedRoute><Live /></ProtectedRoute>} />
      <Route path="/membres" element={<ProtectedRoute><Members /></ProtectedRoute>} />
      <Route path="/presence" element={<ProtectedRoute><Presence /></ProtectedRoute>} />
      <Route path="/cellules" element={<ProtectedRoute><Cells /></ProtectedRoute>} />
      <Route path="/dimes" element={<ProtectedRoute><Tithes /></ProtectedRoute>} />
      <Route path="/evenements" element={<ProtectedRoute><Events /></ProtectedRoute>} />
      <Route path="/communication" element={<ProtectedRoute><Communication /></ProtectedRoute>} />
      <Route path="/departements" element={<ProtectedRoute><Departments /></ProtectedRoute>} />
      <Route path="/scan" element={<ProtectedRoute><ScanQR /></ProtectedRoute>} />
      <Route path="/auto-scan" element={<ProtectedRoute><AutoScan /></ProtectedRoute>} />
      <Route path="/annuaire" element={<ProtectedRoute><Annuaire /></ProtectedRoute>} />
      <Route path="/mon-annuaire" element={<ProtectedRoute><ProfilAnnuaire /></ProtectedRoute>} />
      <Route path="/medias" element={<ProtectedRoute><Medias /></ProtectedRoute>} />
      <Route path="/priere" element={<ProtectedRoute><Priere /></ProtectedRoute>} />
      <Route path="/ia" element={<ProtectedRoute><EsaieIA /></ProtectedRoute>} />
      <Route path="/profil" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
      <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
      <Route path="/utilisateurs" element={<ProtectedRoute><UsersAdmin /></ProtectedRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
