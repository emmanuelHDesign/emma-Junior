import { useState } from "react";
import { useAuth } from "../lib/auth";
import { loadDB, saveDB } from "../lib/data";
import { Card, Button, Badge } from "../components/ui";
import { Bell, CheckCheck, Info, AlertTriangle, CheckCircle, Calendar, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";

export default function Notifications() {
  const { user } = useAuth();
  const [db, setDB] = useState(loadDB());
  const [filter, setFilter] = useState<"all" | "unread">("all");

  const myNotifications = db.notifications.filter(n => !n.userId || n.userId === user?.id);
  const filtered = filter === "unread" ? myNotifications.filter(n => !n.lu) : myNotifications;

  const markAsRead = (id: string) => {
    const newDB = { ...db, notifications: db.notifications.map(n => n.id === id ? { ...n, lu: true } : n) };
    saveDB(newDB);
    setDB(newDB);
  };

  const markAllAsRead = () => {
    const newDB = { ...db, notifications: db.notifications.map(n => (!n.userId || n.userId === user?.id) ? { ...n, lu: true } : n) };
    saveDB(newDB);
    setDB(newDB);
  };

  const deleteNotif = (id: string) => {
    const newDB = { ...db, notifications: db.notifications.filter(n => n.id !== id) };
    saveDB(newDB);
    setDB(newDB);
  };

  const iconForType = (type: string) => {
    switch (type) {
      case "success": return <CheckCircle size={20} className="text-green-600" />;
      case "warning": return <AlertTriangle size={20} className="text-amber-600" />;
      case "alert": return <AlertTriangle size={20} className="text-red-600" />;
      case "rappel": return <Calendar size={20} className="text-mdc-blue" />;
      default: return <Info size={20} className="text-blue-600" />;
    }
  };

  const colorForType = (type: string) => {
    switch (type) {
      case "success": return "green";
      case "warning": return "gold";
      case "alert": return "red";
      case "rappel": return "blue";
      default: return "blue";
    }
  };

  const unreadCount = myNotifications.filter(n => !n.lu).length;

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Bell className="text-mdc-gold" /> Notifications
            {unreadCount > 0 && (
              <Badge color="red">{unreadCount} non lue{unreadCount > 1 ? "s" : ""}</Badge>
            )}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {myNotifications.length} notification{myNotifications.length > 1 ? "s" : ""} au total
          </p>
        </div>
        {unreadCount > 0 && (
          <Button variant="secondary" onClick={markAllAsRead}>
            <CheckCheck size={14} /> Tout marquer comme lu
          </Button>
        )}
      </div>

      {/* Filtres */}
      <div className="flex gap-2">
        <button
          onClick={() => setFilter("all")}
          className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
            filter === "all" ? "bg-mdc-blue text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
          }`}
        >
          Toutes ({myNotifications.length})
        </button>
        <button
          onClick={() => setFilter("unread")}
          className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
            filter === "unread" ? "bg-mdc-blue text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
          }`}
        >
          Non lues ({unreadCount})
        </button>
      </div>

      {/* Liste */}
      <div className="space-y-2">
        {filtered.length === 0 ? (
          <Card className="p-10 text-center">
            <Bell size={40} className="mx-auto text-slate-300 mb-2" />
            <p className="text-slate-500">
              {filter === "unread" ? "Aucune notification non lue." : "Aucune notification."}
            </p>
          </Card>
        ) : (
          filtered.map((n) => (
            <Card
              key={n.id}
              className={`p-4 transition ${!n.lu ? "border-l-4 border-l-mdc-gold" : "opacity-75"}`}
            >
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 mt-0.5">{iconForType(n.type)}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                      {n.titre}
                    </h3>
                    <Badge color={colorForType(n.type) as "green" | "gold" | "red" | "blue"}>{n.type}</Badge>
                  </div>
                  <p className="text-sm text-slate-600 dark:text-slate-400">{n.message}</p>
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-xs text-slate-400">
                      {new Date(n.date).toLocaleString("fr-FR")}
                    </p>
                    <div className="flex gap-2">
                      {n.lien && (
                        <Link to={n.lien} className="text-xs text-mdc-blue hover:underline" onClick={() => markAsRead(n.id)}>
                          Voir →
                        </Link>
                      )}
                      {!n.lu && (
                        <button onClick={() => markAsRead(n.id)} className="text-xs text-slate-500 hover:text-mdc-blue">
                          Marquer comme lu
                        </button>
                      )}
                      <button onClick={() => deleteNotif(n.id)} className="text-xs text-red-500 hover:text-red-700">
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
