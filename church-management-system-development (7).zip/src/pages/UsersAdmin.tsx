import { useState } from "react";
import { useAuth } from "../lib/auth";
import { loadDB, saveDB, type User, type Role } from "../lib/data";
import { Card, Button, Badge, Input, Select, Label, Modal } from "../components/ui";
import { Users, Lock, UserCheck, UserX, Edit2, Shield, History, Search } from "lucide-react";

const ROLES: Role[] = ["ADMIN", "PASTEUR", "SECRETAIRE", "CHEF_CELLULE", "MEMBRE"];

export default function UsersAdmin() {
  const { hasPermission } = useAuth();
  const [db, setDB] = useState(loadDB());
  const [search, setSearch] = useState("");
  const [filterRole, setFilterRole] = useState<string>("");
  const [edit, setEdit] = useState<User | null>(null);
  const [showHistory, setShowHistory] = useState(false);

  if (!hasPermission("gerer_utilisateurs")) {
    return (
      <Card className="p-10 text-center">
        <Lock size={40} className="mx-auto text-slate-400 mb-3" />
        <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">Accès restreint</h2>
        <p className="text-sm text-slate-500 mt-2">
          La gestion des utilisateurs est réservée à l'administrateur.
        </p>
      </Card>
    );
  }

  let users = db.users;
  if (search) {
    const s = search.toLowerCase();
    users = users.filter(u => `${u.nom} ${u.email}`.toLowerCase().includes(s));
  }
  if (filterRole) {
    users = users.filter(u => u.role === filterRole);
  }

  const toggleActif = (id: string) => {
    const newDB = { ...db, users: db.users.map(u => u.id === id ? { ...u, actif: !u.actif } : u) };
    saveDB(newDB);
    setDB(newDB);
  };

  const updateUser = (updated: User) => {
    const newDB = { ...db, users: db.users.map(u => u.id === updated.id ? updated : u) };
    saveDB(newDB);
    setDB(newDB);
    setEdit(null);
  };

  const resetPassword = (id: string) => {
    if (!confirm("Réinitialiser le mot de passe à 'demo123' ?")) return;
    const newDB = { ...db, users: db.users.map(u => u.id === id ? { ...u, password: "demo123" } : u) };
    saveDB(newDB);
    setDB(newDB);
    alert("Mot de passe réinitialisé à : demo123");
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Users className="text-mdc-gold" /> Gestion des utilisateurs
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {db.users.length} compte{db.users.length > 1 ? "s" : ""} · {db.users.filter(u => u.actif).length} actif{db.users.filter(u => u.actif).length > 1 ? "s" : ""}
          </p>
        </div>
        <Button variant="secondary" onClick={() => setShowHistory(true)}>
          <History size={16} /> Historique global
        </Button>
      </div>

      <Card className="p-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
            <Input
              placeholder="Rechercher par nom ou email..."
              className="pl-9"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select value={filterRole} onChange={(e) => setFilterRole(e.target.value)} className="sm:w-48">
            <option value="">Tous les rôles</option>
            {ROLES.map(r => <option key={r}>{r}</option>)}
          </Select>
        </div>
      </Card>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs uppercase text-slate-500">
              <tr>
                <th className="text-left px-4 py-3">Utilisateur</th>
                <th className="text-left px-4 py-3 hidden md:table-cell">Rôle</th>
                <th className="text-left px-4 py-3 hidden lg:table-cell">2FA</th>
                <th className="text-left px-4 py-3 hidden lg:table-cell">Dernière connexion</th>
                <th className="text-left px-4 py-3">Statut</th>
                <th className="text-right px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {users.map(u => {
                const initials = u.nom.split(" ").map(n => n[0]).slice(0, 2).join("").toUpperCase();
                return (
                  <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-mdc-blue to-mdc-blue-dark text-white flex items-center justify-center text-xs font-bold">
                          {initials}
                        </div>
                        <div>
                          <p className="font-medium text-slate-900 dark:text-slate-100">{u.nom}</p>
                          <p className="text-xs text-slate-500">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <Badge color={u.role === "PASTEUR" || u.role === "ADMIN" ? "gold" : "blue"}>{u.role}</Badge>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      {u.deuxFacteurs ? <Badge color="green">Activé</Badge> : <Badge color="slate">Désactivé</Badge>}
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell text-xs text-slate-500">
                      {u.derniereConnexion ? new Date(u.derniereConnexion).toLocaleString("fr-FR") : "Jamais"}
                    </td>
                    <td className="px-4 py-3">
                      {u.actif ? <Badge color="green">Actif</Badge> : <Badge color="red">Désactivé</Badge>}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => setEdit(u)} className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800" title="Modifier">
                          <Edit2 size={14} />
                        </button>
                        <button onClick={() => resetPassword(u.id)} className="p-1.5 rounded hover:bg-amber-50 dark:hover:bg-amber-900/20 text-amber-600" title="Réinitialiser mot de passe">
                          <Lock size={14} />
                        </button>
                        <button
                          onClick={() => toggleActif(u.id)}
                          className={`p-1.5 rounded ${u.actif ? "hover:bg-red-50 text-red-600" : "hover:bg-green-50 text-green-600"}`}
                          title={u.actif ? "Désactiver" : "Activer"}
                        >
                          {u.actif ? <UserX size={14} /> : <UserCheck size={14} />}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {edit && <EditUserModal user={edit} onSave={updateUser} onClose={() => setEdit(null)} />}

      {showHistory && (
        <Modal open onClose={() => setShowHistory(false)} title="Historique global de connexion" maxWidth="lg">
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {db.loginHistory.length === 0 ? (
              <p className="text-center text-slate-500 py-6">Aucun historique de connexion.</p>
            ) : (
              db.loginHistory.slice(0, 50).map(h => {
                const user = db.users.find(u => u.id === h.userId);
                return (
                  <div key={h.id} className="flex items-center justify-between p-2 rounded border border-slate-100 dark:border-slate-800 text-sm">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${h.success ? "bg-green-500" : "bg-red-500"}`} />
                      <div>
                        <p className="font-medium text-slate-900 dark:text-slate-100">
                          {user?.nom || "Utilisateur inconnu"}
                        </p>
                        <p className="text-xs text-slate-500">{h.device} · {h.success ? "Réussi" : "Échec"}</p>
                      </div>
                    </div>
                    <span className="text-xs text-slate-500">{new Date(h.date).toLocaleString("fr-FR")}</span>
                  </div>
                );
              })
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}

function EditUserModal({ user, onSave, onClose }: { user: User; onSave: (u: User) => void; onClose: () => void }) {
  const [edited, setEdited] = useState(user);

  return (
    <Modal open onClose={onClose} title={`Modifier ${user.nom}`}>
      <div className="space-y-3">
        <div><Label>Nom complet</Label><Input value={edited.nom} onChange={(e) => setEdited({ ...edited, nom: e.target.value })} /></div>
        <div><Label>Email</Label><Input type="email" value={edited.email} onChange={(e) => setEdited({ ...edited, email: e.target.value })} /></div>
        <div><Label>Téléphone</Label><Input value={edited.telephone || ""} onChange={(e) => setEdited({ ...edited, telephone: e.target.value })} /></div>
        <div>
          <Label>Rôle</Label>
          <Select value={edited.role} onChange={(e) => setEdited({ ...edited, role: e.target.value as Role })}>
            {ROLES.map(r => <option key={r}>{r}</option>)}
          </Select>
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={edited.deuxFacteurs} onChange={(e) => setEdited({ ...edited, deuxFacteurs: e.target.checked })} />
          Activer l'authentification 2FA
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={edited.actif} onChange={(e) => setEdited({ ...edited, actif: e.target.checked })} />
          Compte actif
        </label>
      </div>
      <div className="flex justify-end gap-2 mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
        <Button variant="ghost" onClick={onClose}>Annuler</Button>
        <Button onClick={() => onSave(edited)}><Shield size={14} /> Enregistrer</Button>
      </div>
    </Modal>
  );
}
