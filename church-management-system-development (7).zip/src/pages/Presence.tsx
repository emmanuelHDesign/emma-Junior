import { useMemo, useState } from "react";
import { loadDB, saveDB, uid } from "../lib/data";
import { useAuth } from "../lib/auth";
import { Card, Button, Select, Badge, Input, Label } from "../components/ui";
import { QRCodeSVG } from "qrcode.react";
import { QrCode, Check, Users, Calendar, Smartphone, Clock, Grid } from "lucide-react";
import { format } from "date-fns";
import type { DB } from "../lib/data";

export default function Presence() {
  const { hasPermission } = useAuth();
  const [db, setDB] = useState(loadDB());
  const today = format(new Date(), "yyyy-MM-dd");
  const [date, setDate] = useState(today);
  const [type, setType] = useState<"Dimanche" | "Étude biblique" | "Prière">("Dimanche");
  const [showQR, setShowQR] = useState(true);
  const [viewMode, setViewMode] = useState<"marquage" | "qr-cards">("marquage");

  const culte = useMemo(() => {
    let c = db.cultes.find((x) => x.date === date && x.type === type);
    if (!c) {
      c = { id: uid("cu"), date, type };
      const newDB = { ...db, cultes: [c, ...db.cultes] };
      saveDB(newDB);
      setDB(newDB);
    }
    return c;
  }, [db, date, type]);

  const presentsIds = useMemo(
    () => new Set(db.presences.filter((p) => p.culteId === culte.id).map((p) => p.membreId)),
    [db, culte]
  );

  const toggle = (membreId: string) => {
    const exists = db.presences.find((p) => p.culteId === culte.id && p.membreId === membreId);
    let presences;
    if (exists) {
      presences = db.presences.filter((p) => p.id !== exists.id);
    } else {
      const heure = new Date().toTimeString().slice(0, 8);
      presences = [...db.presences, {
        id: uid("p"), membreId, type, date, culteId: culte.id,
        heureArrivee: heure, methode: "manuelle" as const,
      }];
    }
    const newDB = { ...db, presences };
    saveDB(newDB);
    setDB(newDB);
  };

  const markAll = () => {
    const heure = new Date().toTimeString().slice(0, 8);
    const newPres = db.membres.filter((m) => !m.archived && !presentsIds.has(m.id)).map((m) => ({
      id: uid("p"), membreId: m.id, type, date, culteId: culte.id,
      heureArrivee: heure, methode: "manuelle" as const,
    }));
    const newDB = { ...db, presences: [...db.presences, ...newPres] };
    saveDB(newDB);
    setDB(newDB);
  };

  const clearAll = () => {
    if (!confirm("Effacer toutes les présences de ce culte ?")) return;
    const newDB = { ...db, presences: db.presences.filter((p) => p.culteId !== culte.id) };
    saveDB(newDB);
    setDB(newDB);
  };

  // QR code PUBLIC : n'importe qui peut scanner sans être connecté
  const qrValue = `${window.location.origin}/public-scan?c=${culte.id}`;
  const taux = db.membres.length > 0
    ? Math.round((presentsIds.size / db.membres.filter((m) => !m.archived).length) * 100) : 0;

  // Stats par membre
  const statsMembres = db.membres.filter((m) => !m.archived).map((m) => {
    const total = db.presences.filter((p) => p.membreId === m.id).length;
    return { membre: m, total };
  }).sort((a, b) => b.total - a.total);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <QrCode className="text-mdc-gold" /> Marquage de présence
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          3 clics max pour enregistrer la présence au culte
        </p>
      </div>

      {/* Contrôles */}
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <div>
            <Label>Date</Label>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
          <div>
            <Label>Type de culte</Label>
            <Select value={type} onChange={(e) => setType(e.target.value as typeof type)}>
              <option value="Dimanche">Dimanche matin</option>
              <option value="Étude biblique">Étude biblique</option>
              <option value="Prière">Soirée de prière</option>
            </Select>
          </div>
          <div>
            <Label>Présents</Label>
            <div className="flex items-center gap-2 h-10">
              <Badge color="blue">{presentsIds.size} / {db.membres.filter((m) => !m.archived).length}</Badge>
              <Badge color="gold">{taux}%</Badge>
            </div>
          </div>
          <div className="md:col-span-2 flex items-end gap-2">
            <Button 
              variant={viewMode === "marquage" ? "primary" : "secondary"} 
              onClick={() => setViewMode("marquage")}
              className="flex-1"
            >
              <Users size={16} /> Marquage
            </Button>
            <Button 
              variant={viewMode === "qr-cards" ? "primary" : "secondary"} 
              onClick={() => setViewMode("qr-cards")}
              className="flex-1"
            >
              <Grid size={16} /> QR Membres
            </Button>
          </div>
        </div>
      </Card>

      {viewMode === "marquage" && (
        <div className="flex flex-wrap gap-2 justify-end">
          <Button variant="secondary" onClick={markAll}><Check size={16} /> Tout cocher</Button>
          <Button variant="ghost" onClick={clearAll}>Effacer</Button>
        </div>
      )}

      {viewMode === "marquage" && (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* QR Code global */}
        <Card className="p-5 lg:col-span-1">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Smartphone size={16} /> QR Code général
            </h3>
            <button onClick={() => setShowQR((s) => !s)} className="text-xs text-mdc-blue">
              {showQR ? "Masquer" : "Afficher"}
            </button>
          </div>
          {showQR && (
            <div className="bg-white p-4 rounded-lg flex flex-col items-center">
              <QRCodeSVG value={qrValue} size={200} level="M" includeMargin fgColor="#1E3A8A" bgColor="#ffffff" />
              <p className="mt-3 text-xs text-slate-600 text-center font-medium">
                ✅ QR PUBLIC — Aucune connexion requise
              </p>
              <p className="text-xs text-slate-500 text-center mt-1">
                N'importe qui peut scanner et s'enregistrer
              </p>
            </div>
          )}
          <div className="mt-4 p-3 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
            <p className="text-xs text-green-800 dark:text-green-200">
              <strong>📱 Mode public :</strong> Imprimez ce QR et affichez-le à l'entrée du temple. Chaque personne scanne et choisit son nom dans la liste (ou s'inscrit comme visiteur).
            </p>
          </div>
        </Card>

        {/* Liste manuelle avec heures d'arrivée */}
        <Card className="p-0 lg:col-span-2 overflow-hidden">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Users size={16} /> Liste manuelle
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Cochez rapidement les membres présents</p>
          </div>
          <div className="max-h-[500px] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {db.membres.filter((m) => !m.archived).map((m) => {
              const presence = db.presences.find((p) => p.culteId === culte.id && p.membreId === m.id);
              const present = !!presence;
              const cel = db.cellules.find((c) => c.id === m.celluleId);
              return (
                <button
                  key={m.id}
                  onClick={() => toggle(m.id)}
                  className={`w-full flex items-center gap-3 p-3 text-left transition ${
                    present ? "bg-green-50 dark:bg-green-900/20" : "hover:bg-slate-50 dark:hover:bg-slate-800/30"
                  }`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${
                    present
                      ? "bg-green-500 text-white"
                      : "bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300"
                  }`}>
                    {present ? <Check size={18} /> : `${m.prenom[0]}${m.nom[0]}`}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-slate-900 dark:text-slate-100 truncate">{m.prenom} {m.nom}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{cel?.nom || "Sans cellule"}</p>
                  </div>
                  {present && presence?.heureArrivee && (
                    <div className="flex flex-col items-end">
                      <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-mdc-gold/20 text-mdc-gold-dark dark:text-mdc-gold text-xs font-mono font-bold">
                        <Clock size={10} />
                        {presence.heureArrivee.slice(0, 5)}
                      </div>
                      <span className="text-[10px] text-slate-400 mt-0.5">
                        {presence.methode === "self_scan" ? "📱 Scan" : presence.methode === "qr_code" ? "QR" : "Manuel"}
                      </span>
                    </div>
                  )}
                  {!present && (
                    <Badge color={m.statut === "Engagé" ? "gold" : m.statut === "Baptisé" ? "blue" : "green"}>
                      {m.statut}
                    </Badge>
                  )}
                </button>
              );
            })}
          </div>
        </Card>
      </div>
      )}

      {viewMode === "qr-cards" && (
        <QRCardsView db={db} culteId={culte.id} />
      )}

      {/* Stats mensuelles */}
      {hasPermission("voir_dashboard_pasteur") && (
        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-4 flex items-center gap-2">
            <Calendar size={16} /> Top présence mensuelle
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {statsMembres.slice(0, 10).map((s, i) => (
              <div key={s.membre.id} className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-mdc-blue text-white flex items-center justify-center text-xs font-bold">
                    {i + 1}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">{s.membre.prenom} {s.membre.nom}</p>
                    <p className="text-xs text-slate-500">{s.total} culte(s)</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

// ============================
// QR CARDS VIEW (cartes imprimables)
// ============================

function QRCardsView({ db, culteId }: { db: DB; culteId: string }) {
  const membresActifs = db.membres.filter((m) => !m.archived);
  const [searchQ, setSearchQ] = useState("");

  const filtered = searchQ
    ? membresActifs.filter((m) =>
        `${m.nom} ${m.prenom} ${m.telephone}`.toLowerCase().includes(searchQ.toLowerCase())
      )
    : membresActifs;

  const handlePrint = () => {
    window.print();
  };

  return (
    <Card className="p-5">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
        <div>
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Grid size={16} /> Cartes QR des membres
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Chaque carte pré-sélectionne le membre. Scannez pour enregistrer directement (sans connexion).
          </p>
        </div>
        <div className="flex gap-2">
          <Input
            placeholder="Rechercher un membre..."
            value={searchQ}
            onChange={(e) => setSearchQ(e.target.value)}
            className="max-w-xs"
          />
          <Button variant="secondary" onClick={handlePrint}>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
            </svg>
            Imprimer
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 print:grid-cols-3 print:gap-2">
        {filtered.map((m) => {
          // QR individuel pré-sélectionne le membre (sans auth requise)
          const qrValue = `${window.location.origin}/public-scan?c=${culteId}&m=${m.id}`;
          const initials = `${m.prenom[0] || ""}${m.nom[0] || ""}`.toUpperCase();
          return (
            <div
              key={m.id}
              className="border-2 border-slate-200 dark:border-slate-700 rounded-lg p-3 bg-white text-slate-900 print:border-slate-400"
            >
              <div className="flex items-center gap-2 mb-2 pb-2 border-b border-slate-200">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-mdc-blue to-mdc-blue-dark text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                  {initials}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold truncate">{m.prenom} {m.nom}</p>
                  <p className="text-[10px] text-slate-500 truncate">{m.telephone}</p>
                </div>
              </div>
              <div className="bg-white p-2 rounded flex justify-center">
                <QRCodeSVG
                  value={qrValue}
                  size={120}
                  level="M"
                  fgColor="#1E3A8A"
                  bgColor="#ffffff"
                  includeMargin={false}
                />
              </div>
              <p className="text-[9px] text-center text-slate-500 mt-1 font-mono">
                MDC • {m.id.slice(-6).toUpperCase()}
              </p>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <p className="text-center text-slate-500 py-8">Aucun membre trouvé</p>
      )}

      <div className="mt-6 p-4 rounded-lg bg-gradient-to-br from-blue-50 to-amber-50 dark:from-blue-900/20 dark:to-amber-900/20 border border-blue-200 dark:border-blue-800 print:hidden">
        <h4 className="font-semibold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-2">
          📱 Comment utiliser les QR codes ?
        </h4>
        <ol className="text-sm text-slate-700 dark:text-slate-300 space-y-1 list-decimal list-inside">
          <li>Imprimez cette page (bouton "Imprimer")</li>
          <li>Découpez les cartes et distribuez-les aux membres</li>
          <li>Chaque membre conserve sa carte (format carte de visite)</li>
          <li>À l'arrivée au culte, le membre scanne son propre QR avec son téléphone</li>
          <li>Sa présence est enregistrée <strong>automatiquement</strong> avec l'heure d'arrivée</li>
          <li>Alternative : la secrétaire peut scanner le QR du membre avec une tablette</li>
        </ol>
        <p className="text-xs text-slate-500 mt-2">
          <strong>Note :</strong> Le membre doit être connecté à l'application pour que le scan fonctionne (sécurité).
        </p>
      </div>
    </Card>
  );
}
