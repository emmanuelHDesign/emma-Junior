import { useMemo, useState } from "react";
import { loadDB, saveDB, uid, type Membre, type StatutSpirituel } from "../lib/data";
import { useAuth } from "../lib/auth";
import { Card, Button, Input, Label, Select, Badge, Modal, Textarea } from "../components/ui";
import { Plus, Search, Download, Upload, Edit2, Archive, Filter, Phone, Mail } from "lucide-react";

const STATUTS: StatutSpirituel[] = ["Nouveau converti", "Baptisé", "Engagé", "Archivé"];
const STATUT_COLOR: Record<StatutSpirituel, "green" | "blue" | "gold" | "red"> = {
  "Nouveau converti": "green",
  "Baptisé": "blue",
  "Engagé": "gold",
  "Archivé": "red",
};

export default function Members() {
  const { user, hasPermission } = useAuth();
  const [db, setDB] = useState(loadDB());
  const [q, setQ] = useState("");
  const [filterStatut, setFilterStatut] = useState<string>("");
  const [filterDep, setFilterDep] = useState<string>("");
  const [filterCell, setFilterCell] = useState<string>("");
  const [showArchived, setShowArchived] = useState(false);
  const [edit, setEdit] = useState<Membre | null>(null);
  const [showAdd, setShowAdd] = useState(false);

  // Restriction chef de cellule : ne voit que ses membres
  const membres = useMemo(() => {
    let list = db.membres;
    if (user?.role === "CHEF_CELLULE") {
      const celluleChef = db.cellules.find((c) => c.chefId === "m4"); // id mock
      list = list.filter((m) => m.celluleId === celluleChef?.id);
    }
    if (!showArchived) list = list.filter((m) => !m.archived);
    if (q) {
      const s = q.toLowerCase();
      list = list.filter((m) => `${m.nom} ${m.prenom} ${m.telephone}`.toLowerCase().includes(s));
    }
    if (filterStatut) list = list.filter((m) => m.statut === filterStatut);
    if (filterDep) list = list.filter((m) => m.departementId === filterDep);
    if (filterCell) list = list.filter((m) => m.celluleId === filterCell);
    return list;
  }, [db, q, filterStatut, filterDep, filterCell, showArchived, user]);

  const save = (membres: Membre[]) => {
    const newDB = { ...db, membres };
    saveDB(newDB);
    setDB(newDB);
  };

  const handleSave = (m: Membre) => {
    const exists = db.membres.find((x) => x.id === m.id);
    const next = exists
      ? db.membres.map((x) => (x.id === m.id ? m : x))
      : [...db.membres, { ...m, id: uid("m") }];
    save(next);
    setEdit(null);
    setShowAdd(false);
  };

  const handleArchive = (id: string) => {
    if (!confirm("Archiver ce membre ? Il ne sera pas supprimé, mais retiré des listes actives.")) return;
    save(db.membres.map((m) => (m.id === id ? { ...m, archived: true, statut: "Archivé" } : m)));
  };

  const handleExport = () => {
    const headers = ["Nom", "Prénom", "Téléphone", "Email", "Statut", "Département", "Cellule", "Date intégration"];
    const rows = membres.map((m) => [
      m.nom, m.prenom, m.telephone, m.email || "",
      m.statut,
      db.departements.find((d) => d.id === m.departementId)?.nom || "",
      db.cellules.find((c) => c.id === m.celluleId)?.nom || "",
      m.dateIntegration,
    ]);
    const csv = [headers, ...rows].map((r) => r.map((x) => `"${x}"`).join(",")).join("\n");
    const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `membres-mdc-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      const lines = text.split("\n").filter((l) => l.trim());
      const imported: Membre[] = lines.slice(1).map((line) => {
        const cols = line.split(",").map((c) => c.replace(/^"|"$/g, "").trim());
        return {
          id: uid("m"),
          nom: cols[0] || "",
          prenom: cols[1] || "",
          telephone: cols[2] || "",
          email: cols[3],
          statut: (cols[4] as StatutSpirituel) || "Nouveau converti",
          dateIntegration: cols[7] || new Date().toISOString().slice(0, 10),
          consentementPhoto: true,
          consentementSMS: true,
          archived: false,
        };
      });
      save([...db.membres, ...imported]);
      alert(`${imported.length} membre(s) importé(s).`);
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const canEdit = hasPermission("gerer_membres");

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
            Membres {user?.role === "CHEF_CELLULE" && <span className="text-base font-normal text-slate-500">(Ma cellule)</span>}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {membres.length} membre(s) · {db.membres.filter((m) => m.archived).length} archivé(s)
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" onClick={handleExport}><Download size={16} /> Export</Button>
          {canEdit && (
            <>
              <label className="inline-flex">
                <input type="file" accept=".csv" onChange={handleImport} className="hidden" />
                <span className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer">
                  <Upload size={16} /> Import
                </span>
              </label>
              <Button onClick={() => setShowAdd(true)}><Plus size={16} /> Nouveau membre</Button>
            </>
          )}
        </div>
      </div>

      {/* Filtres */}
      <Card className="p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="relative sm:col-span-2">
            <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
            <Input placeholder="Rechercher nom, prénom, téléphone..." className="pl-9" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <Select value={filterStatut} onChange={(e) => setFilterStatut(e.target.value)}>
            <option value="">Tous statuts</option>
            {STATUTS.map((s) => <option key={s} value={s}>{s}</option>)}
          </Select>
          <Select value={filterDep} onChange={(e) => setFilterDep(e.target.value)}>
            <option value="">Tous départements</option>
            {db.departements.map((d) => <option key={d.id} value={d.id}>{d.nom}</option>)}
          </Select>
          <Select value={filterCell} onChange={(e) => setFilterCell(e.target.value)}>
            <option value="">Toutes cellules</option>
            {db.cellules.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}
          </Select>
        </div>
        <div className="flex items-center gap-3 mt-3">
          <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
            <input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} className="rounded" />
            Afficher archivés
          </label>
          {(filterStatut || filterDep || filterCell) && (
            <button
              onClick={() => { setFilterStatut(""); setFilterDep(""); setFilterCell(""); }}
              className="text-xs text-mdc-blue hover:underline flex items-center gap-1"
            >
              <Filter size={12} /> Effacer filtres
            </button>
          )}
        </div>
      </Card>

      {/* Table */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs uppercase text-slate-500 dark:text-slate-400">
              <tr>
                <th className="text-left px-4 py-3">Membre</th>
                <th className="text-left px-4 py-3 hidden md:table-cell">Contact</th>
                <th className="text-left px-4 py-3">Statut</th>
                <th className="text-left px-4 py-3 hidden lg:table-cell">Département</th>
                <th className="text-left px-4 py-3 hidden lg:table-cell">Cellule</th>
                <th className="text-right px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {membres.map((m) => {
                const dep = db.departements.find((d) => d.id === m.departementId);
                const cel = db.cellules.find((c) => c.id === m.celluleId);
                const initials = `${m.prenom[0] || ""}${m.nom[0] || ""}`.toUpperCase();
                return (
                  <tr key={m.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-mdc-blue to-mdc-blue-dark text-white flex items-center justify-center text-xs font-bold">
                          {initials}
                        </div>
                        <div>
                          <p className="font-medium text-slate-900 dark:text-slate-100">{m.prenom} {m.nom}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">Depuis {new Date(m.dateIntegration).toLocaleDateString("fr-FR")}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <div className="space-y-0.5 text-xs">
                        <p className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400"><Phone size={11} /> {m.telephone}</p>
                        {m.email && <p className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400"><Mail size={11} /> {m.email}</p>}
                      </div>
                    </td>
                    <td className="px-4 py-3"><Badge color={STATUT_COLOR[m.statut]}>{m.statut}</Badge></td>
                    <td className="px-4 py-3 hidden lg:table-cell text-slate-600 dark:text-slate-400">{dep?.nom || "—"}</td>
                    <td className="px-4 py-3 hidden lg:table-cell text-slate-600 dark:text-slate-400">{cel?.nom || "—"}</td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex justify-end gap-1">
                        {canEdit && (
                          <>
                            <button
                              onClick={() => setEdit(m)}
                              className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
                              title="Modifier"
                            ><Edit2 size={14} /></button>
                            {!m.archived && (
                              <button
                                onClick={() => handleArchive(m.id)}
                                className="p-1.5 rounded hover:bg-red-50 dark:hover:bg-red-900/20 text-red-600"
                                title="Archiver"
                              ><Archive size={14} /></button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {membres.length === 0 && (
                <tr><td colSpan={6} className="px-4 py-10 text-center text-slate-500 dark:text-slate-400">Aucun membre trouvé.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {(showAdd || edit) && (
        <MembreForm
          initial={edit}
          db={db}
          onClose={() => { setEdit(null); setShowAdd(false); }}
          onSave={handleSave}
        />
      )}
    </div>
  );
}

function MembreForm({ initial, db, onClose, onSave }: {
  initial: Membre | null;
  db: ReturnType<typeof loadDB>;
  onClose: () => void;
  onSave: (m: Membre) => void;
}) {
  const [m, setM] = useState<Membre>(initial ?? {
    id: "", nom: "", prenom: "", telephone: "", email: "",
    statut: "Nouveau converti", dateIntegration: new Date().toISOString().slice(0, 10),
    consentementPhoto: false, consentementSMS: true, archived: false,
  });

  const update = <K extends keyof Membre>(k: K, v: Membre[K]) => setM({ ...m, [k]: v });

  return (
    <Modal open onClose={onClose} title={initial ? "Modifier le membre" : "Nouveau membre"} maxWidth="lg">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div><Label>Prénom *</Label><Input value={m.prenom} onChange={(e) => update("prenom", e.target.value)} required /></div>
        <div><Label>Nom *</Label><Input value={m.nom} onChange={(e) => update("nom", e.target.value)} required /></div>
        <div><Label>Téléphone *</Label><Input value={m.telephone} onChange={(e) => update("telephone", e.target.value)} placeholder="+237 6XX XX XX XX" /></div>
        <div><Label>Email</Label><Input type="email" value={m.email || ""} onChange={(e) => update("email", e.target.value)} /></div>
        <div><Label>Statut spirituel</Label>
          <Select value={m.statut} onChange={(e) => update("statut", e.target.value as StatutSpirituel)}>
            {STATUTS.map((s) => <option key={s}>{s}</option>)}
          </Select>
        </div>
        <div><Label>Date d'intégration</Label><Input type="date" value={m.dateIntegration} onChange={(e) => update("dateIntegration", e.target.value)} /></div>
        <div><Label>Département</Label>
          <Select value={m.departementId || ""} onChange={(e) => update("departementId", e.target.value || undefined)}>
            <option value="">Aucun</option>
            {db.departements.map((d) => <option key={d.id} value={d.id}>{d.nom}</option>)}
          </Select>
        </div>
        <div><Label>Cellule</Label>
          <Select value={m.celluleId || ""} onChange={(e) => update("celluleId", e.target.value || undefined)}>
            <option value="">Aucune</option>
            {db.cellules.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}
          </Select>
        </div>
        <div className="md:col-span-2"><Label>Adresse</Label><Textarea rows={2} value={m.adresse || ""} onChange={(e) => update("adresse", e.target.value)} /></div>

        <div className="md:col-span-2 space-y-2 p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
          <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase">Consentements RGPD</p>
          <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
            <input type="checkbox" checked={m.consentementPhoto} onChange={(e) => update("consentementPhoto", e.target.checked)} />
            J'autorise l'utilisation de ma photo
          </label>
          <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
            <input type="checkbox" checked={m.consentementSMS} onChange={(e) => update("consentementSMS", e.target.checked)} />
            J'autorise l'envoi de SMS/WhatsApp
          </label>
        </div>
      </div>

      <div className="flex justify-end gap-2 mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
        <Button variant="ghost" onClick={onClose}>Annuler</Button>
        <Button onClick={() => {
          if (!m.nom.trim() || !m.prenom.trim() || !m.telephone.trim()) {
            alert("Nom, prénom et téléphone sont obligatoires."); return;
          }
          onSave(m);
        }}>Enregistrer</Button>
      </div>
    </Modal>
  );
}
