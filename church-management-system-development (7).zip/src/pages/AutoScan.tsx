import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { loadDB, saveDB, uid } from "../lib/data";
import { useAuth } from "../lib/auth";
import { Card } from "../components/ui";
import { CheckCircle, AlertCircle, Loader2, Clock } from "lucide-react";

export default function AutoScan() {
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [status, setStatus] = useState<"loading" | "success" | "error" | "already">("loading");
  const [message, setMessage] = useState("");
  const [heureArrivee, setHeureArrivee] = useState("");
  const [membreNom, setMembreNom] = useState("");

  useEffect(() => {
    const culteId = searchParams.get("c");
    const membreId = searchParams.get("m");

    if (!culteId || !membreId) {
      setStatus("error");
      setMessage("QR code invalide (paramètres manquants)");
      return;
    }

    // Vérifier authentification
    if (!user) {
      setStatus("error");
      setMessage("Veuillez vous connecter pour scanner votre présence");
      setTimeout(() => navigate("/login"), 2000);
      return;
    }

    // Enregistrer la présence automatiquement
    const db = loadDB();

    // Trouver le membre
    const membre = db.membres.find((m) => m.id === membreId);
    if (!membre) {
      setStatus("error");
      setMessage("Membre introuvable");
      return;
    }

    // Vérifier que le membre correspond à l'utilisateur (sécurité)
    const userMembre = db.membres.find((m) => {
      if (user.email === "membre@mdc.cm") return m.id === "m1";
      if (user.email === "chef1@mdc.cm") return m.id === "m4";
      if (user.email === "secretaire@mdc.cm") return m.id === "m3";
      return false;
    });

    if (userMembre?.id !== membreId && user.role !== "PASTEUR" && user.role !== "ADMIN") {
      setStatus("error");
      setMessage("Ce QR code ne correspond pas à votre compte");
      return;
    }

    // Vérifier culte existe
    const culte = db.cultes.find((c) => c.id === culteId);
    if (!culte) {
      setStatus("error");
      setMessage("Culte introuvable");
      return;
    }

    // Vérifier si déjà présent
    const dejaPresent = db.presences.find(
      (p) => p.culteId === culteId && p.membreId === membreId
    );

    if (dejaPresent) {
      setStatus("already");
      setHeureArrivee(dejaPresent.heureArrivee || "");
      setMembreNom(`${membre.prenom} ${membre.nom}`);
      setMessage(`Vous êtes déjà enregistré`);
      return;
    }

    // Enregistrer présence
    const maintenant = new Date();
    const heure = maintenant.toTimeString().slice(0, 8);

    const nouvellePresence = {
      id: uid("p"),
      membreId,
      type: culte.type,
      date: culte.date,
      culteId,
      heureArrivee: heure,
      methode: "self_scan" as const,
    };

    const newDB = { ...db, presences: [...db.presences, nouvellePresence] };
    saveDB(newDB);

    setStatus("success");
    setHeureArrivee(heure);
    setMembreNom(`${membre.prenom} ${membre.nom}`);
    setMessage("Présence enregistrée avec succès !");
  }, [searchParams, user, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-mdc-blue via-mdc-blue-dark to-slate-900">
      <Card className="max-w-md w-full p-8 text-center">
        {status === "loading" && (
          <>
            <Loader2 size={64} className="mx-auto text-mdc-blue animate-spin mb-4" />
            <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-2">
              Enregistrement en cours...
            </h2>
            <p className="text-sm text-slate-500">Veuillez patienter</p>
          </>
        )}

        {status === "success" && (
          <>
            <CheckCircle size={64} className="mx-auto text-green-600 mb-4" />
            <h2 className="text-xl font-bold text-green-900 dark:text-green-100 mb-2">
              Bienvenue au culte ! 🙏
            </h2>
            <p className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4">
              {membreNom}
            </p>
            <div className="inline-flex items-center gap-2 px-4 py-3 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 mb-4">
              <Clock size={20} className="text-mdc-gold" />
              <div className="text-left">
                <p className="text-xs text-slate-500">Heure d'arrivée</p>
                <p className="font-mono font-bold text-lg text-slate-900 dark:text-slate-100">
                  {heureArrivee}
                </p>
              </div>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
              Que le Seigneur vous bénisse !
            </p>
            <button
              onClick={() => navigate("/")}
              className="text-sm text-mdc-blue hover:underline"
            >
              Retour à l'accueil →
            </button>
          </>
        )}

        {status === "already" && (
          <>
            <AlertCircle size={64} className="mx-auto text-amber-600 mb-4" />
            <h2 className="text-xl font-bold text-amber-900 dark:text-amber-100 mb-2">
              Déjà enregistré
            </h2>
            <p className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4">
              {membreNom}
            </p>
            <div className="inline-flex items-center gap-2 px-4 py-3 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 mb-4">
              <Clock size={20} className="text-mdc-gold" />
              <div className="text-left">
                <p className="text-xs text-slate-500">Arrivé à</p>
                <p className="font-mono font-bold text-lg text-slate-900 dark:text-slate-100">
                  {heureArrivee}
                </p>
              </div>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
              Votre présence a déjà été enregistrée pour ce culte
            </p>
            <button
              onClick={() => navigate("/")}
              className="text-sm text-mdc-blue hover:underline"
            >
              Retour à l'accueil →
            </button>
          </>
        )}

        {status === "error" && (
          <>
            <AlertCircle size={64} className="mx-auto text-red-600 mb-4" />
            <h2 className="text-xl font-bold text-red-900 dark:text-red-100 mb-2">
              Erreur
            </h2>
            <p className="text-sm text-red-700 dark:text-red-300 mb-4">
              {message}
            </p>
            <button
              onClick={() => navigate("/")}
              className="text-sm text-mdc-blue hover:underline"
            >
              Retour à l'accueil →
            </button>
          </>
        )}
      </Card>
    </div>
  );
}
