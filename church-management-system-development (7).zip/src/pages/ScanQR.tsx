import { useState } from "react";
import { loadDB, saveDB, uid } from "../lib/data";
import { useAuth } from "../lib/auth";
import { Card, Button, Badge } from "../components/ui";
import { QrCode, CheckCircle, Clock, AlertCircle, Camera } from "lucide-react";
import { format } from "date-fns";

export default function ScanQR() {
  const { user } = useAuth();
  const [db, setDB] = useState(loadDB());
  const [scanResult, setScanResult] = useState<"success" | "already" | "error" | null>(null);
  const [heureArrivee, setHeureArrivee] = useState<string>("");

  // Trouver le membre associé à l'utilisateur
  // Mapping par email (en production : user.membre_id FK)
  const membre = db.membres.find((m) => {
    if (user?.email === "membre@mdc.cm") return m.id === "m1";
    if (user?.email === "chef1@mdc.cm") return m.id === "m4";
    if (user?.email === "secretaire@mdc.cm") return m.id === "m3";
    return false;
  }) || db.membres[0];

  // Trouver le culte du jour
  const today = format(new Date(), "yyyy-MM-dd");
  const culteAujourdhui = db.cultes.find((c) => c.date === today && c.type === "Dimanche");

  const simulerScan = () => {
    if (!membre) {
      setScanResult("error");
      return;
    }

    if (!culteAujourdhui) {
      setScanResult("error");
      return;
    }

    // Vérifier si déjà présent
    const dejaPresent = db.presences.find(
      (p) => p.culteId === culteAujourdhui.id && p.membreId === membre.id
    );

    if (dejaPresent) {
      setScanResult("already");
      setHeureArrivee(dejaPresent.heureArrivee || "");
      return;
    }

    // Enregistrer la présence avec heure d'arrivée
    const maintenant = new Date();
    const heure = maintenant.toTimeString().slice(0, 8); // HH:MM:SS

    const nouvellePresence = {
      id: uid("p"),
      membreId: membre.id,
      type: culteAujourdhui.type,
      date: today,
      culteId: culteAujourdhui.id,
      heureArrivee: heure,
      methode: "self_scan" as const,
    };

    const newDB = { ...db, presences: [...db.presences, nouvellePresence] };
    saveDB(newDB);
    setDB(newDB);
    setHeureArrivee(heure);
    setScanResult("success");
  };

  const reset = () => {
    setScanResult(null);
    setHeureArrivee("");
  };

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Camera className="text-mdc-gold" /> Scanner ma présence
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Scannez le QR code du culte pour marquer votre arrivée
        </p>
      </div>

      {!scanResult && (
        <>
          <Card className="p-8 text-center">
            <div className="w-32 h-32 mx-auto mb-4 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
              <Camera size={64} className="text-slate-400" />
            </div>
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-2">
              Caméra prête
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
              Pointez votre caméra vers le QR code affiché au temple
            </p>
            <Button onClick={simulerScan} className="w-full py-3 text-base">
              <QrCode size={18} /> Simuler le scan (démo)
            </Button>
            <p className="text-xs text-slate-400 mt-3">
              En production : la caméra du téléphone scanne automatiquement le QR code
            </p>
          </Card>

          <Card className="p-5">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-3">
              Informations du culte
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">Date</span>
                <span className="font-medium text-slate-900 dark:text-slate-100">
                  {new Date(today).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Type</span>
                <Badge color="blue">{culteAujourdhui?.type || "Aucun culte"}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Votre profil</span>
                <span className="font-medium text-slate-900 dark:text-slate-100">
                  {membre ? `${membre.prenom} ${membre.nom}` : "Non trouvé"}
                </span>
              </div>
            </div>
          </Card>
        </>
      )}

      {scanResult === "success" && (
        <Card className="p-8 text-center bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
          <CheckCircle size={64} className="mx-auto text-green-600 mb-4" />
          <h3 className="text-xl font-bold text-green-900 dark:text-green-100 mb-2">
            Présence enregistrée !
          </h3>
          <p className="text-sm text-green-700 dark:text-green-300 mb-4">
            Bienvenue au culte, {membre?.prenom} 🙏
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white dark:bg-slate-900 shadow">
            <Clock size={16} className="text-mdc-gold" />
            <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
              {heureArrivee}
            </span>
          </div>
          <Button onClick={reset} variant="secondary" className="mt-6">
            Scanner à nouveau
          </Button>
        </Card>
      )}

      {scanResult === "already" && (
        <Card className="p-8 text-center bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800">
          <AlertCircle size={64} className="mx-auto text-amber-600 mb-4" />
          <h3 className="text-xl font-bold text-amber-900 dark:text-amber-100 mb-2">
            Déjà enregistré
          </h3>
          <p className="text-sm text-amber-700 dark:text-amber-300 mb-4">
            Vous avez déjà scanné votre présence pour ce culte
          </p>
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white dark:bg-slate-900 shadow">
            <Clock size={16} className="text-mdc-gold" />
            <span className="text-sm text-slate-600 dark:text-slate-400">Arrivé à :</span>
            <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
              {heureArrivee}
            </span>
          </div>
          <Button onClick={reset} variant="secondary" className="mt-6">
            Retour
          </Button>
        </Card>
      )}

      {scanResult === "error" && (
        <Card className="p-8 text-center bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
          <AlertCircle size={64} className="mx-auto text-red-600 mb-4" />
          <h3 className="text-xl font-bold text-red-900 dark:text-red-100 mb-2">
            Erreur
          </h3>
          <p className="text-sm text-red-700 dark:text-red-300 mb-4">
            {!membre
              ? "Votre profil n'est pas lié à votre compte utilisateur"
              : !culteAujourdhui
              ? "Aucun culte programmé aujourd'hui"
              : "Erreur lors de l'enregistrement"}
          </p>
          <Button onClick={reset} variant="secondary" className="mt-6">
            Réessayer
          </Button>
        </Card>
      )}

      <Card className="p-5 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
        <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
          💡 Comment ça marche ?
        </h3>
        <ol className="text-sm text-blue-800 dark:text-blue-200 space-y-1 list-decimal list-inside">
          <li>Le QR code est affiché à l'entrée du temple</li>
          <li>Ouvrez cette page sur votre téléphone</li>
          <li>Pointez la caméra vers le QR code</li>
          <li>Votre présence est enregistrée avec l'heure d'arrivée</li>
          <li>Le Pasteur voit en temps réel qui est arrivé</li>
        </ol>
      </Card>
    </div>
  );
}
