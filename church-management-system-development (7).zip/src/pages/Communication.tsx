import { useState } from "react";
import { loadDB, saveDB, uid, type Message } from "../lib/data";
import { useAuth } from "../lib/auth";
import { Card, Button, Select, Textarea, Label, Badge } from "../components/ui";
import { MessageSquare, Send, Users, CheckCircle, Clock, AlertCircle } from "lucide-react";

const TEMPLATES = [
  { label: "Culte dimanche 8h", text: "Paix du Seigneur ! Rappel : culte ce Dimanche à 8h au temple MDC. Soyez bénis !" },
  { label: "Jeûne mercredi", text: "Chers frères et sœurs, journée de jeûne et prière ce mercredi. RDV 18h au temple." },
  { label: "Répétition louange", text: "Bonjour l'équipe louange, répétition samedi à 15h. Merci de confirmer votre présence." },
  { label: "Anniversaire membre", text: "Joyeux anniversaire ! Que le Seigneur te bénisse abondamment en cette nouvelle année. - Famille MDC" },
];

export default function Communication() {
  const { hasPermission } = useAuth();
  const [db, setDB] = useState(loadDB());
  const [canal, setCanal] = useState<"SMS" | "WhatsApp">("WhatsApp");
  const [cible, setCible] = useState("Tous");
  const [contenu, setContenu] = useState("");

  if (!hasPermission("envoyer_messages")) {
    return (
      <Card className="p-10 text-center">
        <MessageSquare size={40} className="mx-auto text-slate-400 mb-3" />
        <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">Module Communication</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
          Envoyer des SMS/WhatsApp groupés est réservé aux rôles autorisés.
        </p>
      </Card>
    );
  }

  const destinataires = () => {
    const membres = db.membres.filter((m) => !m.archived && m.consentementSMS);
    if (cible === "Tous") return membres.length;
    if (cible.startsWith("d")) return membres.filter((m) => m.departementId === cible).length;
    if (cible.startsWith("c")) return membres.filter((m) => m.celluleId === cible).length;
    return 0;
  };

  const envoyer = () => {
    if (!contenu.trim()) { alert("Le message est vide."); return; }
    if (contenu.length > 160 && canal === "SMS") {
      if (!confirm(`SMS trop long (${contenu.length} caractères). Il sera découpé. Continuer ?`)) return;
    }
    const msg: Message = {
      id: uid("msg"), canal, cible, contenu,
      dateEnvoi: new Date().toISOString(),
      destinataires: destinataires(),
      statut: "Envoyé",
    };
    const newDB = { ...db, messages: [msg, ...db.messages] };
    saveDB(newDB); setDB(newDB);
    setContenu("");
    alert(`✅ Message envoyé à ${msg.destinataires} destinataire(s) via ${canal}.`);
  };

  const statutIcon = (s: Message["statut"]) => {
    if (s === "Envoyé") return <CheckCircle size={14} className="text-green-600" />;
    if (s === "En attente") return <Clock size={14} className="text-amber-600" />;
    return <AlertCircle size={14} className="text-red-600" />;
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <MessageSquare className="text-mdc-gold" /> Communication
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          SMS & WhatsApp groupés via Twilio / Orange SMS API / WhatsApp Business
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Compositeur */}
        <Card className="p-5 lg:col-span-2">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-3">Nouveau message</h3>

          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <Label>Canal</Label>
                <div className="flex gap-2">
                  <button
                    onClick={() => setCanal("WhatsApp")}
                    className={`flex-1 p-2 rounded-lg border text-sm font-medium transition ${
                      canal === "WhatsApp"
                        ? "bg-green-600 text-white border-green-600"
                        : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300"
                    }`}
                  >WhatsApp</button>
                  <button
                    onClick={() => setCanal("SMS")}
                    className={`flex-1 p-2 rounded-lg border text-sm font-medium transition ${
                      canal === "SMS"
                        ? "bg-mdc-blue text-white border-mdc-blue"
                        : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300"
                    }`}
                  >SMS</button>
                </div>
              </div>
              <div>
                <Label>Destinataires</Label>
                <Select value={cible} onChange={(e) => setCible(e.target.value)}>
                  <option value="Tous">Tous les membres</option>
                  <optgroup label="Par département">
                    {db.departements.map((d) => <option key={d.id} value={d.id}>{d.nom}</option>)}
                  </optgroup>
                  <optgroup label="Par cellule">
                    {db.cellules.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}
                  </optgroup>
                </Select>
              </div>
              <div className="flex items-end">
                <div className="w-full p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 text-center">
                  <p className="text-2xl font-bold text-mdc-blue">{destinataires()}</p>
                  <p className="text-xs text-slate-500">destinataire(s)</p>
                </div>
              </div>
            </div>

            <div>
              <Label>Message ({contenu.length} / {canal === "SMS" ? 160 : 1000} car.)</Label>
              <Textarea rows={5} value={contenu} onChange={(e) => setContenu(e.target.value)} maxLength={canal === "SMS" ? 320 : 1000} placeholder="Tapez votre message ici..." />
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              <Button onClick={envoyer} className="flex-1"><Send size={16} /> Envoyer</Button>
              <Button variant="secondary" onClick={() => setContenu("")}>Effacer</Button>
            </div>

            <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-900/30">
              <p className="text-xs text-amber-800 dark:text-amber-200">
                <strong>RGPD :</strong> Seuls les membres ayant donné leur consentement SMS seront contactés ({destinataires()} sur {db.membres.filter((m) => !m.archived).length} actifs).
              </p>
            </div>
          </div>
        </Card>

        {/* Templates */}
        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-3">Templates</h3>
          <div className="space-y-2">
            {TEMPLATES.map((t, i) => (
              <button
                key={i}
                onClick={() => setContenu(t.text)}
                className="w-full text-left p-3 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition"
              >
                <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{t.label}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">{t.text}</p>
              </button>
            ))}
          </div>
        </Card>
      </div>

      {/* Historique */}
      <Card className="p-5">
        <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-3 flex items-center gap-2">
          <Users size={16} /> Historique des envois
        </h3>
        <div className="space-y-2">
          {db.messages.slice(0, 10).map((m) => {
            const cibleLabel = m.cible === "Tous" ? "Tous"
              : db.departements.find((d) => d.id === m.cible)?.nom
              || db.cellules.find((c) => c.id === m.cible)?.nom
              || m.cible;
            return (
              <div key={m.id} className="flex items-start gap-3 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-white flex-shrink-0 ${m.canal === "WhatsApp" ? "bg-green-600" : "bg-mdc-blue"}`}>
                  <MessageSquare size={16} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge color={m.canal === "WhatsApp" ? "green" : "blue"}>{m.canal}</Badge>
                    <span className="text-xs text-slate-500">→ {cibleLabel}</span>
                    <span className="text-xs text-slate-400">•</span>
                    <span className="text-xs text-slate-500">{m.destinataires} dest.</span>
                  </div>
                  <p className="text-sm text-slate-700 dark:text-slate-300 line-clamp-2">{m.contenu}</p>
                  <p className="text-xs text-slate-400 mt-1">{new Date(m.dateEnvoi).toLocaleString("fr-FR")}</p>
                </div>
                <div className="flex items-center gap-1 text-xs">
                  {statutIcon(m.statut)}
                  <span className="text-slate-500">{m.statut}</span>
                </div>
              </div>
            );
          })}
          {db.messages.length === 0 && (
            <p className="text-center text-slate-500 text-sm py-6">Aucun message envoyé pour l'instant.</p>
          )}
        </div>
      </Card>
    </div>
  );
}
