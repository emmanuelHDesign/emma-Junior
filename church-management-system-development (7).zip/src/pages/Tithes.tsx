import { useMemo, useState } from "react";
import { loadDB, saveDB, uid, type Dime } from "../lib/data";
import { useAuth } from "../lib/auth";
import { Card, Button, Input, Label, Select, Badge, Modal, StatCard } from "../components/ui";
import { Wallet, Plus, Download, FileText, Lock, TrendingUp, Printer } from "lucide-react";

const TYPES = ["Dîme", "Offrande", "Action de grâce", "Offrande spéciale"] as const;
const MODES = ["Cash", "MTN Mobile Money", "Orange Money"] as const;

export default function Tithes() {
  const { user, hasPermission } = useAuth();
  const [db, setDB] = useState(loadDB());
  const [showAdd, setShowAdd] = useState(false);
  const [receipt, setReceipt] = useState<Dime | null>(null);
  const [filterType, setFilterType] = useState("");

  if (!hasPermission("enregistrer_dime")) {
    return (
      <Card className="p-10 text-center">
        <Lock size={40} className="mx-auto text-slate-400 mb-3" />
        <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">Accès restreint</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
          Les montants financiers ne sont visibles que par le Pasteur et l'Administrateur, conformément à la politique de confidentialité MDC.
        </p>
      </Card>
    );
  }

  const canSeeAmounts = hasPermission("voir_finances");

  const stats = useMemo(() => {
    const total = db.dimes.reduce((s, d) => s + d.montant, 0);
    const dimes = db.dimes.filter((d) => d.type === "Dîme").reduce((s, d) => s + d.montant, 0);
    const offrandes = db.dimes.filter((d) => d.type !== "Dîme").reduce((s, d) => s + d.montant, 0);
    return { total, dimes, offrandes, count: db.dimes.length };
  }, [db]);

  const filtered = filterType ? db.dimes.filter((d) => d.type === filterType) : db.dimes;

  const save = (dimes: Dime[]) => {
    const newDB = { ...db, dimes };
    saveDB(newDB);
    setDB(newDB);
  };

  const handleAdd = (d: Dime) => {
    save([{ ...d, id: uid("dm"), enregistrePar: user!.id }, ...db.dimes]);
    setShowAdd(false);
  };

  const exportPdf = () => {
    alert("Reçu PDF généré. (En production : génération via weasyprint côté backend)");
  };

  const printReceipt = (d: Dime) => setReceipt(d);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Wallet className="text-mdc-gold" /> Dîmes & Offrandes
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {stats.count} contribution(s) enregistrée(s) · Traçabilité complète
          </p>
        </div>
        <Button onClick={() => setShowAdd(true)}><Plus size={16} /> Nouvelle contribution</Button>
      </div>

      {canSeeAmounts ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <StatCard label="Total du mois" value={`${stats.total.toLocaleString("fr-FR")} FCFA`} icon={<TrendingUp size={20} />} color="gold" />
          <StatCard label="Dîmes" value={`${stats.dimes.toLocaleString("fr-FR")} FCFA`} icon={<Wallet size={20} />} color="blue" />
          <StatCard label="Offrandes & actions" value={`${stats.offrandes.toLocaleString("fr-FR")} FCFA`} icon={<FileText size={20} />} color="green" />
        </div>
      ) : (
        <Card className="p-4 flex items-center gap-3 bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-900/30">
          <Lock size={20} className="text-amber-700" />
          <p className="text-sm text-amber-800 dark:text-amber-200">
            Vous pouvez enregistrer les contributions, mais seul le Pasteur voit les totaux financiers.
          </p>
        </Card>
      )}

      <Card className="p-4 flex flex-col sm:flex-row gap-3">
        <Select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="sm:w-48">
          <option value="">Toutes catégories</option>
          {TYPES.map((t) => <option key={t}>{t}</option>)}
        </Select>
        <Button variant="secondary" onClick={exportPdf}><Download size={16} /> Rapport mensuel (PDF)</Button>
      </Card>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs uppercase text-slate-500 dark:text-slate-400">
              <tr>
                <th className="text-left px-4 py-3">Date</th>
                <th className="text-left px-4 py-3">Membre</th>
                <th className="text-left px-4 py-3">Type</th>
                <th className="text-right px-4 py-3">Montant</th>
                <th className="text-left px-4 py-3 hidden md:table-cell">Mode</th>
                <th className="text-left px-4 py-3 hidden lg:table-cell">Référence</th>
                <th className="text-right px-4 py-3">Reçu</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map((d) => {
                const m = db.membres.find((x) => x.id === d.membreId);
                return (
                  <tr key={d.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30">
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{new Date(d.date).toLocaleDateString("fr-FR")}</td>
                    <td className="px-4 py-3 font-medium text-slate-900 dark:text-slate-100">{m ? `${m.prenom} ${m.nom}` : "—"}</td>
                    <td className="px-4 py-3">
                      <Badge color={d.type === "Dîme" ? "gold" : d.type === "Offrande" ? "blue" : "green"}>{d.type}</Badge>
                    </td>
                    <td className="px-4 py-3 text-right font-semibold text-slate-900 dark:text-slate-100">
                      {canSeeAmounts ? `${d.montant.toLocaleString("fr-FR")} FCFA` : "••••"}
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell text-slate-600 dark:text-slate-400 text-xs">{d.mode}</td>
                    <td className="px-4 py-3 hidden lg:table-cell text-xs text-slate-500">{d.reference || "—"}</td>
                    <td className="px-4 py-3 text-right">
                      <button onClick={() => printReceipt(d)} className="text-mdc-blue hover:underline text-xs flex items-center gap-1 ml-auto">
                        <Printer size={12} /> Imprimer
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && <tr><td colSpan={7} className="px-4 py-10 text-center text-slate-500">Aucune contribution.</td></tr>}
            </tbody>
          </table>
        </div>
      </Card>

      {showAdd && <DimeForm membres={db.membres} onClose={() => setShowAdd(false)} onSave={handleAdd} />}
      {receipt && <ReceiptModal dime={receipt} membre={db.membres.find((m) => m.id === receipt.membreId)!} onClose={() => setReceipt(null)} />}
    </div>
  );
}

function DimeForm({ membres, onClose, onSave }: {
  membres: ReturnType<typeof loadDB>["membres"];
  onClose: () => void;
  onSave: (d: Dime) => void;
}) {
  const [d, setD] = useState<Dime>({
    id: "", membreId: membres[0]?.id || "", montant: 0, type: "Dîme",
    date: new Date().toISOString().slice(0, 10), mode: "Cash", enregistrePar: ""
  });
  const update = <K extends keyof Dime>(k: K, v: Dime[K]) => setD({ ...d, [k]: v });

  return (
    <Modal open onClose={onClose} title="Enregistrer une contribution">
      <div className="space-y-3">
        <div><Label>Membre *</Label>
          <Select value={d.membreId} onChange={(e) => update("membreId", e.target.value)}>
            {membres.map((m) => <option key={m.id} value={m.id}>{m.prenom} {m.nom}</option>)}
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Type *</Label>
            <Select value={d.type} onChange={(e) => update("type", e.target.value as Dime["type"])}>
              {TYPES.map((t) => <option key={t}>{t}</option>)}
            </Select>
          </div>
          <div><Label>Montant (FCFA) *</Label><Input type="number" value={d.montant} onChange={(e) => update("montant", +e.target.value)} /></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Mode de paiement</Label>
            <Select value={d.mode} onChange={(e) => update("mode", e.target.value as Dime["mode"])}>
              {MODES.map((m) => <option key={m}>{m}</option>)}
            </Select>
          </div>
          <div><Label>Date</Label><Input type="date" value={d.date} onChange={(e) => update("date", e.target.value)} /></div>
        </div>
        {d.mode !== "Cash" && (
          <div><Label>Référence Mobile Money</Label><Input value={d.reference || ""} onChange={(e) => update("reference", e.target.value)} placeholder="MM-2025-10-XXX" /></div>
        )}
        <p className="text-xs text-slate-500 p-3 rounded bg-slate-50 dark:bg-slate-800/50">
          🔒 Cette action sera loggée (audit) : qui a enregistré, quand, montant. Seul le Pasteur peut voir les totaux.
        </p>
      </div>
      <div className="flex justify-end gap-2 mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
        <Button variant="ghost" onClick={onClose}>Annuler</Button>
        <Button onClick={() => {
          if (d.montant <= 0) { alert("Montant invalide."); return; }
          onSave(d);
        }}>Enregistrer</Button>
      </div>
    </Modal>
  );
}

function ReceiptModal({ dime, membre, onClose }: { dime: Dime; membre: ReturnType<typeof loadDB>["membres"][0]; onClose: () => void }) {
  return (
    <Modal open onClose={onClose} title="Reçu de contribution">
      <div id="receipt" className="p-6 border-2 border-dashed border-mdc-gold rounded-lg bg-white text-slate-900">
        <div className="text-center mb-4 pb-4 border-b border-mdc-gold">
          <h2 className="text-xl font-bold text-mdc-blue">MDC</h2>
          <p className="text-xs text-slate-600">Ministère des Déterminés pour Christ — Douala</p>
          <p className="text-xs italic text-slate-500 mt-1">"L'Esprit du Seigneur est sur moi" — Ésaïe 61:1-3</p>
        </div>
        <div className="text-center mb-4">
          <h3 className="text-lg font-bold uppercase">{dime.type}</h3>
          <p className="text-xs text-slate-500">Reçu N° {dime.id.toUpperCase()}</p>
        </div>
        <div className="space-y-1.5 text-sm">
          <p><strong>Reçu de :</strong> {membre.prenom} {membre.nom}</p>
          <p><strong>Téléphone :</strong> {membre.telephone}</p>
          <p><strong>Montant :</strong> <span className="text-lg font-bold text-mdc-gold-dark">{dime.montant.toLocaleString("fr-FR")} FCFA</span></p>
          <p><strong>Mode :</strong> {dime.mode} {dime.reference && `(${dime.reference})`}</p>
          <p><strong>Date :</strong> {new Date(dime.date).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p>
        </div>
        <div className="mt-6 pt-4 border-t border-slate-200 flex justify-between text-xs text-slate-500">
          <span>Le Seigneur vous bénisse ! 🙏</span>
          <span>Signature Pasteur</span>
        </div>
      </div>
      <div className="flex justify-end gap-2 mt-4">
        <Button variant="secondary" onClick={() => window.print()}><Printer size={14} /> Imprimer</Button>
        <Button onClick={onClose}>Fermer</Button>
      </div>
    </Modal>
  );
}
