import { useState } from "react";
import { loadDB, saveDB, uid, type Departement } from "../lib/data";
import { useAuth } from "../lib/auth";
import { Card, Button, Input, Label, Select, Badge, Modal, Textarea } from "../components/ui";
import { Network, Users, Edit2, Plus } from "lucide-react";

const COLORS = ["#1E3A8A", "#D4AF37", "#7C3AED", "#10B981", "#EF4444", "#F59E0B", "#06B6D4"];

export default function Departments() {
  const { hasPermission } = useAuth();
  const [db, setDB] = useState(loadDB());
  const [edit, setEdit] = useState<Departement | null>(null);
  const [showAdd, setShowAdd] = useState(false);

  const canManage = hasPermission("gerer_membres");

  const save = (departements: Departement[]) => {
    const newDB = { ...db, departements };
    saveDB(newDB); setDB(newDB);
  };

  const handleSave = (d: Departement) => {
    const exists = db.departements.find((x) => x.id === d.id);
    const next = exists ? db.departements.map((x) => (x.id === d.id ? d : x)) : [...db.departements, { ...d, id: uid("d") }];
    save(next);
    setEdit(null); setShowAdd(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Départements</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Louange, Protocole, Intercession, Enfants, etc.
          </p>
        </div>
        {canManage && <Button onClick={() => setShowAdd(true)}><Plus size={16} /> Nouveau département</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {db.departements.map((d) => {
          const membres = db.membres.filter((m) => m.departementId === d.id && !m.archived);
          const resp = db.membres.find((m) => m.id === d.responsableId);
          return (
            <Card key={d.id} className="overflow-hidden">
              <div className="h-2" style={{ background: d.couleur }} />
              <div className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-lg flex items-center justify-center" style={{ background: `${d.couleur}20` }}>
                      <Network size={20} style={{ color: d.couleur }} />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 dark:text-slate-100">{d.nom}</h3>
                      <Badge color="blue">{membres.length} membre(s)</Badge>
                    </div>
                  </div>
                  {canManage && (
                    <button onClick={() => setEdit(d)} className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800">
                      <Edit2 size={14} />
                    </button>
                  )}
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-3">{d.description}</p>
                {resp && (
                  <p className="text-sm text-slate-700 dark:text-slate-300 flex items-center gap-2">
                    <Users size={14} /> Responsable : <strong>{resp.prenom} {resp.nom}</strong>
                  </p>
                )}
                <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <p className="text-xs text-slate-500 mb-2">Membres</p>
                  <div className="flex flex-wrap gap-1 max-h-16 overflow-y-auto">
                    {membres.slice(0, 10).map((m) => (
                      <span key={m.id} className="text-xs px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800">
                        {m.prenom}
                      </span>
                    ))}
                    {membres.length > 10 && <span className="text-xs text-slate-500">+{membres.length - 10}</span>}
                    {membres.length === 0 && <span className="text-xs text-slate-400 italic">Aucun membre</span>}
                  </div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {(showAdd || edit) && (
        <DepartementForm initial={edit} membres={db.membres} onClose={() => { setEdit(null); setShowAdd(false); }} onSave={handleSave} />
      )}
    </div>
  );
}

function DepartementForm({ initial, membres, onClose, onSave }: {
  initial: Departement | null;
  membres: ReturnType<typeof loadDB>["membres"];
  onClose: () => void;
  onSave: (d: Departement) => void;
}) {
  const [d, setD] = useState<Departement>(initial ?? {
    id: "", nom: "", description: "", couleur: COLORS[0]
  });
  const update = <K extends keyof Departement>(k: K, v: Departement[K]) => setD({ ...d, [k]: v });

  return (
    <Modal open onClose={onClose} title={initial ? "Modifier le département" : "Nouveau département"}>
      <div className="space-y-3">
        <div><Label>Nom *</Label><Input value={d.nom} onChange={(e) => update("nom", e.target.value)} /></div>
        <div><Label>Responsable</Label>
          <Select value={d.responsableId || ""} onChange={(e) => update("responsableId", e.target.value || undefined)}>
            <option value="">— Aucun —</option>
            {membres.map((m) => <option key={m.id} value={m.id}>{m.prenom} {m.nom}</option>)}
          </Select>
        </div>
        <div><Label>Couleur</Label>
          <div className="flex gap-2 flex-wrap">
            {COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => update("couleur", c)}
                className={`w-8 h-8 rounded-lg border-2 transition ${d.couleur === c ? "border-slate-900 dark:border-white scale-110" : "border-transparent"}`}
                style={{ background: c }}
              />
            ))}
          </div>
        </div>
        <div><Label>Description</Label><Textarea rows={3} value={d.description} onChange={(e) => update("description", e.target.value)} /></div>
      </div>
      <div className="flex justify-end gap-2 mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
        <Button variant="ghost" onClick={onClose}>Annuler</Button>
        <Button onClick={() => {
          if (!d.nom.trim()) { alert("Nom requis."); return; }
          onSave(d);
        }}>Enregistrer</Button>
      </div>
    </Modal>
  );
}
