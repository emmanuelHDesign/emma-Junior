import { useState } from "react";
import { useAuth } from "../lib/auth";
import { Button, Card, Input, Label } from "../components/ui";
import { Navigate } from "react-router-dom";
import {
  KeyRound, ShieldCheck, Users, UserPlus, Mail, Lock,
  Phone, Eye, EyeOff, ArrowLeft, CheckCircle, AlertCircle, Sparkles
} from "lucide-react";

type Mode = "login" | "signup" | "forgot" | "reset" | "2fa";

export default function Login() {
  const { user, login, verify2FA, signup, forgotPassword, resetPassword } = useAuth();

  const [mode, setMode] = useState<Mode>("login");
  const [message, setMessage] = useState<{ type: "success" | "error" | "info"; text: string } | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  // Login
  const [email, setEmail] = useState("pasteur@mdc.cm");
  const [password, setPassword] = useState("demo123");
  const [rememberMe, setRememberMe] = useState(true);

  // 2FA
  const [code2FA, setCode2FA] = useState("");

  // Signup
  const [signupData, setSignupData] = useState({
    nom: "", email: "", password: "", confirmPassword: "", telephone: "",
    acceptCGU: false,
  });

  // Forgot / Reset
  const [forgotEmail, setForgotEmail] = useState("");
  const [resetToken, setResetToken] = useState("");
  const [newPassword, setNewPassword] = useState("");

  if (user) return <Navigate to="/" replace />;

  // ====== LOGIN ======
  const handleLogin = () => {
    setMessage(null);
    const result = login(email, password, rememberMe);
    if (!result.success) {
      setMessage({ type: "error", text: result.message });
      return;
    }
    if (result.needs2FA) {
      setMode("2fa");
      setMessage({ type: "info", text: result.message });
    } else {
      // Redirection automatique via Navigate
      window.location.href = "/";
    }
  };

  const handle2FA = () => {
    setMessage(null);
    if (verify2FA(code2FA)) {
      window.location.href = "/";
    } else {
      setMessage({ type: "error", text: "Code 2FA incorrect. Tapez 123456 pour la démo." });
    }
  };

  // ====== SIGNUP ======
  const handleSignup = () => {
    setMessage(null);
    if (!signupData.acceptCGU) {
      setMessage({ type: "error", text: "Vous devez accepter les conditions d'utilisation." });
      return;
    }
    if (signupData.password !== signupData.confirmPassword) {
      setMessage({ type: "error", text: "Les mots de passe ne correspondent pas." });
      return;
    }
    if (!signupData.nom.trim() || !signupData.telephone.trim()) {
      setMessage({ type: "error", text: "Tous les champs sont obligatoires." });
      return;
    }
    const result = signup({
      nom: signupData.nom,
      email: signupData.email,
      password: signupData.password,
      telephone: signupData.telephone,
    });
    if (result.success) {
      setMessage({ type: "success", text: result.message });
      setEmail(signupData.email);
      setPassword(signupData.password);
      setTimeout(() => setMode("login"), 1500);
    } else {
      setMessage({ type: "error", text: result.message });
    }
  };

  // ====== FORGOT PASSWORD ======
  const handleForgot = () => {
    setMessage(null);
    const result = forgotPassword(forgotEmail);
    if (result.resetToken) {
      setResetToken(result.resetToken);
      setMode("reset");
      setMessage({ type: "info", text: result.message });
    } else {
      setMessage({ type: "success", text: result.message });
    }
  };

  const handleReset = () => {
    setMessage(null);
    const result = resetPassword(resetToken, newPassword);
    if (result.success) {
      setMessage({ type: "success", text: result.message });
      setTimeout(() => setMode("login"), 1500);
    } else {
      setMessage({ type: "error", text: result.message });
    }
  };

  const quickLogin = (e: string) => {
    setEmail(e);
    setPassword("demo123");
    setMessage(null);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-mdc-blue via-mdc-blue-dark to-slate-900 relative overflow-hidden">
      {/* Décorations de fond */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-72 h-72 bg-mdc-gold rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-mdc-blue-light rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative z-10 animate-fade-in">
        {/* En-tête */}
        <div className="text-center mb-6 text-white">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-mdc-gold/20 border border-mdc-gold/30 mb-3">
            <Sparkles size={14} className="text-mdc-gold" />
            <span className="text-xs font-semibold text-mdc-gold">Version 2.0</span>
          </div>
          <h1 className="text-3xl font-bold tracking-tight">MDC</h1>
          <p className="text-white/90 text-base mt-2">Ministère des Déterminés pour Christ</p>
          <p className="text-white/70 text-sm mt-1">Douala, Cameroun</p>
        </div>

        {/* Onglets (sauf modes spéciaux) */}
        {(mode === "login" || mode === "signup") && (
          <div className="flex gap-2 mb-4 p-1 bg-white/10 rounded-lg backdrop-blur-sm">
            <button
              onClick={() => { setMode("login"); setMessage(null); }}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition ${
                mode === "login" ? "bg-white text-mdc-blue shadow" : "text-white/80 hover:bg-white/10"
              }`}
            >
              <KeyRound size={14} className="inline mr-1.5" /> Connexion
            </button>
            <button
              onClick={() => { setMode("signup"); setMessage(null); }}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition ${
                mode === "signup" ? "bg-white text-mdc-blue shadow" : "text-white/80 hover:bg-white/10"
              }`}
            >
              <UserPlus size={14} className="inline mr-1.5" /> Inscription
            </button>
          </div>
        )}

        <Card className="p-6">
          {/* Message global */}
          {message && (
            <div className={`mb-4 p-3 rounded-lg flex items-start gap-2 text-sm ${
              message.type === "success" ? "bg-green-50 dark:bg-green-900/20 text-green-800 dark:text-green-200 border border-green-200 dark:border-green-800" :
              message.type === "error" ? "bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-200 border border-red-200 dark:border-red-800" :
              "bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-200 border border-blue-200 dark:border-blue-800"
            }`}>
              {message.type === "success" && <CheckCircle size={16} className="flex-shrink-0 mt-0.5" />}
              {message.type === "error" && <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />}
              {message.type === "info" && <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />}
              <span>{message.text}</span>
            </div>
          )}

          {/* ====== MODE : LOGIN ====== */}
          {mode === "login" && (
            <>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4 flex items-center gap-2">
                <KeyRound size={18} /> Se connecter
              </h2>
              <div className="space-y-3">
                <div>
                  <Label>Email</Label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3 top-2.5 text-slate-400" />
                    <Input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="vous@mdc.cm"
                      className="pl-9"
                    />
                  </div>
                </div>
                <div>
                  <Label>Mot de passe</Label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3 top-2.5 text-slate-400" />
                    <Input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="pl-9 pr-9"
                      onKeyDown={(e) => e.key === "Enter" && handleLogin()}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="rounded border-slate-300"
                    />
                    <span className="text-slate-600 dark:text-slate-400">Se souvenir de moi</span>
                  </label>
                  <button
                    onClick={() => { setMode("forgot"); setMessage(null); }}
                    className="text-mdc-blue hover:underline"
                  >
                    Mot de passe oublié ?
                  </button>
                </div>

                <Button onClick={handleLogin} className="w-full">
                  <KeyRound size={16} /> Se connecter
                </Button>
              </div>

              {/* Comptes de démo */}
              <div className="mt-5 pt-5 border-t border-slate-200 dark:border-slate-800">
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">
                  Comptes de démo (mot de passe : <code className="font-mono bg-slate-100 dark:bg-slate-800 px-1 rounded">demo123</code>) :
                </p>
                <div className="grid grid-cols-1 gap-1.5">
                  {[
                    { e: "pasteur@mdc.cm", r: "PASTEUR", desc: "Accès complet + finances" },
                    { e: "admin@mdc.cm", r: "ADMIN", desc: "Tout + gestion utilisateurs" },
                    { e: "secretaire@mdc.cm", r: "SECRETAIRE", desc: "Membres & dîmes" },
                    { e: "chef1@mdc.cm", r: "CHEF_CELLULE", desc: "Sa cellule uniquement" },
                    { e: "membre@mdc.cm", r: "MEMBRE", desc: "Lecture seule" },
                  ].map((c) => (
                    <button
                      key={c.e}
                      onClick={() => quickLogin(c.e)}
                      className="flex items-center gap-2 p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-left text-xs transition"
                    >
                      <Users size={14} className="text-mdc-blue flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-slate-900 dark:text-slate-100 truncate">{c.e}</p>
                        <p className="text-slate-500 dark:text-slate-400">{c.r} — {c.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* ====== MODE : SIGNUP ====== */}
          {mode === "signup" && (
            <>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4 flex items-center gap-2">
                <UserPlus size={18} /> Créer un compte
              </h2>
              <div className="space-y-3">
                <div>
                  <Label>Nom complet *</Label>
                  <Input
                    value={signupData.nom}
                    onChange={(e) => setSignupData({ ...signupData, nom: e.target.value })}
                    placeholder="Jean Dupont"
                  />
                </div>
                <div>
                  <Label>Email *</Label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3 top-2.5 text-slate-400" />
                    <Input
                      type="email"
                      value={signupData.email}
                      onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                      placeholder="vous@email.cm"
                      className="pl-9"
                    />
                  </div>
                </div>
                <div>
                  <Label>Téléphone *</Label>
                  <div className="relative">
                    <Phone size={16} className="absolute left-3 top-2.5 text-slate-400" />
                    <Input
                      type="tel"
                      value={signupData.telephone}
                      onChange={(e) => setSignupData({ ...signupData, telephone: e.target.value })}
                      placeholder="+237 6XX XX XX XX"
                      className="pl-9"
                    />
                  </div>
                </div>
                <div>
                  <Label>Mot de passe * (min 6 caractères)</Label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3 top-2.5 text-slate-400" />
                    <Input
                      type={showPassword ? "text" : "password"}
                      value={signupData.password}
                      onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                      placeholder="••••••••"
                      className="pl-9 pr-9"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
                <div>
                  <Label>Confirmer le mot de passe *</Label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3 top-2.5 text-slate-400" />
                    <Input
                      type={showPassword ? "text" : "password"}
                      value={signupData.confirmPassword}
                      onChange={(e) => setSignupData({ ...signupData, confirmPassword: e.target.value })}
                      placeholder="••••••••"
                      className="pl-9"
                    />
                  </div>
                </div>

                <label className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={signupData.acceptCGU}
                    onChange={(e) => setSignupData({ ...signupData, acceptCGU: e.target.checked })}
                    className="mt-0.5 rounded"
                  />
                  <span>
                    J'accepte les conditions d'utilisation et la politique de confidentialité RGPD de MDC.
                    Je consens à recevoir les communications de l'église.
                  </span>
                </label>

                <Button onClick={handleSignup} variant="gold" className="w-full">
                  <UserPlus size={16} /> Créer mon compte
                </Button>

                <p className="text-xs text-center text-slate-500 dark:text-slate-400">
                  Votre compte sera créé avec le rôle <strong>MEMBRE</strong>.
                  Un administrateur peut modifier vos accès.
                </p>
              </div>
            </>
          )}

          {/* ====== MODE : FORGOT PASSWORD ====== */}
          {mode === "forgot" && (
            <>
              <button
                onClick={() => { setMode("login"); setMessage(null); }}
                className="text-xs text-slate-500 hover:text-mdc-blue mb-3 inline-flex items-center gap-1"
              >
                <ArrowLeft size={12} /> Retour à la connexion
              </button>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-2">
                <Mail size={18} /> Mot de passe oublié
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                Entrez votre email pour recevoir un lien de réinitialisation.
              </p>
              <div className="space-y-3">
                <div>
                  <Label>Email du compte</Label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3 top-2.5 text-slate-400" />
                    <Input
                      type="email"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="vous@mdc.cm"
                      className="pl-9"
                    />
                  </div>
                </div>
                <Button onClick={handleForgot} className="w-full">
                  Envoyer le lien
                </Button>
              </div>
            </>
          )}

          {/* ====== MODE : RESET PASSWORD ====== */}
          {mode === "reset" && (
            <>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-2">
                <Lock size={18} /> Nouveau mot de passe
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                Définissez votre nouveau mot de passe sécurisé.
              </p>
              <div className="space-y-3">
                <div>
                  <Label>Token de réinitialisation (démo)</Label>
                  <Input
                    value={resetToken}
                    onChange={(e) => setResetToken(e.target.value)}
                    className="font-mono text-xs"
                  />
                </div>
                <div>
                  <Label>Nouveau mot de passe (min 6 car.)</Label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3 top-2.5 text-slate-400" />
                    <Input
                      type={showPassword ? "text" : "password"}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="••••••••"
                      className="pl-9 pr-9"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-400"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
                <Button onClick={handleReset} variant="gold" className="w-full">
                  Réinitialiser le mot de passe
                </Button>
              </div>
            </>
          )}

          {/* ====== MODE : 2FA ====== */}
          {mode === "2fa" && (
            <>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2 flex items-center gap-2">
                <ShieldCheck size={18} /> Vérification 2FA
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                Un code a été envoyé par SMS au numéro enregistré.
                Tapez <strong className="text-mdc-blue">123456</strong> pour la démo.
              </p>
              <div className="space-y-3">
                <div>
                  <Label>Code à 6 chiffres</Label>
                  <Input
                    value={code2FA}
                    onChange={(e) => setCode2FA(e.target.value)}
                    placeholder="123456"
                    maxLength={6}
                    className="text-center text-2xl tracking-[0.5em] font-mono font-bold"
                    onKeyDown={(e) => e.key === "Enter" && handle2FA()}
                  />
                </div>
                <Button onClick={handle2FA} className="w-full">
                  <ShieldCheck size={16} /> Valider et se connecter
                </Button>
                <button
                  onClick={() => { setMode("login"); setMessage(null); }}
                  className="w-full text-xs text-slate-500 hover:text-mdc-blue inline-flex items-center justify-center gap-1"
                >
                  <ArrowLeft size={12} /> Changer de compte
                </button>
              </div>
            </>
          )}
        </Card>

        {/* Footer V2 */}
        <div className="text-center mt-4 space-y-2">
          <p className="text-white/50 text-xs">
            🔒 Sécurisé par HTTPS · JWT · RBAC · 2FA SMS · bcrypt
          </p>

          <div className="pt-3 border-t border-white/10">
            <p className="text-white/40 text-[10px] uppercase tracking-wider">Application développée par</p>
            <p className="text-mdc-gold font-semibold text-sm mt-1">
              Emmanuel Junior Bona
            </p>
            <p className="text-white/60 text-xs mt-0.5">Consultant Église Digitale</p>
          </div>
        </div>
      </div>
    </div>
  );
}
