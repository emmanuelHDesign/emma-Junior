// V3.0 — Esaïe IA : Assistant Bible MDC avec streaming
import { useState, useRef, useEffect } from "react";
import { useAuth } from "../lib/auth";
import {
  streamAIResponse, getChatHistory, saveChatMessage,
  clearChatHistory, createMessage, getRemainingMessages,
  incrementMessageCount, type ChatMessage
} from "../lib/ai-engine";
import { SUGGESTIONS_CHAT } from "../lib/ai-system-prompt";
import { ChatInput } from "../components/ChatInput";
import { Badge, Button } from "../components/ui";
import { Sparkles, Trash2, AlertTriangle, MessageSquare, Bot, User } from "lucide-react";

export default function EsaieIA() {
  const { user } = useAuth();
  if (!user) return null;

  return <ChatView userId={user.id} userName={user.nom} />;
}

function ChatView({ userId, userName }: { userId: string; userName: string }) {
  const [messages, setMessages] = useState<ChatMessage[]>(getChatHistory(userId));
  const [streaming, setStreaming] = useState(false);
  const [streamContent, setStreamContent] = useState("");
  const [remaining, setRemaining] = useState(getRemainingMessages(userId));
  const [showClear, setShowClear] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, streamContent]);

  const handleSend = async (text: string) => {
    if (streaming) return;
    if (remaining <= 0) return;

    // Message utilisateur
    const userMsg = createMessage("user", text);
    saveChatMessage(userId, userMsg);
    setMessages((prev) => [...prev, userMsg]);
    incrementMessageCount(userId);
    setRemaining(getRemainingMessages(userId));

    // Streaming de la réponse IA
    setStreaming(true);
    setStreamContent("");

    let fullResponse = "";
    for await (const chunk of streamAIResponse(text, userId)) {
      fullResponse += chunk;
      setStreamContent(fullResponse);
    }

    // Sauvegarder le message assistant
    const assistantMsg = createMessage("assistant", fullResponse);
    saveChatMessage(userId, assistantMsg);
    setMessages((prev) => [...prev, assistantMsg]);
    setStreamContent("");
    setStreaming(false);
  };

  const handleClear = () => {
    clearChatHistory(userId);
    setMessages([]);
    setShowClear(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-h-[800px]">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 rounded-t-xl">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-full bg-gradient-to-br from-mdc-blue to-mdc-blue-dark flex items-center justify-center">
            <Sparkles size={20} className="text-mdc-gold" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-slate-900 dark:text-slate-100">Esaïe IA</h2>
              <Badge color="gold">BETA</Badge>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Assistant Bible MDC · 24h/24</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge color={remaining > 10 ? "green" : remaining > 0 ? "gold" : "red"}>
            {remaining}/50
          </Badge>
          <button
            onClick={() => setShowClear(true)}
            className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 text-red-500"
            title="Supprimer mon historique IA"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50 dark:bg-slate-950"
      >
        {/* Message de bienvenue */}
        {messages.length === 0 && !streaming && (
          <div className="text-center py-8 space-y-6">
            <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-mdc-blue to-mdc-blue-dark flex items-center justify-center">
              <Sparkles size={36} className="text-mdc-gold" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-slate-100">
                Shalom {userName.split(" ")[0]} ! 🙏
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-2 max-w-md mx-auto">
                Je suis <strong>Esaïe IA</strong>, votre assistant biblique MDC.
                Posez-moi vos questions sur la Bible, la prière ou la vie chrétienne.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 max-w-md mx-auto">
              <div className="flex items-start gap-2">
                <AlertTriangle size={14} className="text-amber-600 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-amber-800 dark:text-amber-200 text-left">
                  L'IA cite la Bible mais <strong>ne remplace pas votre Pasteur ni votre Berger</strong>.
                  Pour les questions profondes, contactez l'équipe MDC.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-w-lg mx-auto">
              {SUGGESTIONS_CHAT.slice(0, 8).map((suggestion, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(suggestion)}
                  className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800 text-sm text-left text-slate-700 dark:text-slate-300 transition hover:border-mdc-blue min-h-[48px]"
                >
                  <MessageSquare size={12} className="inline mr-1.5 text-mdc-blue" />
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Historique des messages */}
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
          >
            {msg.role === "assistant" && (
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-mdc-blue to-mdc-blue-dark flex items-center justify-center flex-shrink-0 mt-1">
                <Bot size={14} className="text-mdc-gold" />
              </div>
            )}
            <div
              className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 text-base whitespace-pre-line ${
                msg.role === "user"
                  ? "bg-mdc-blue text-white rounded-br-md"
                  : "bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-bl-md shadow-sm"
              }`}
            >
              {msg.content}
              <p className={`text-[10px] mt-1 ${msg.role === "user" ? "text-blue-200" : "text-slate-400"}`}>
                {new Date(msg.timestamp).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
            {msg.role === "user" && (
              <div className="w-8 h-8 rounded-full bg-mdc-gold text-mdc-blue-dark flex items-center justify-center flex-shrink-0 mt-1">
                <User size={14} />
              </div>
            )}
          </div>
        ))}

        {/* Message en cours de streaming */}
        {streaming && streamContent && (
          <div className="flex gap-3 justify-start">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-mdc-blue to-mdc-blue-dark flex items-center justify-center flex-shrink-0 mt-1">
              <Bot size={14} className="text-mdc-gold animate-pulse" />
            </div>
            <div className="max-w-[85%] sm:max-w-[75%] rounded-2xl rounded-bl-md px-4 py-3 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 shadow-sm text-base whitespace-pre-line">
              {streamContent}
              <span className="inline-block w-1.5 h-4 bg-mdc-blue animate-pulse ml-0.5 align-text-bottom rounded" />
            </div>
          </div>
        )}

        {/* Indicateur de frappe */}
        {streaming && !streamContent && (
          <div className="flex gap-3 justify-start">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-mdc-blue to-mdc-blue-dark flex items-center justify-center flex-shrink-0">
              <Bot size={14} className="text-mdc-gold" />
            </div>
            <div className="rounded-2xl rounded-bl-md px-5 py-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm">
              <div className="flex gap-1.5">
                <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Limite atteinte */}
      {remaining <= 0 && (
        <div className="px-4 py-3 bg-red-50 dark:bg-red-900/20 border-t border-red-200 dark:border-red-800 text-center">
          <p className="text-sm text-red-700 dark:text-red-300">
            Limite quotidienne atteinte (50 messages/jour). Revenez demain ! 🙏
          </p>
        </div>
      )}

      {/* Input */}
      <ChatInput
        onSend={handleSend}
        disabled={streaming || remaining <= 0}
        placeholder={remaining <= 0 ? "Limite atteinte — revenez demain" : "Posez votre question biblique..."}
      />

      {/* Modal suppression historique */}
      {showClear && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={() => setShowClear(false)}>
          <div className="p-5 max-w-sm w-full bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800" onClick={(e: React.MouseEvent) => e.stopPropagation()}>
            <h3 className="font-bold text-slate-900 dark:text-slate-100 mb-2">Supprimer l'historique IA ?</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
              Toutes vos conversations avec Esaïe IA seront supprimées définitivement. Conformément au RGPD, cette action est irréversible.
            </p>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => setShowClear(false)} className="flex-1">Annuler</Button>
              <Button variant="danger" onClick={handleClear} className="flex-1">
                <Trash2 size={14} /> Tout supprimer
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
