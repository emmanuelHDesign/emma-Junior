import { useState } from "react";
import { useAuth } from "../lib/auth";
import { loadDB } from "../lib/data";
import { Card, Button, Input, Label, Badge } from "../components/ui";
import { PhotoUpload } from "../components/PhotoUpload";
import { CoverUpload } from "../components/CoverUpload";
import {
  User, Mail, Phone, Shield, Calendar, Lock, Save,
  CheckCircle, AlertCircle, History, Smartphone, Eye, EyeOff, Camera
} from "lucide-react";

export default function Profile() {
  const { user, updateProfile, changePassword } = useAuth();
  const db = loadDB();

  const [editing, setEditing] = useState(false);
  const [nom, setNom] = useState(user?.nom || "");
  const [telephone, setTelephone] = useState(user?.telephone || "");
  const [deuxFacteurs, setDeuxFacteurs] = useState(user?.deuxFacteurs || false);
  const [photoUrl, setPhotoUrl] = useState<string | undefined>(user?.photoUrl);
  const [coverUrl, setCoverUrl] = useState<string | undefined>(user?.coverUrl);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Changement mot de passe
  const [showPwdSection, setShowPwdSection] = useState(false);
  const [oldPwd, setOldPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [pwdMessage, setPwdMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  if (!user) return null;

  const initials = user.nom.split(" ").map(n => n[0]).slice(0, 2).join("").toUpperCase();
  const membre = user.membreId ? db.membres.find(m => m.id === user.membreId) : null;

  const handleSave = () => {
    const ok = updateProfile({ nom, telephone, deuxFacteurs, photoUrl, coverUrl });
    if (ok) {
      setMessage({ type: "success", text: "Profil mis à jour avec succès !" });
      setEditing(false);
      setTimeout(() => setMessage(null), 3000);
    } else {
      setMessage({ type: "error", text: "Erreur lors de la mise à jour." });
    }
  };

  const handlePhotoChange = (newPhoto: string | undefined) => {
    setPhotoUrl(newPhoto);
    updateProfile({ photoUrl: newPhoto });
    setMessage({ type: "success", text: newPhoto ? "Photo de profil mise à jour !" : "Photo supprimée." });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleCoverChange = (newCover: string | undefined) => {
    setCoverUrl(newCover);
    updateProfile({ coverUrl: newCover });
    setMessage({ type: "success", text: newCover ? "Photo de couverture mise à jour !" : "Couverture supprimée." });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleChangePassword = () => {
    setPwdMessage(null);
    if (newPwd !== confirmPwd) {
      setPwdMessage({ type: "error", text: "Les nouveaux mots de passe ne correspondent pas." });
      return;
    }
    const result = changePassword(oldPwd, newPwd);
    if (result.success) {
      setPwdMessage({ type: "success", text: result.message });
      setOldPwd(""); setNewPwd(""); setConfirmPwd("");
      setTimeout(() => { setShowPwdSection(false); setPwdMessage(null); }, 2000);
    } else {
      setPwdMessage({ type: "error", text: result.message });
    }
  };

  // Historique connexions de cet utilisateur
  const monHistorique = db.loginHistory.filter(h => h.userId === user.id).slice(0, 10);

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <User className="text-mdc-gold" /> Mon Profil
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Gérez vos informations personnelles et votre sécurité
        </p>
      </div>

      {message && (
        <div className={`p-3 rounded-lg flex items-center gap-2 text-sm ${
          message.type === "success"
            ? "bg-green-50 dark:bg-green-900/20 text-green-800 dark:text-green-200 border border-green-200"
            : "bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-200 border border-red-200"
        }`}>
          {message.type === "success" ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
          {message.text}
        </div>
      )}

      {/* Carte profil avec couverture + photo */}
      <Card className="overflow-hidden">
        <CoverUpload
          currentCover={coverUrl}
          onCoverChange={handleCoverChange}
          editing={editing}
        />
        <div className="px-6 pb-6 -mt-16">
          <div className="flex flex-col sm:flex-row gap-4 items-start">
            {/* Photo de profil */}
            {editing ? (
              <PhotoUpload
                currentPhoto={photoUrl}
                initials={initials}
                onPhotoChange={handlePhotoChange}
              />
            ) : (
              <div className="relative group">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white dark:border-slate-900 shadow-lg bg-gradient-to-br from-mdc-gold to-mdc-gold-dark flex items-center justify-center flex-shrink-0">
                  {photoUrl ? (
                    <img src={photoUrl} alt={user.nom} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-4xl font-bold text-mdc-blue-dark">{initials}</span>
                  )}
                </div>
                <button
                  onClick={() => setEditing(true)}
                  className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
                  title="Modifier la photo"
                >
                  <Camera size={28} className="text-white" />
                </button>
              </div>
            )}

            <div className="flex-1 pt-16 sm:pt-20">
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <h2 className="text-xl font-bold text-slate-900 dark:text-slate-100">{user.nom}</h2>
                <Badge color={user.role === "PASTEUR" || user.role === "ADMIN" ? "gold" : "blue"}>
                  {user.role}
                </Badge>
                {user.actif && <Badge color="green">Actif</Badge>}
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-400">{user.email}</p>
              {user.telephone && <p className="text-sm text-slate-500 dark:text-slate-400">{user.telephone}</p>}
            </div>
            {!editing && (
              <Button variant="secondary" onClick={() => setEditing(true)}>
                Modifier
              </Button>
            )}
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Infos personnelles */}
        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-4 flex items-center gap-2">
            <User size={16} /> Informations personnelles
          </h3>
          <div className="space-y-3">
            <div>
              <Label>Nom complet</Label>
              {editing ? (
                <Input value={nom} onChange={(e) => setNom(e.target.value)} />
              ) : (
                <p className="text-sm text-slate-900 dark:text-slate-100 py-2">{user.nom}</p>
              )}
            </div>
            <div>
              <Label>Email</Label>
              <div className="flex items-center gap-2 py-2 text-sm text-slate-900 dark:text-slate-100">
                <Mail size={14} className="text-slate-400" />
                {user.email}
                <Badge color="slate">Non modifiable</Badge>
              </div>
            </div>
            <div>
              <Label>Téléphone</Label>
              {editing ? (
                <Input value={telephone} onChange={(e) => setTelephone(e.target.value)} placeholder="+237 6XX XX XX XX" />
              ) : (
                <div className="flex items-center gap-2 py-2 text-sm text-slate-900 dark:text-slate-100">
                  <Phone size={14} className="text-slate-400" />
                  {user.telephone || "Non renseigné"}
                </div>
              )}
            </div>
            <div>
              <Label>Rôle</Label>
              <div className="flex items-center gap-2 py-2">
                <Shield size={14} className="text-slate-400" />
                <Badge color={user.role === "PASTEUR" || user.role === "ADMIN" ? "gold" : "blue"}>
                  {user.role}
                </Badge>
              </div>
            </div>
            <div>
              <Label>Compte créé le</Label>
              <div className="flex items-center gap-2 py-2 text-sm text-slate-600 dark:text-slate-400">
                <Calendar size={14} className="text-slate-400" />
                {new Date(user.dateCreation).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
              </div>
            </div>

            {editing && (
              <div className="flex gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <Button variant="ghost" onClick={() => { setEditing(false); setNom(user.nom); setTelephone(user.telephone || ""); }} className="flex-1">
                  Annuler
                </Button>
                <Button onClick={handleSave} className="flex-1">
                  <Save size={14} /> Enregistrer
                </Button>
              </div>
            )}
          </div>
        </Card>

        {/* Sécurité */}
        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-4 flex items-center gap-2">
            <Shield size={16} /> Sécurité
          </h3>
          <div className="space-y-3">
            {/* 2FA */}
            <div className="flex items-center justify-between p-3 rounded-lg border border-slate-200 dark:border-slate-700">
              <div className="flex items-center gap-3">
                <Smartphone size={20} className="text-mdc-blue" />
                <div>
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100">Authentification 2FA</p>
                  <p className="text-xs text-slate-500">Vérification par SMS à chaque connexion</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={deuxFacteurs}
                  onChange={(e) => { setDeuxFacteurs(e.target.checked); if (!editing) updateProfile({ deuxFacteurs: e.target.checked }); }}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-mdc-blue"></div>
              </label>
            </div>

            {/* Mot de passe */}
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-700">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <Lock size={20} className="text-mdc-blue" />
                  <div>
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100">Mot de passe</p>
                    <p className="text-xs text-slate-500">Modifié pour la dernière fois récemment</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowPwdSection(!showPwdSection)}
                  className="text-xs text-mdc-blue hover:underline"
                >
                  {showPwdSection ? "Annuler" : "Changer"}
                </button>
              </div>

              {showPwdSection && (
                <div className="space-y-2 pt-3 border-t border-slate-200 dark:border-slate-700">
                  <div>
                    <Label>Ancien mot de passe</Label>
                    <div className="relative">
                      <Input
                        type={showPwd ? "text" : "password"}
                        value={oldPwd}
                        onChange={(e) => setOldPwd(e.target.value)}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPwd(!showPwd)}
                        className="absolute right-3 top-2.5 text-slate-400"
                      >
                        {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                    </div>
                  </div>
                  <div>
                    <Label>Nouveau mot de passe (min 6 car.)</Label>
                    <Input type={showPwd ? "text" : "password"} value={newPwd} onChange={(e) => setNewPwd(e.target.value)} />
                  </div>
                  <div>
                    <Label>Confirmer le nouveau mot de passe</Label>
                    <Input type={showPwd ? "text" : "password"} value={confirmPwd} onChange={(e) => setConfirmPwd(e.target.value)} />
                  </div>

                  {pwdMessage && (
                    <div className={`p-2 rounded text-xs flex items-center gap-1 ${
                      pwdMessage.type === "success" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                    }`}>
                      {pwdMessage.text}
                    </div>
                  )}

                  <Button onClick={handleChangePassword} className="w-full" variant="gold">
                    <Save size={14} /> Modifier le mot de passe
                  </Button>
                </div>
              )}
            </div>

            {/* Profil membre lié */}
            {membre && (
              <div className="p-3 rounded-lg bg-mdc-gold/10 border border-mdc-gold/30">
                <p className="text-xs font-semibold text-mdc-gold-dark dark:text-mdc-gold mb-1">PROFIL MEMBRE ASSOCIÉ</p>
                <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                  {membre.prenom} {membre.nom}
                </p>
                <p className="text-xs text-slate-500">{membre.statut} • Intégré le {new Date(membre.dateIntegration).toLocaleDateString("fr-FR")}</p>
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Historique de connexions */}
      <Card className="p-5">
        <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-4 flex items-center gap-2">
          <History size={16} /> Historique de connexion
        </h3>
        <div className="space-y-2">
          {monHistorique.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-6">Aucun historique disponible.</p>
          ) : (
            monHistorique.map((h) => (
              <div key={h.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${h.success ? "bg-green-500" : "bg-red-500"}`} />
                  <div>
                    <p className="text-sm text-slate-900 dark:text-slate-100">
                      {h.success ? "Connexion réussie" : "Tentative échouée"}
                    </p>
                    <p className="text-xs text-slate-500">{h.device} · IP {h.ip}</p>
                  </div>
                </div>
                <span className="text-xs text-slate-500">
                  {new Date(h.date).toLocaleString("fr-FR")}
                </span>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
}
