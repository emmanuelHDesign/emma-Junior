import { useState } from "react";
import { loadDB, saveDB, uid, type Cellule } from "../lib/data";
import { useAuth } from "../lib/auth";
import { Card, Button, Input, Label, Select, Badge, Modal, Textarea } from "../components/ui";
import { Home, Users, MapPin, Calendar, Clock, Plus, Edit2, FileText } from "lucide-react";

export default function Cells() {
  const { user } = useAuth();
  const [db, setDB] = useState(loadDB());
  const [edit, setEdit] = useState<Cellule | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [reportFor, setReportFor] = useState<string | null>(null);

  const isAdmin = user?.role === "PASTEUR" || user?.role === "ADMIN";
  const isChef = user?.role === "CHEF_CELLULE";

  const visibleCellules = isChef
    ? db.cellules.filter((c) => c.chefId === "m4") // mock : chef de la cellule Béthel
    : db.cellules;

  const save = (cellules: Cellule[]) => {
    const newDB = { ...db, cellules };
    saveDB(newDB);
    setDB(newDB);
  };

  const handleSave = (c: Cellule) => {
    const exists = db.cellules.find((x) => x.id === c.id);
    const next = exists ? db.cellules.map((x) => (x.id === c.id ? c : x)) : [...db.cellules, { ...c, id: uid("c") }];
    save(next);
    setEdit(null); setShowAdd(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Cellules de maison</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {db.cellules.length} cellule(s) active(s) · {db.membres.filter((m) => m.celluleId && !m.archived).length} membres répartis
          </p>
        </div>
        {isAdmin && <Button onClick={() => setShowAdd(true)}><Plus size={16} /> Nouvelle cellule</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {visibleCellules.map((c) => {
          const membres = db.membres.filter((m) => m.celluleId === c.id && !m.archived);
          const chef = db.membres.find((m) => m.id === c.chefId);
          return (
            <Card key={c.id} className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-lg bg-mdc-blue/10 flex items-center justify-center">
                    <Home size={20} className="text-mdc-blue" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-slate-100">{c.nom}</h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">{c.zone}</p>
                  </div>
                </div>
                <Badge color="blue">{membres.length} membres</Badge>
              </div>

              <div className="space-y-2 text-sm mb-4">
                <p className="flex items-start gap-2 text-slate-600 dark:text-slate-400">
                  <MapPin size={14} className="mt-0.5 flex-shrink-0" />
                  <span className="truncate">{c.adresse}</span>
                </p>
                <p className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                  <Calendar size={14} /> {c.jourRencontre}
                  <Clock size={14} className="ml-2" /> {c.heureRencontre}
                </p>
                {chef && (
                  <p className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                    <Users size={14} /> <span>Chef : <strong>{chef.prenom} {chef.nom}</strong></span>
                  </p>
                )}
              </div>

              <div className="flex flex-wrap gap-1 mb-3 max-h-16 overflow-y-auto">
                {membres.slice(0, 8).map((m) => (
                  <span key={m.id} className="text-xs px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                    {m.prenom} {m.nom[0]}.
                  </span>
                ))}
                {membres.length > 8 && (
                  <span className="text-xs text-slate-500">+{membres.length - 8}</span>
                )}
              </div>

              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => setReportFor(c.id)} className="flex-1">
                  <FileText size={14} /> Rapport hebdo
                </Button>
                {(isAdmin || isChef) && (
                  <button onClick={() => setEdit(c)} className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800">
                    <Edit2 size={14} />
                  </button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      {(showAdd || edit) && (
        <CelluleForm initial={edit} membres={db.membres} onClose={() => { setEdit(null); setShowAdd(false); }} onSave={handleSave} />
      )}

      {reportFor && <RapportModal celluleId={reportFor} db={db} onClose={() => setReportFor(null)} />}
    </div>
  );
}

function CelluleForm({ initial, membres, onClose, onSave }: {
  initial: Cellule | null;
  membres: ReturnType<typeof loadDB>["membres"];
  onClose: () => void;
  onSave: (c: Cellule) => void;
}) {
  const [c, setC] = useState<Cellule>(initial ?? {
    id: "", nom: "", chefId: "", adresse: "", jourRencontre: "Mercredi", heureRencontre: "18:00", zone: ""
  });
  const update = <K extends keyof Cellule>(k: K, v: Cellule[K]) => setC({ ...c, [k]: v });
  return (
    <Modal open onClose={onClose} title={initial ? "Modifier la cellule" : "Nouvelle cellule"}>
      <div className="space-y-3">
        <div><Label>Nom *</Label><Input value={c.nom} onChange={(e) => update("nom", e.target.value)} placeholder="Cellule Béthel" /></div>
        <div><Label>Zone / Quartier</Label><Input value={c.zone} onChange={(e) => update("zone", e.target.value)} placeholder="Bonamoussadi" /></div>
        <div><Label>Chef de cellule</Label>
          <Select value={c.chefId} onChange={(e) => update("chefId", e.target.value)}>
            <option value="">— Sélectionner —</option>
            {membres.map((m) => <option key={m.id} value={m.id}>{m.prenom} {m.nom}</option>)}
          </Select>
        </div>
        <div><Label>Adresse de réunion</Label><Textarea rows={2} value={c.adresse} onChange={(e) => update("adresse", e.target.value)} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Jour</Label>
            <Select value={c.jourRencontre} onChange={(e) => update("jourRencontre", e.target.value)}>
              {["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"].map((j) => <option key={j}>{j}</option>)}
            </Select>
          </div>
          <div><Label>Heure</Label><Input type="time" value={c.heureRencontre} onChange={(e) => update("heureRencontre", e.target.value)} /></div>
        </div>
      </div>
      <div className="flex justify-end gap-2 mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
        <Button variant="ghost" onClick={onClose}>Annuler</Button>
        <Button onClick={() => {
          if (!c.nom.trim()) { alert("Nom requis."); return; }
          onSave(c);
        }}>Enregistrer</Button>
      </div>
    </Modal>
  );
}

function RapportModal({ celluleId, db, onClose }: { celluleId: string; db: ReturnType<typeof loadDB>; onClose: () => void }) {
  const c = db.cellules.find((x) => x.id === celluleId)!;
  const membres = db.membres.filter((m) => m.celluleId === celluleId && !m.archived);
  const [report, setReport] = useState({ presents: 0, absents: 0, priere: "", enseignement: "", action: "" });

  return (
    <Modal open onClose={onClose} title={`Rapport hebdo — ${c.nom}`} maxWidth="lg">
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Présents</Label><Input type="number" value={report.presents} onChange={(e) => setReport({ ...report, presents: +e.target.value })} /></div>
          <div><Label>Absents</Label><Input type="number" value={report.absents} onChange={(e) => setReport({ ...report, absents: +e.target.value })} /></div>
        </div>
        <div><Label>Sujet de prière</Label><Textarea rows={2} value={report.priere} onChange={(e) => setReport({ ...report, priere: e.target.value })} /></div>
        <div><Label>Enseignement / partage</Label><Textarea rows={3} value={report.enseignement} onChange={(e) => setReport({ ...report, enseignement: e.target.value })} /></div>
        <div><Label>Actions à suivre</Label><Textarea rows={2} value={report.action} onChange={(e) => setReport({ ...report, action: e.target.value })} /></div>
        <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-500">
          Membres de la cellule : {membres.map((m) => `${m.prenom} ${m.nom[0]}.`).join(", ")}
        </div>
      </div>
      <div className="flex justify-end gap-2 mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
        <Button variant="ghost" onClick={onClose}>Annuler</Button>
        <Button onClick={() => { alert("Rapport envoyé au Pasteur ✅"); onClose(); }}>Envoyer au Pasteur</Button>
      </div>
    </Modal>
  );
}
