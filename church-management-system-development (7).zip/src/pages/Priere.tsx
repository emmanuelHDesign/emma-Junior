// V2.2 — Carnet de prière chiffré AES côté client
import { useState, useEffect, useRef } from "react";
import { useAuth } from "../lib/auth";
import { getMesPrieres, savePriere, deletePriere } from "../lib/priere-data";
import { Card, Button, Badge } from "../components/ui";
import { BookHeart, Plus, Save, Trash2, Lock, Shield, Clock } from "lucide-react";

export default function Priere() {
  const { user } = useAuth();
  if (!user) return null;

  const userId = user.id;
  const [prieres, setPrieres] = useState(getMesPrieres(userId));
  const [editId, setEditId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState("");
  const [showNew, setShowNew] = useState(false);
  const [newContent, setNewContent] = useState("");
  const [autoSaved, setAutoSaved] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout>>(undefined);

  const reload = () => setPrieres(getMesPrieres(userId));

  // Auto-save avec debounce
  const handleEditChange = (text: string) => {
    setEditContent(text);
    setAutoSaved(false);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      if (editId && text.trim()) {
        savePriere(userId, text, editId);
        setAutoSaved(true);
        reload();
      }
    }, 1500);
  };

  const handleNewSave = () => {
    if (!newContent.trim()) return;
    savePriere(userId, newContent);
    setNewContent("");
    setShowNew(false);
    reload();
  };

  const handleDelete = (id: string) => {
    if (!confirm("Supprimer cette prière ? Cette action est irréversible.")) return;
    deletePriere(userId, id);
    if (editId === id) { setEditId(null); setEditContent(""); }
    reload();
  };

  const startEdit = (id: string, contenu: string) => {
    setEditId(id);
    setEditContent(contenu);
    setShowNew(false);
    setAutoSaved(false);
  };

  useEffect(() => {
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, []);

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <BookHeart className="text-mdc-gold" /> Mon Carnet de Prière
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Seul Dieu et toi pouvez lire ce carnet. 🔒 Chiffré AES-256.
          </p>
        </div>
        <Button onClick={() => { setShowNew(true); setEditId(null); }} variant="gold">
          <Plus size={16} /> Nouvelle prière
        </Button>
      </div>

      {/* Sécurité */}
      <Card className="p-3 bg-mdc-blue/5 dark:bg-mdc-blue/10 border-mdc-blue/20">
        <div className="flex items-start gap-2">
          <Shield size={14} className="text-mdc-blue mt-0.5" />
          <p className="text-xs text-slate-600 dark:text-slate-400">
            <strong>Chiffrement de bout en bout :</strong> Vos prières sont chiffrées avec AES-256
            avant d'être enregistrées. Même l'administrateur du système ne peut pas les lire.
            La clé est dérivée de votre compte unique.
          </p>
        </div>
      </Card>

      {/* Nouvelle prière */}
      {showNew && (
        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-3 flex items-center gap-2">
            <Lock size={14} className="text-mdc-gold" /> Nouvelle prière
          </h3>
          <textarea
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            placeholder="Seigneur, je te prie pour..."
            className="w-full h-40 p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-base resize-none focus:outline-none focus:ring-2 focus:ring-mdc-blue/40"
            autoFocus
          />
          <div className="flex gap-2 mt-3">
            <Button variant="ghost" onClick={() => setShowNew(false)} className="flex-1 min-h-[48px]">
              Annuler
            </Button>
            <Button onClick={handleNewSave} variant="gold" className="flex-1 min-h-[48px]">
              <Save size={14} /> Enregistrer (chiffré)
            </Button>
          </div>
        </Card>
      )}

      {/* Édition */}
      {editId && (
        <Card className="p-5 border-mdc-gold/30">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Lock size={14} className="text-mdc-gold" /> Modifier la prière
            </h3>
            {autoSaved && (
              <Badge color="green"><Save size={10} /> Sauvegardé</Badge>
            )}
          </div>
          <textarea
            value={editContent}
            onChange={(e) => handleEditChange(e.target.value)}
            className="w-full h-48 p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-base resize-none focus:outline-none focus:ring-2 focus:ring-mdc-gold/40"
          />
          <p className="text-xs text-slate-400 mt-2 italic">
            Auto-sauvegarde chiffrée toutes les 1.5 secondes.
          </p>
          <Button variant="ghost" onClick={() => setEditId(null)} className="mt-3 min-h-[48px]">
            Fermer l'éditeur
          </Button>
        </Card>
      )}

      {/* Liste des prières */}
      <div className="space-y-3">
        {prieres.length === 0 && !showNew ? (
          <Card className="p-10 text-center">
            <BookHeart size={40} className="mx-auto text-slate-300 dark:text-slate-600 mb-3" />
            <p className="text-slate-500 dark:text-slate-400">
              Votre carnet de prière est vide. Ajoutez votre première prière. 🙏
            </p>
          </Card>
        ) : (
          prieres.map((p) => (
            <div
              key={p.id}
              className={`p-4 cursor-pointer transition hover:shadow-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm ${editId === p.id ? "ring-2 ring-mdc-gold" : ""}`}
              onClick={() => startEdit(p.id, p.contenu)}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-900 dark:text-slate-100 line-clamp-3 whitespace-pre-line">
                    {p.contenu}
                  </p>
                  <div className="flex items-center gap-2 mt-2 text-xs text-slate-400">
                    <Clock size={11} />
                    {new Date(p.date).toLocaleString("fr-FR")}
                    <Lock size={11} className="ml-1 text-mdc-gold" /> Chiffré
                  </div>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); handleDelete(p.id); }}
                  className="p-2 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 text-red-500 flex-shrink-0"
                  title="Supprimer"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
