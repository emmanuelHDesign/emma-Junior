import { useMemo } from "react";
import { loadDB } from "../lib/data";
import { useAuth } from "../lib/auth";
import { StatCard, Card, Badge } from "../components/ui";
import { InstallApp } from "../components/InstallApp";
import { InstallQRCode } from "../components/InstallQRCode";
import { Users, UserPlus, Wallet, TrendingUp, Church, Network, Smartphone, QrCode } from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid
} from "recharts";

export default function Dashboard() {
  const { hasPermission, user } = useAuth();
  const db = loadDB();

  const stats = useMemo(() => {
    const membres = db.membres.filter((m) => !m.archived);
    const nouveaux = membres.filter((m) => m.statut === "Nouveau converti");
    const baptises = membres.filter((m) => m.statut === "Baptisé");
    const engages = membres.filter((m) => m.statut === "Engagé");

    // Croissance 6 derniers mois (simulée)
    const now = new Date();
    const croissance = Array.from({ length: 6 }).map((_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
      const month = d.toLocaleDateString("fr-FR", { month: "short" });
      const count = membres.filter((m) => new Date(m.dateIntegration) <= d).length
        + Math.floor(Math.random() * 15 + i * 8);
      return { mois: month, membres: Math.max(count, 20 + i * 12) };
    });

    const totalDimes = db.dimes.reduce((s, d) => s + d.montant, 0);
    const tauxPresence = db.membres.length > 0
      ? Math.round((db.presences.length / db.membres.length) * 100)
      : 0;

    return { membres, nouveaux, baptises, engages, croissance, totalDimes, tauxPresence };
  }, [db]);

  const parStatut = [
    { name: "Nouveau converti", value: stats.nouveaux.length, color: "#10B981" },
    { name: "Baptisé", value: stats.baptises.length, color: "#3B5FB5" },
    { name: "Engagé", value: stats.engages.length, color: "#D4AF37" },
  ];

  const parType = db.dimes.reduce((acc: Record<string, number>, d) => {
    acc[d.type] = (acc[d.type] || 0) + d.montant;
    return acc;
  }, {});
  const dataType = Object.entries(parType).map(([name, value]) => ({ name, value }));

  if (!hasPermission("voir_dashboard_pasteur")) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
          Bienvenue, {user?.nom} 👋
        </h1>
        <Card className="p-8 text-center">
          <p className="text-slate-600 dark:text-slate-400">
            Le tableau de bord complet est réservé au Pasteur et à l'Administrateur.
            Utilisez le menu latéral pour accéder aux modules autorisés.
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">
            Tableau de bord Pasteur
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Vue d'ensemble · MDC Douala · {new Date().toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
          </p>
        </div>
        <Badge color="gold">Ésaïe 61:1-3</Badge>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Membres actifs" value={stats.membres.length} icon={<Users size={20} />} color="blue" hint={`+${stats.nouveaux.length} ce mois`} />
        <StatCard label="Nouveaux convertis" value={stats.nouveaux.length} icon={<UserPlus size={20} />} color="green" hint="À discipeler" />
        <StatCard label="Taux de présence" value={`${stats.tauxPresence}%`} icon={<Church size={20} />} color="purple" hint="Culte dimanche" />
        <StatCard label="Dîmes & offrandes" value={`${stats.totalDimes.toLocaleString("fr-FR")} FCFA`} icon={<Wallet size={20} />} color="gold" hint="Ce mois" />
      </div>

      {/* Installation mobile via QR code */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Card className="p-5">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-11 h-11 rounded-xl bg-mdc-blue/10 dark:bg-mdc-blue/20 flex items-center justify-center">
              <Smartphone size={20} className="text-mdc-blue" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 dark:text-slate-100">Installer MDC sur téléphone</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Installez l'application sur Android ou iPhone pour un accès plus rapide depuis l'église ou à la maison.
              </p>
            </div>
          </div>
          <InstallApp />
        </Card>

        <div className="flex flex-col gap-4">
          <InstallQRCode />
          <Card className="p-4 bg-mdc-gold/10 border-mdc-gold/30">
            <div className="flex items-start gap-3">
              <QrCode size={18} className="text-mdc-gold-dark dark:text-mdc-gold mt-0.5" />
              <div>
                <p className="font-medium text-slate-900 dark:text-slate-100">Utilisation conseillée à l'église</p>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                  Imprimez ce QR code en format A3 et placez-le à l'entrée du temple de Bonapriso pour permettre aux membres d'installer facilement l'application avec l'appareil photo de leur téléphone.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Graphiques */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-1">Croissance des membres</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">6 derniers mois</p>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={stats.croissance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="mois" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Line type="monotone" dataKey="membres" stroke="#1E3A8A" strokeWidth={3} dot={{ fill: "#D4AF37", r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-1">Statut spirituel</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">Répartition</p>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={parStatut} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={(e) => `${e.value}`}>
                {parStatut.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1 mt-2">
            {parStatut.map((s) => (
              <div key={s.name} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: s.color }} />
                  {s.name}
                </span>
                <span className="font-medium text-slate-900 dark:text-slate-100">{s.value}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-1">Dîmes & offrandes par catégorie</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">Ce mois (FCFA)</p>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={dataType}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(v) => `${Number(v).toLocaleString("fr-FR")} FCFA`} />
              <Bar dataKey="value" fill="#D4AF37" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-4">Cellules actives</h3>
          <div className="space-y-3">
            {db.cellules.slice(0, 5).map((c) => {
              const nb = db.membres.filter((m) => m.celluleId === c.id && !m.archived).length;
              return (
                <div key={c.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-mdc-blue/10 dark:bg-mdc-blue/20 flex items-center justify-center">
                      <Network size={14} className="text-mdc-blue" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">{c.nom}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{c.zone}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-slate-900 dark:text-slate-100">{nb}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">membres</p>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Activité récente */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <TrendingUp size={16} /> Activité récente
          </h3>
        </div>
        <div className="space-y-2 text-sm">
          {[
            { icon: "💰", text: `${db.dimes.length} contributions enregistrées ce dimanche`, time: "Il y a 2h" },
            { icon: "✅", text: `${db.presences.length} présences marquées au culte`, time: "Il y a 3h" },
            { icon: "📱", text: `${db.messages.length} SMS/WhatsApp envoyés`, time: "Hier" },
            { icon: "🙏", text: `${stats.nouveaux.length} nouveaux convertis à accompagner`, time: "Ce mois" },
          ].map((a, i) => (
            <div key={i} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50">
              <span className="text-xl">{a.icon}</span>
              <div className="flex-1">
                <p className="text-slate-900 dark:text-slate-100">{a.text}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">{a.time}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
