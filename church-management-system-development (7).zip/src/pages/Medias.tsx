// V2.2 — Médias prédications (audio, vidéo, PDF) avec cache offline
import { useEffect, useState } from "react";
import { loadMedias, type Media } from "../lib/medias-data";
import { cacheMedia, getCachedIds } from "../lib/offline-cache";
import { Card, Badge } from "../components/ui";
import { Music, Video, FileText, Download, Play, Wifi, WifiOff, Headphones, Search } from "lucide-react";

type Tab = "audio" | "video" | "pdf";

export default function Medias() {
  const [tab, setTab] = useState<Tab>("audio");
  const [medias] = useState<Media[]>(loadMedias());
  const [cachedSet, setCachedSet] = useState<Set<string>>(new Set());
  const [playing, setPlaying] = useState<string | null>(null);
  const [q, setQ] = useState("");

  // Charger les IDs en cache
  useEffect(() => {
    getCachedIds().then((ids) => setCachedSet(new Set(ids)));
  }, []);

  const filtered = medias.filter((m) => {
    if (m.type !== tab) return false;
    if (q) return `${m.titre} ${m.pasteur}`.toLowerCase().includes(q.toLowerCase());
    return true;
  });

  const handleDownloadOffline = async (media: Media) => {
    // En production : fetch le vrai blob depuis Supabase Storage
    // Ici on simule avec un petit blob placeholder
    const blob = new Blob([`MDC Prédication: ${media.titre}`], { type: "text/plain" });
    await cacheMedia(media.id, blob);
    const ids = await getCachedIds();
    setCachedSet(new Set(ids));
  };

  const tabIcon = (t: Tab) => {
    if (t === "audio") return <Music size={14} />;
    if (t === "video") return <Video size={14} />;
    return <FileText size={14} />;
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Headphones className="text-mdc-gold" /> Médias & Prédications
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Écoutez, regardez et téléchargez les prédications pour écouter hors ligne
        </p>
      </div>

      {/* Onglets */}
      <div className="flex gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
        {(["audio", "video", "pdf"] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-md text-sm font-medium transition ${
              tab === t ? "bg-white dark:bg-slate-900 text-mdc-blue shadow" : "text-slate-600 dark:text-slate-400"
            }`}
          >
            {tabIcon(t)}
            {t === "audio" ? "Audio" : t === "video" ? "Vidéo" : "Notes PDF"}
            <Badge color="slate">{medias.filter((m) => m.type === t).length}</Badge>
          </button>
        ))}
      </div>

      {/* Recherche */}
      <div className="relative">
        <Search size={16} className="absolute left-3 top-3 text-slate-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Rechercher une prédication..."
          className="w-full pl-9 pr-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-mdc-blue/40"
        />
      </div>

      {/* Liste */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <Card className="p-10 text-center">
            <p className="text-slate-500">Aucune prédication dans cette catégorie.</p>
          </Card>
        ) : (
          filtered.map((m) => {
            const isOffline = cachedSet.has(m.id);
            return (
              <Card key={m.id} className="p-4">
                <div className="flex items-start gap-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    m.type === "audio" ? "bg-purple-100 dark:bg-purple-900/30" :
                    m.type === "video" ? "bg-red-100 dark:bg-red-900/30" :
                    "bg-blue-100 dark:bg-blue-900/30"
                  }`}>
                    {m.type === "audio" && <Music size={20} className="text-purple-600" />}
                    {m.type === "video" && <Video size={20} className="text-red-600" />}
                    {m.type === "pdf" && <FileText size={20} className="text-blue-600" />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-slate-900 dark:text-slate-100 truncate">{m.titre}</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400">{m.pasteur}</p>
                    <div className="flex flex-wrap items-center gap-2 mt-1">
                      <span className="text-xs text-slate-400">{new Date(m.dateCulte).toLocaleDateString("fr-FR")}</span>
                      {m.duree && <span className="text-xs text-slate-400">· {m.duree}</span>}
                      {m.taille && <span className="text-xs text-slate-400">· {m.taille}</span>}
                      {isOffline && (
                        <Badge color="green"><WifiOff size={10} className="inline" /> Hors ligne</Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col gap-1.5 flex-shrink-0">
                    {m.type === "audio" && (
                      <button
                        onClick={() => setPlaying(playing === m.id ? null : m.id)}
                        className="p-2.5 rounded-lg bg-mdc-blue text-white hover:bg-mdc-blue-dark transition"
                        title="Écouter"
                      >
                        <Play size={16} />
                      </button>
                    )}
                    <button
                      onClick={() => handleDownloadOffline(m)}
                      className={`p-2.5 rounded-lg transition ${
                        isOffline
                          ? "bg-green-100 dark:bg-green-900/30 text-green-600"
                          : "bg-slate-100 dark:bg-slate-800 text-slate-600 hover:bg-mdc-gold/20"
                      }`}
                      title={isOffline ? "Déjà téléchargé" : "Télécharger hors ligne"}
                    >
                      <Download size={16} />
                    </button>
                  </div>
                </div>

                {/* Player audio inline */}
                {playing === m.id && m.type === "audio" && (
                  <div className="mt-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                    <p className="text-xs text-slate-500 mb-2 italic">
                      En production : lecture depuis Supabase Storage
                    </p>
                    <audio controls className="w-full" autoPlay>
                      <source src={m.url} type="audio/mpeg" />
                      Votre navigateur ne supporte pas le lecteur audio.
                    </audio>
                  </div>
                )}
              </Card>
            );
          })
        )}
      </div>

      {/* Info offline */}
      <Card className="p-4 bg-blue-50 dark:bg-blue-900/10 border-blue-200 dark:border-blue-800">
        <div className="flex items-start gap-3">
          <Wifi size={18} className="text-blue-600 mt-0.5" />
          <div>
            <h3 className="font-semibold text-blue-900 dark:text-blue-100">Mode hors-ligne</h3>
            <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
              Téléchargez jusqu'à 5 audios et 5 PDF pour les écouter sans connexion internet.
              Idéal pour les zones avec réseau 3G faible à Douala.
            </p>
            <p className="text-xs text-blue-600 mt-2">
              {cachedSet.size} / 10 fichier{cachedSet.size > 1 ? "s" : ""} en cache
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
