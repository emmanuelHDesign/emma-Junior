// V2.1 — Cellules par quartier Douala avec WhatsApp berger
import { CELLULES_QUARTIERS } from "../lib/cellules-data";
import { Card, Badge } from "../components/ui";
import { MapPin, Calendar, Clock, MessageCircle, Phone, Users } from "lucide-react";

export default function CellulesQuartiers() {
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <MapPin className="text-mdc-gold" /> Cellules de maison · Douala
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Rejoignez une cellule près de chez vous. Contactez le berger directement via WhatsApp.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {CELLULES_QUARTIERS.map((c) => (
          <Card key={c.id} className="overflow-hidden">
            <div className="h-2" style={{ backgroundColor: c.couleur }} />
            <div className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-sm"
                    style={{ backgroundColor: c.couleur }}
                  >
                    {c.photo}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-slate-100">{c.nom}</h3>
                    <p className="text-sm text-slate-500 dark:text-slate-400">{c.berger}</p>
                  </div>
                </div>
                <Badge color="blue">{c.quartier}</Badge>
              </div>

              <div className="space-y-2 mb-4 text-sm text-slate-600 dark:text-slate-400">
                <p className="flex items-center gap-2">
                  <MapPin size={14} className="text-slate-400 flex-shrink-0" />
                  {c.adresse}
                </p>
                <p className="flex items-center gap-2">
                  <Calendar size={14} className="text-slate-400" />
                  {c.jour}
                  <Clock size={14} className="ml-2 text-slate-400" />
                  {c.heure}
                </p>
                <p className="flex items-center gap-2">
                  <Phone size={14} className="text-slate-400" />
                  {c.phone}
                </p>
              </div>

              <a
                href={`https://wa.me/${c.phone.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(
                  `Bonjour ${c.berger}, je suis intéressé(e) par la cellule "${c.nom}" dans le quartier ${c.quartier}. Comment puis-je vous rejoindre ? 🙏`
                )}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold text-sm transition min-h-[48px]"
              >
                <MessageCircle size={18} /> Contacter le Berger via WhatsApp
              </a>
            </div>
          </Card>
        ))}
      </div>

      <Card className="p-5 bg-mdc-gold/10 border-mdc-gold/30">
        <div className="flex items-start gap-3">
          <Users size={20} className="text-mdc-gold-dark dark:text-mdc-gold mt-0.5" />
          <div>
            <h3 className="font-semibold text-slate-900 dark:text-slate-100">Pas de cellule dans votre quartier ?</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              Contactez l'administration MDC pour ouvrir une nouvelle cellule dans votre zone.
            </p>
            <a
              href={`https://wa.me/237658842522?text=${encodeURIComponent(
                "Bonjour, je souhaite ouvrir une cellule de maison dans mon quartier. Merci !"
              )}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 mt-3 px-4 py-2 rounded-lg bg-green-600 hover:bg-green-700 text-white text-sm font-medium transition min-h-[44px]"
            >
              <MessageCircle size={14} /> WhatsApp Admin MDC
            </a>
          </div>
        </div>
      </Card>
    </div>
  );
}
