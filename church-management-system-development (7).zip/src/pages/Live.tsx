// V2.1 — Page Culte Live (YouTube / Facebook embed)
import { Card, Badge } from "../components/ui";
import { ModeCulteToggle } from "../components/ModeCulte";
import { PushConsent } from "../components/PushConsent";
import { Tv, ExternalLink, Clock, Calendar, MessageCircle } from "lucide-react";

export default function LivePage() {
  const now = new Date();
  const isDimanche = now.getDay() === 0;
  const isLiveHours = isDimanche && now.getHours() >= 8 && now.getHours() < 13;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <Tv className="text-red-500" /> Culte en direct
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Suivez les cultes de MDC en direct depuis Douala
          </p>
        </div>
        <div className="flex gap-2">
          <ModeCulteToggle />
          <PushConsent />
        </div>
      </div>

      {/* Statut du live */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            {isLiveHours ? (
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                <Badge color="red">EN DIRECT</Badge>
              </div>
            ) : (
              <Badge color="slate">Hors antenne</Badge>
            )}
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
            <Calendar size={14} /> Dimanche
            <Clock size={14} className="ml-1" /> 09h00 - 12h00
          </div>
        </div>

        {/* Embed vidéo */}
        <div className="relative w-full aspect-video bg-slate-900 rounded-xl overflow-hidden mb-4">
          {isLiveHours ? (
            <iframe
              src="https://www.youtube.com/embed/live_stream?channel=UC_MDC_CHANNEL"
              title="Culte MDC en direct"
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-white p-6 text-center">
              <Tv size={56} className="text-slate-600 mb-3" />
              <h3 className="text-lg font-bold mb-1">Le prochain culte sera diffusé dimanche à 09h00</h3>
              <p className="text-sm text-slate-400">Activez les rappels pour ne rien manquer.</p>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <a
            href="https://www.youtube.com/@mdceglise"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition min-h-[48px]"
          >
            <Tv size={18} /> YouTube MDC <ExternalLink size={14} />
          </a>
          <a
            href="https://www.facebook.com/mdceglise"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition min-h-[48px]"
          >
            📘 Facebook MDC <ExternalLink size={14} />
          </a>
        </div>
      </Card>

      {/* Prochains cultes */}
      <Card className="p-5">
        <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-3">Programme de la semaine</h3>
        <div className="space-y-3">
          {[
            { jour: "Dimanche", heure: "09h00 - 12h00", titre: "Culte dominical", lieu: "Temple MDC Bonapriso", live: true },
            { jour: "Mardi", heure: "18h00 - 19h30", titre: "Soirée de prière", lieu: "Temple MDC", live: false },
            { jour: "Mercredi - Jeudi", heure: "18h00 - 19h30", titre: "Cellules de maison", lieu: "Quartiers Douala", live: false },
            { jour: "Vendredi", heure: "18h00 - 20h00", titre: "Étude biblique", lieu: "Temple MDC", live: false },
          ].map((p, i) => (
            <div key={i} className="flex items-start gap-3 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
              <div className="w-10 h-10 rounded-lg bg-mdc-blue/10 dark:bg-mdc-blue/20 flex items-center justify-center flex-shrink-0">
                <Calendar size={16} className="text-mdc-blue" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-slate-900 dark:text-slate-100">{p.titre}</p>
                  {p.live && <Badge color="red">Live</Badge>}
                </div>
                <p className="text-sm text-slate-500 dark:text-slate-400">{p.jour} · {p.heure}</p>
                <p className="text-xs text-slate-400">{p.lieu}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* WhatsApp */}
      <Card className="p-5 bg-green-50 dark:bg-green-900/10 border-green-200 dark:border-green-800">
        <div className="flex items-start gap-3">
          <MessageCircle size={20} className="text-green-600 mt-0.5" />
          <div>
            <h3 className="font-semibold text-slate-900 dark:text-slate-100">Besoin de prière ?</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
              Envoyez votre sujet de prière à l'équipe d'intercession.
            </p>
            <a
              href={`https://wa.me/237658842522?text=${encodeURIComponent("Bonjour, j'ai un sujet de prière. 🙏")}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 mt-3 px-4 py-2 rounded-lg bg-green-600 hover:bg-green-700 text-white text-sm font-medium transition min-h-[44px]"
            >
              <MessageCircle size={14} /> WhatsApp Intercession
            </a>
          </div>
        </div>
      </Card>
    </div>
  );
}
