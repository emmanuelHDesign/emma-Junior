import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { loadDB, saveDB, uid } from "../lib/data";
import { Card, Button, Input, Label } from "../components/ui";
import { CheckCircle, AlertCircle, Loader2, Clock, Search, UserPlus, Church, Phone } from "lucide-react";

type Status = "idle" | "loading" | "success" | "already" | "error" | "visiteur";

export default function PublicScan() {
  const [searchParams] = useSearchParams();
  const culteId = searchParams.get("c");
  const preselectedMembreId = searchParams.get("m"); // QR individuel pré-sélectionne

  const [db] = useState(loadDB());
  const [status, setStatus] = useState<Status>("idle");
  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState("");
  const [message, setMessage] = useState("");
  const [heureArrivee, setHeureArrivee] = useState("");
  const [membreNom, setMembreNom] = useState("");

  // Mode visiteur (non membre)
  const [visiteurMode, setVisiteurMode] = useState(false);
  const [visiteurNom, setVisiteurNom] = useState("");
  const [visiteurPrenom, setVisiteurPrenom] = useState("");
  const [visiteurTel, setVisiteurTel] = useState("");

  const culte = useMemo(() => db.cultes.find((c) => c.id === culteId), [db, culteId]);

  // Auto-enregistrement si QR individuel (paramètre m= present)
  useEffect(() => {
    if (preselectedMembreId && culteId && culte && status === "idle") {
      const m = db.membres.find((x) => x.id === preselectedMembreId);
      if (m && !m.archived) {
        setSelectedId(m.id);
        // Enregistrement automatique après un court délai pour afficher l'UI
        const timer = setTimeout(() => {
          enregistrerPresence(m.id, `${m.prenom} ${m.nom}`);
        }, 500);
        return () => clearTimeout(timer);
      }
    }
  }, [preselectedMembreId, culteId, culte, status]); // eslint-disable-line react-hooks/exhaustive-deps

  const membresActifs = useMemo(
    () => db.membres.filter((m) => !m.archived),
    [db]
  );

  const filtered = useMemo(() => {
    if (!search.trim()) return membresActifs.slice(0, 10);
    const s = search.toLowerCase();
    return membresActifs.filter((m) =>
      `${m.nom} ${m.prenom} ${m.telephone}`.toLowerCase().includes(s)
    ).slice(0, 20);
  }, [search, membresActifs]);

  const enregistrerPresence = (membreId: string, membreNomComplet: string) => {
    if (!culteId || !culte) {
      setStatus("error");
      setMessage("Culte introuvable");
      return;
    }

    // Vérif doublon
    const deja = db.presences.find(
      (p) => p.culteId === culteId && p.membreId === membreId
    );

    const maintenant = new Date();
    const heure = maintenant.toTimeString().slice(0, 8);

    if (deja) {
      setStatus("already");
      setHeureArrivee(deja.heureArrivee || heure);
      setMembreNom(membreNomComplet);
      return;
    }

    const nouvellePresence = {
      id: uid("p"),
      membreId,
      type: culte.type,
      date: culte.date,
      culteId,
      heureArrivee: heure,
      methode: "self_scan" as const,
    };

    const newDB = { ...db, presences: [...db.presences, nouvellePresence] };
    saveDB(newDB);

    setStatus("success");
    setHeureArrivee(heure);
    setMembreNom(membreNomComplet);
  };

  const handleSelectMembre = () => {
    if (!selectedId) {
      alert("Veuillez sélectionner votre nom dans la liste.");
      return;
    }
    const m = db.membres.find((x) => x.id === selectedId);
    if (!m) return;
    enregistrerPresence(m.id, `${m.prenom} ${m.nom}`);
  };

  const handleVisiteur = () => {
    if (!visiteurNom.trim() || !visiteurPrenom.trim()) {
      alert("Veuillez saisir votre nom et prénom.");
      return;
    }
    if (!visiteurTel.trim()) {
      alert("Veuillez saisir votre numéro de téléphone.");
      return;
    }

    // Créer un nouveau membre "visiteur"
    const nouveauMembre = {
      id: uid("m"),
      nom: visiteurNom.trim(),
      prenom: visiteurPrenom.trim(),
      telephone: visiteurTel.trim(),
      statut: "Nouveau converti" as const,
      dateIntegration: new Date().toISOString().slice(0, 10),
      consentementPhoto: false,
      consentementSMS: true,
      archived: false,
    };

    const newDB = { ...db, membres: [...db.membres, nouveauMembre] };
    saveDB(newDB);

    enregistrerPresence(nouveauMembre.id, `${nouveauMembre.prenom} ${nouveauMembre.nom}`);
    setStatus("visiteur");
  };

  const reset = () => {
    setStatus("idle");
    setSearch("");
    setSelectedId("");
    setMessage("");
    setHeureArrivee("");
    setMembreNom("");
    setVisiteurMode(false);
    setVisiteurNom("");
    setVisiteurPrenom("");
    setVisiteurTel("");
  };

  // Erreur si culte invalide
  useEffect(() => {
    if (!culteId) {
      setStatus("error");
      setMessage("QR code invalide — ID du culte manquant");
    } else if (!culte) {
      setStatus("error");
      setMessage("Culte introuvable");
    }
  }, [culteId, culte]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-mdc-blue via-mdc-blue-dark to-slate-900 py-6 px-4">
      <div className="max-w-md mx-auto">
        {/* En-tête MDC */}
        <div className="text-center mb-6 text-white">
          <h1 className="text-2xl font-bold tracking-tight">MDC</h1>
          <p className="text-white/90 text-sm mt-1">Ministère des Déterminés pour Christ</p>
          <p className="text-white/70 text-xs mt-2 italic">"L'Esprit du Seigneur est sur moi" — Ésaïe 61:1-3</p>
        </div>

        {/* Info culte */}
        {culte && status === "idle" && (
          <Card className="mb-4 p-4 bg-mdc-gold/10 border-mdc-gold/30">
            <div className="flex items-center gap-3">
              <Church className="text-mdc-gold flex-shrink-0" />
              <div>
                <p className="text-xs text-slate-600 dark:text-slate-400">Culte du jour</p>
                <p className="font-bold text-slate-900 dark:text-slate-100">
                  {culte.type} — {new Date(culte.date).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* ===== ÉCRAN INITIAL : SÉLECTION MEMBRE ===== */}
        {status === "idle" && !visiteurMode && (
          <Card className="p-6">
            <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 mb-1">
              Enregistrez votre présence 🙏
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
              Recherchez votre nom ou inscrivez-vous comme visiteur
            </p>

            {/* Barre de recherche */}
            <div className="relative mb-3">
              <Search size={16} className="absolute left-3 top-3 text-slate-400" />
              <Input
                placeholder="Nom, prénom ou téléphone..."
                className="pl-9"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                autoFocus
              />
            </div>

            {/* Liste des membres */}
            <div className="max-h-64 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-lg divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.length === 0 ? (
                <p className="text-center text-slate-500 text-sm py-6">
                  Aucun membre trouvé
                </p>
              ) : (
                filtered.map((m) => {
                  const isSelected = selectedId === m.id;
                  const initials = `${m.prenom[0]}${m.nom[0]}`.toUpperCase();
                  return (
                    <button
                      key={m.id}
                      onClick={() => setSelectedId(m.id)}
                      className={`w-full flex items-center gap-3 p-3 text-left transition ${
                        isSelected
                          ? "bg-mdc-blue/10 dark:bg-mdc-blue/20 border-l-4 border-mdc-blue"
                          : "hover:bg-slate-50 dark:hover:bg-slate-800/50"
                      }`}
                    >
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-mdc-blue to-mdc-blue-dark text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                        {initials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-slate-900 dark:text-slate-100 truncate">
                          {m.prenom} {m.nom}
                        </p>
                        <p className="text-xs text-slate-500 truncate">{m.telephone}</p>
                      </div>
                      {isSelected && (
                        <CheckCircle size={20} className="text-mdc-blue flex-shrink-0" />
                      )}
                    </button>
                  );
                })
              )}
            </div>

            <Button
              onClick={handleSelectMembre}
              disabled={!selectedId}
              className="w-full mt-4"
            >
              <CheckCircle size={16} /> Enregistrer ma présence
            </Button>

            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700">
              <button
                onClick={() => setVisiteurMode(true)}
                className="w-full flex items-center justify-center gap-2 p-3 rounded-lg border-2 border-dashed border-mdc-gold text-mdc-gold hover:bg-mdc-gold/10 transition text-sm font-medium"
              >
                <UserPlus size={16} /> Je suis nouveau / visiteur
              </button>
            </div>
          </Card>
        )}

        {/* ===== MODE VISITEUR ===== */}
        {status === "idle" && visiteurMode && (
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <UserPlus className="text-mdc-gold" />
              <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                Inscription visiteur
              </h2>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
              Bienvenue à MDC ! Inscrivez-vous pour enregistrer votre présence
            </p>

            <div className="space-y-3">
              <div>
                <Label>Prénom *</Label>
                <Input
                  value={visiteurPrenom}
                  onChange={(e) => setVisiteurPrenom(e.target.value)}
                  placeholder="Ex: Jean"
                  autoFocus
                />
              </div>
              <div>
                <Label>Nom *</Label>
                <Input
                  value={visiteurNom}
                  onChange={(e) => setVisiteurNom(e.target.value)}
                  placeholder="Ex: Dupont"
                />
              </div>
              <div>
                <Label>Téléphone *</Label>
                <Input
                  type="tel"
                  value={visiteurTel}
                  onChange={(e) => setVisiteurTel(e.target.value)}
                  placeholder="+237 6XX XX XX XX"
                />
              </div>

              <Button onClick={handleVisiteur} className="w-full mt-2" variant="gold">
                <CheckCircle size={16} /> M'inscrire et enregistrer ma présence
              </Button>

              <button
                onClick={() => setVisiteurMode(false)}
                className="w-full text-sm text-slate-500 hover:text-mdc-blue"
              >
                ← Je suis déjà membre
              </button>
            </div>
          </Card>
        )}

        {/* ===== SUCCÈS ===== */}
        {(status === "success" || status === "visiteur") && (
          <Card className="p-8 text-center bg-gradient-to-br from-green-50 to-white dark:from-green-900/20 dark:to-slate-900 border-green-200 dark:border-green-800">
            <CheckCircle size={64} className="mx-auto text-green-600 mb-4" />
            <h2 className="text-2xl font-bold text-green-900 dark:text-green-100 mb-1">
              Bienvenue {status === "visiteur" ? "à MDC" : "au culte"} ! 🙏
            </h2>
            <p className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4">
              {membreNom}
            </p>
            <div className="inline-flex items-center gap-3 px-5 py-3 rounded-xl bg-white dark:bg-slate-900 shadow-lg border border-green-200 dark:border-green-800 mb-4">
              <Clock size={24} className="text-mdc-gold" />
              <div className="text-left">
                <p className="text-xs text-slate-500 uppercase tracking-wide">Heure d'arrivée</p>
                <p className="font-mono font-bold text-2xl text-slate-900 dark:text-slate-100">
                  {heureArrivee}
                </p>
              </div>
            </div>
            {status === "visiteur" && (
              <p className="text-sm text-slate-600 dark:text-slate-400 mb-4 bg-amber-50 dark:bg-amber-900/20 p-3 rounded-lg border border-amber-200 dark:border-amber-800">
                ✨ Votre profil a été créé. Un responsable MDC vous contactera bientôt pour vous accueillir !
              </p>
            )}
            <p className="text-sm text-slate-600 dark:text-slate-400 italic mb-4">
              Que le Seigneur vous bénisse abondamment !
            </p>
            <Button onClick={reset} variant="secondary">
              Enregistrer une autre personne
            </Button>
          </Card>
        )}

        {/* ===== DÉJÀ ENREGISTRÉ ===== */}
        {status === "already" && (
          <Card className="p-8 text-center bg-gradient-to-br from-amber-50 to-white dark:from-amber-900/20 dark:to-slate-900 border-amber-200 dark:border-amber-800">
            <AlertCircle size={64} className="mx-auto text-amber-600 mb-4" />
            <h2 className="text-xl font-bold text-amber-900 dark:text-amber-100 mb-2">
              Déjà enregistré
            </h2>
            <p className="text-lg font-semibold text-slate-900 dark:text-slate-100 mb-4">
              {membreNom}
            </p>
            <div className="inline-flex items-center gap-3 px-5 py-3 rounded-xl bg-white dark:bg-slate-900 shadow border border-amber-200 dark:border-amber-800 mb-4">
              <Clock size={24} className="text-mdc-gold" />
              <div className="text-left">
                <p className="text-xs text-slate-500 uppercase tracking-wide">Arrivé à</p>
                <p className="font-mono font-bold text-2xl text-slate-900 dark:text-slate-100">
                  {heureArrivee}
                </p>
              </div>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
              Votre présence a déjà été enregistrée pour ce culte
            </p>
            <Button onClick={reset} variant="secondary">
              Enregistrer une autre personne
            </Button>
          </Card>
        )}

        {/* ===== ERREUR ===== */}
        {status === "error" && (
          <Card className="p-8 text-center bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800">
            <AlertCircle size={64} className="mx-auto text-red-600 mb-4" />
            <h2 className="text-xl font-bold text-red-900 dark:text-red-100 mb-2">
              Erreur
            </h2>
            <p className="text-sm text-red-700 dark:text-red-300 mb-4">
              {message}
            </p>
            <Button onClick={reset} variant="secondary">
              Réessayer
            </Button>
          </Card>
        )}

        {/* ===== LOADING ===== */}
        {status === "loading" && (
          <Card className="p-8 text-center">
            <Loader2 size={64} className="mx-auto text-mdc-blue animate-spin mb-4" />
            <p className="text-slate-500">Enregistrement en cours...</p>
          </Card>
        )}

        {/* Footer */}
        <div className="text-center mt-6 text-white/60 text-xs">
          <p>MDC — Douala, Cameroun</p>
          <p className="mt-1 flex items-center justify-center gap-2">
            <Phone size={10} /> +237 6XX XX XX XX
          </p>
        </div>

        {/* Crédit développeur */}
        <div className="text-center mt-4 pt-3 border-t border-white/10">
          <p className="text-white/40 text-[10px] uppercase tracking-wider">Application développée par</p>
          <p className="text-mdc-gold font-semibold text-xs mt-0.5">
            Emmanuel Junior Bona
          </p>
          <p className="text-white/50 text-[10px]">Consultant Église Digitale</p>
        </div>
      </div>
    </div>
  );
}
