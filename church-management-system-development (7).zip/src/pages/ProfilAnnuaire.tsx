// V2.2 — Profil annuaire personnel (opt-in + photo + quartier)
import { useState } from "react";
import { useAuth } from "../lib/auth";
import { getMonProfil, saveMonProfil, type ProfilAnnuaire } from "../lib/annuaire-data";
import { Card, Button, Input, Label, Select } from "../components/ui";
import { User, Phone, MapPin, Shield, Save, CheckCircle, Eye, EyeOff } from "lucide-react";

const QUARTIERS = ["Bonapriso", "Akwa", "Bali", "Ndokoti", "PK14 - Bonabéri", "Bonamoussadi", "New-Bell", "Deïdo", "Makepe", "Logbessou", "Kotto", "Village"];

export default function ProfilAnnuaire() {
  const { user } = useAuth();
  if (!user) return null;

  const existing = getMonProfil(user.id);
  const [nom, setNom] = useState(existing?.nom || user.nom);
  const [whatsapp, setWhatsapp] = useState(existing?.whatsapp || user.telephone || "");
  const [quartier, setQuartier] = useState(existing?.quartier || "");
  const [visible, setVisible] = useState(existing?.visibleAnnuaire ?? false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    saveMonProfil(user.id, {
      nom,
      whatsapp,
      quartier,
      visibleAnnuaire: visible,
      role: (user.role === "PASTEUR" ? "PASTEUR" : user.role === "CHEF_CELLULE" ? "BERGER" : "MEMBRE") as ProfilAnnuaire["role"],
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <User className="text-mdc-gold" /> Mon profil annuaire
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Gérez votre visibilité dans l'annuaire des membres MDC
        </p>
      </div>

      {saved && (
        <div className="p-3 rounded-lg bg-green-50 dark:bg-green-900/20 text-green-800 dark:text-green-200 border border-green-200 flex items-center gap-2 text-sm">
          <CheckCircle size={16} /> Profil mis à jour avec succès !
        </div>
      )}

      <Card className="p-5 space-y-4">
        <div>
          <Label>Nom complet</Label>
          <Input value={nom} onChange={(e) => setNom(e.target.value)} />
        </div>

        <div>
          <Label>Numéro WhatsApp</Label>
          <div className="relative">
            <Phone size={16} className="absolute left-3 top-3 text-slate-400" />
            <Input
              type="tel"
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              placeholder="+237 6XX XX XX XX"
              className="pl-9"
            />
          </div>
        </div>

        <div>
          <Label>Quartier à Douala</Label>
          <div className="relative">
            <MapPin size={16} className="absolute left-3 top-3 text-slate-400" />
            <Select value={quartier} onChange={(e) => setQuartier(e.target.value)} className="pl-9">
              <option value="">Sélectionnez votre quartier</option>
              {QUARTIERS.map((q) => <option key={q}>{q}</option>)}
            </Select>
          </div>
        </div>

        <div className="p-4 rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-700">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              {visible ? <Eye size={20} className="text-green-600 mt-0.5" /> : <EyeOff size={20} className="text-slate-400 mt-0.5" />}
              <div>
                <p className="font-semibold text-slate-900 dark:text-slate-100">
                  Apparaître dans l'annuaire
                </p>
                <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                  {visible
                    ? "Votre nom, quartier et bouton WhatsApp seront visibles par les autres membres."
                    : "Vous êtes invisible dans l'annuaire. Aucun membre ne peut vous trouver."
                  }
                </p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer flex-shrink-0 ml-4">
              <input
                type="checkbox"
                checked={visible}
                onChange={(e) => setVisible(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-300 dark:bg-slate-700 rounded-full peer peer-checked:bg-green-600 peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
            </label>
          </div>
        </div>

        <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
          <div className="flex items-start gap-2">
            <Shield size={14} className="text-mdc-blue mt-0.5" />
            <p className="text-xs text-slate-500 dark:text-slate-400">
              <strong>RGPD :</strong> Votre numéro WhatsApp et votre quartier ne seront visibles
              que si vous activez l'option ci-dessus. Vous pouvez la désactiver à tout moment.
            </p>
          </div>
        </div>

        <Button onClick={handleSave} className="w-full min-h-[48px]">
          <Save size={16} /> Enregistrer mon profil
        </Button>
      </Card>
    </div>
  );
}
