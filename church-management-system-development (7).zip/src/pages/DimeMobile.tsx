// V2.1 — Module Dîme Mobile Money (MTN MoMo / Orange Money)
import { useState } from "react";
import { useAuth } from "../lib/auth";
import { enregistrerDon, loadDons, type TypeDon, type ReseauMomo, type DonMobileMoney } from "../lib/dime-data";
import { Card, Button, Input, Label, Badge } from "../components/ui";
import { Wallet, Phone, CreditCard, Download, CheckCircle, AlertCircle, History } from "lucide-react";

export default function DimeMobile() {
  const { user } = useAuth();
  const [dons, setDons] = useState<DonMobileMoney[]>(loadDons());

  // Formulaire
  const [type, setType] = useState<TypeDon>("Dîme");
  const [montant, setMontant] = useState("");
  const [reseau, setReseau] = useState<ReseauMomo>("MTN Mobile Money");
  const [telephone, setTelephone] = useState(user?.telephone || "");
  const [step, setStep] = useState<"form" | "confirm" | "success" | "error">("form");
  const [lastDon, setLastDon] = useState<DonMobileMoney | null>(null);
  const [erreur, setErreur] = useState("");

  // Tab
  const [tab, setTab] = useState<"payer" | "historique">("payer");

  const handleSubmit = () => {
    setErreur("");
    const m = parseInt(montant);
    if (isNaN(m) || m < 500) {
      setErreur("Montant minimum : 500 FCFA");
      return;
    }
    if (!telephone.trim() || telephone.length < 9) {
      setErreur("Numéro de téléphone invalide");
      return;
    }
    setStep("confirm");
  };

  const handleConfirm = () => {
    if (!user) return;
    const don = enregistrerDon({
      userId: user.id,
      membreNom: user.nom,
      type,
      montant: parseInt(montant),
      reseau,
      telephone: telephone.trim(),
    });
    setLastDon(don);
    setDons(loadDons());
    setStep("success");
    setMontant("");
  };

  const genererRecu = async (don: DonMobileMoney) => {
    const { jsPDF } = await import("jspdf");
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.setTextColor(30, 58, 138);
    doc.text("MDC - Ministère des Déterminés pour Christ", 105, 25, { align: "center" });
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text("Douala, Cameroun · Ésaïe 61:1-3", 105, 33, { align: "center" });
    doc.setDrawColor(212, 175, 55);
    doc.setLineWidth(1);
    doc.line(20, 38, 190, 38);

    doc.setFontSize(16);
    doc.setTextColor(0);
    doc.text(`REÇU DE ${don.type.toUpperCase()}`, 105, 52, { align: "center" });

    doc.setFontSize(12);
    doc.text(`Réf: ${don.reference}`, 20, 65);
    doc.text(`Date: ${new Date(don.date).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}`, 20, 73);
    doc.text(`Nom: ${don.membreNom}`, 20, 81);
    doc.text(`Téléphone: ${don.telephone}`, 20, 89);

    doc.setFontSize(14);
    doc.setTextColor(212, 175, 55);
    doc.text(`Montant: ${don.montant.toLocaleString("fr-FR")} FCFA`, 20, 102);

    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text(`Mode: ${don.reseau}`, 20, 113);
    doc.text(`Statut: ${don.statut === "succès" ? "Payé ✓" : don.statut}`, 20, 121);

    doc.setDrawColor(212, 175, 55);
    doc.line(20, 130, 190, 130);

    doc.setFontSize(10);
    doc.setTextColor(100);
    doc.text("L'Esprit du Seigneur est sur moi... - Ésaïe 61:1", 105, 140, { align: "center" });
    doc.text("Que le Seigneur vous bénisse ! 🙏", 105, 148, { align: "center" });
    doc.text("Développé par Emmanuel Junior Bona - Consultant Église Digitale", 105, 160, { align: "center" });

    doc.save(`recu-${don.reference}.pdf`);
  };

  const mesDons = user ? dons.filter((d) => d.userId === user.id) : [];

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Wallet className="text-mdc-gold" /> Dîme & Offrande Mobile Money
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Payez votre dîme ou offrande via MTN MoMo ou Orange Money
        </p>
      </div>

      {/* Onglets */}
      <div className="flex gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
        <button
          onClick={() => { setTab("payer"); setStep("form"); }}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition ${
            tab === "payer" ? "bg-white dark:bg-slate-900 text-mdc-blue shadow" : "text-slate-600 dark:text-slate-400"
          }`}
        >
          <CreditCard size={14} className="inline mr-1.5" /> Payer
        </button>
        <button
          onClick={() => setTab("historique")}
          className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition ${
            tab === "historique" ? "bg-white dark:bg-slate-900 text-mdc-blue shadow" : "text-slate-600 dark:text-slate-400"
          }`}
        >
          <History size={14} className="inline mr-1.5" /> Historique ({mesDons.length})
        </button>
      </div>

      {tab === "payer" && (
        <>
          {/* Formulaire */}
          {step === "form" && (
            <Card className="p-5 space-y-4">
              <div>
                <Label>Type de contribution</Label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  {(["Dîme", "Offrande", "Action de grâce"] as TypeDon[]).map((t) => (
                    <button
                      key={t}
                      onClick={() => setType(t)}
                      className={`p-3 rounded-xl text-sm font-medium border-2 transition min-h-[48px] ${
                        type === t
                          ? "border-mdc-blue bg-mdc-blue/5 text-mdc-blue dark:text-blue-300"
                          : "border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-slate-300"
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label>Montant (FCFA) — minimum 500</Label>
                <div className="relative">
                  <Input
                    type="number"
                    value={montant}
                    onChange={(e) => setMontant(e.target.value)}
                    placeholder="Ex: 10000"
                    min={500}
                    className="text-lg font-bold pl-4 pr-16"
                  />
                  <span className="absolute right-3 top-2.5 text-sm text-slate-400 font-medium">FCFA</span>
                </div>
                <div className="flex gap-2 mt-2">
                  {[5000, 10000, 25000, 50000].map((v) => (
                    <button
                      key={v}
                      onClick={() => setMontant(String(v))}
                      className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-mdc-gold/20 text-slate-700 dark:text-slate-300 transition"
                    >
                      {v.toLocaleString("fr-FR")}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label>Réseau Mobile Money</Label>
                <div className="grid grid-cols-2 gap-2 mt-1">
                  {([
                    { label: "MTN MoMo", value: "MTN Mobile Money" as ReseauMomo, color: "#FFC107", textColor: "#000" },
                    { label: "Orange Money", value: "Orange Money" as ReseauMomo, color: "#FF6600", textColor: "#fff" },
                  ]).map((r) => (
                    <button
                      key={r.value}
                      onClick={() => setReseau(r.value)}
                      className={`p-3 rounded-xl font-bold text-sm border-2 transition min-h-[48px] ${
                        reseau === r.value
                          ? "border-mdc-blue shadow-md"
                          : "border-slate-200 dark:border-slate-700"
                      }`}
                      style={{
                        backgroundColor: reseau === r.value ? r.color : undefined,
                        color: reseau === r.value ? r.textColor : undefined,
                      }}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <Label>Numéro de téléphone</Label>
                <div className="relative">
                  <Phone size={16} className="absolute left-3 top-3 text-slate-400" />
                  <Input
                    type="tel"
                    value={telephone}
                    onChange={(e) => setTelephone(e.target.value)}
                    placeholder="+237 6XX XX XX XX"
                    className="pl-9"
                  />
                </div>
              </div>

              {erreur && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle size={14} /> {erreur}
                </p>
              )}

              <Button onClick={handleSubmit} variant="gold" className="w-full min-h-[52px] text-base">
                <CreditCard size={18} /> Procéder au paiement
              </Button>

              <p className="text-xs text-slate-400 text-center">
                🔒 Paiement sécurisé · Aucune donnée bancaire stockée · Reçu PDF automatique
              </p>
            </Card>
          )}

          {/* Confirmation */}
          {step === "confirm" && (
            <Card className="p-5 space-y-4">
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 text-center">Confirmer le paiement</h3>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-slate-500">Type</span><span className="font-medium text-slate-900 dark:text-slate-100">{type}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Montant</span><span className="font-bold text-lg text-mdc-gold">{parseInt(montant).toLocaleString("fr-FR")} FCFA</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Réseau</span><span className="font-medium text-slate-900 dark:text-slate-100">{reseau}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">Téléphone</span><span className="font-medium text-slate-900 dark:text-slate-100">{telephone}</span></div>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" onClick={() => setStep("form")} className="flex-1 min-h-[48px]">Modifier</Button>
                <Button variant="gold" onClick={handleConfirm} className="flex-1 min-h-[48px]">Confirmer</Button>
              </div>
            </Card>
          )}

          {/* Succès */}
          {step === "success" && lastDon && (
            <Card className="p-6 text-center space-y-4 bg-green-50 dark:bg-green-900/10 border-green-200 dark:border-green-800">
              <CheckCircle size={56} className="mx-auto text-green-600" />
              <h3 className="text-xl font-bold text-green-900 dark:text-green-100">Paiement reçu ! 🙏</h3>
              <p className="text-sm text-green-700 dark:text-green-300">
                Merci pour votre {lastDon.type.toLowerCase()} de <strong>{lastDon.montant.toLocaleString("fr-FR")} FCFA</strong>.
              </p>
              <p className="text-xs text-green-600">Référence : {lastDon.reference}</p>
              <p className="text-sm italic text-mdc-gold">
                "L'Esprit du Seigneur est sur moi…" — Ésaïe 61:1
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => genererRecu(lastDon)} className="flex-1 min-h-[48px]">
                  <Download size={14} /> Reçu PDF
                </Button>
                <Button onClick={() => setStep("form")} className="flex-1 min-h-[48px]">
                  Nouveau don
                </Button>
              </div>
            </Card>
          )}
        </>
      )}

      {/* Historique */}
      {tab === "historique" && (
        <Card className="overflow-hidden">
          {mesDons.length === 0 ? (
            <p className="text-center text-slate-500 py-10">Aucune contribution enregistrée.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 dark:bg-slate-800/50 text-xs uppercase text-slate-500">
                  <tr>
                    <th className="text-left px-4 py-3">Date</th>
                    <th className="text-left px-4 py-3">Type</th>
                    <th className="text-right px-4 py-3">Montant</th>
                    <th className="text-left px-4 py-3 hidden sm:table-cell">Réseau</th>
                    <th className="text-left px-4 py-3">Statut</th>
                    <th className="text-right px-4 py-3">Reçu</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {mesDons.map((d) => (
                    <tr key={d.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30">
                      <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{new Date(d.date).toLocaleDateString("fr-FR")}</td>
                      <td className="px-4 py-3"><Badge color={d.type === "Dîme" ? "gold" : "blue"}>{d.type}</Badge></td>
                      <td className="px-4 py-3 text-right font-semibold text-slate-900 dark:text-slate-100">{d.montant.toLocaleString("fr-FR")}</td>
                      <td className="px-4 py-3 hidden sm:table-cell text-xs text-slate-500">{d.reseau}</td>
                      <td className="px-4 py-3"><Badge color={d.statut === "succès" ? "green" : "red"}>{d.statut}</Badge></td>
                      <td className="px-4 py-3 text-right">
                        <button onClick={() => genererRecu(d)} className="text-mdc-blue hover:underline text-xs"><Download size={12} className="inline" /> PDF</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
