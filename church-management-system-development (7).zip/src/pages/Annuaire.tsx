// V2.2 — Annuaire membres opt-in avec WhatsApp
import { useState } from "react";
import { getProfilsVisibles, type ProfilAnnuaire } from "../lib/annuaire-data";
import { Card, Badge, Input } from "../components/ui";
import { Users, Search, MessageCircle, MapPin } from "lucide-react";

export default function Annuaire() {
  const [q, setQ] = useState("");
  const profils = getProfilsVisibles();

  const filtered = q
    ? profils.filter((p) => `${p.nom} ${p.quartier}`.toLowerCase().includes(q.toLowerCase()))
    : profils;

  const roleBadge = (role: ProfilAnnuaire["role"]) => {
    if (role === "PASTEUR") return <Badge color="gold">Pasteur</Badge>;
    if (role === "BERGER") return <Badge color="blue">Berger</Badge>;
    return <Badge color="slate">Membre</Badge>;
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
          <Users className="text-mdc-gold" /> Annuaire MDC
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          {profils.length} membre{profils.length > 1 ? "s" : ""} visibles · Inscription opt-in uniquement
        </p>
      </div>

      <div className="relative">
        <Search size={16} className="absolute left-3 top-3 text-slate-400" />
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Rechercher par nom ou quartier..."
          className="pl-9"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((p) => {
          const initials = p.nom.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
          return (
            <Card key={p.id} className="p-5">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-mdc-blue to-mdc-blue-dark text-white flex items-center justify-center text-lg font-bold flex-shrink-0">
                  {initials}
                </div>
                <div className="min-w-0 flex-1">
                  <h3 className="font-bold text-slate-900 dark:text-slate-100 truncate">{p.nom}</h3>
                  {roleBadge(p.role)}
                  <p className="text-sm text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-1">
                    <MapPin size={12} /> {p.quartier}
                  </p>
                </div>
              </div>
              <a
                href={`https://wa.me/${p.whatsapp.replace(/[^0-9]/g, "")}?text=${encodeURIComponent(`Shalom ${p.nom.split(" ")[0]} de MDC ! 🙏`)}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-center gap-2 w-full py-3 rounded-xl bg-green-600 hover:bg-green-700 text-white font-semibold text-sm transition min-h-[48px]"
              >
                <MessageCircle size={16} /> Contacter via WhatsApp
              </a>
            </Card>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <Card className="p-10 text-center">
          <p className="text-slate-500">Aucun membre trouvé.</p>
        </Card>
      )}

      <Card className="p-4 bg-amber-50 dark:bg-amber-900/10 border-amber-200 dark:border-amber-800">
        <p className="text-sm text-amber-800 dark:text-amber-200">
          <strong>RGPD :</strong> Seuls les membres ayant activé l'option "Apparaître dans l'annuaire"
          dans leur profil sont listés ici. Par défaut, tout profil est caché.
        </p>
      </Card>
    </div>
  );
}
