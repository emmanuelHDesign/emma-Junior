import { useState } from "react";
import { loadDB, saveDB, uid, type Evenement } from "../lib/data";
import { useAuth } from "../lib/auth";
import { Card, Button, Input, Label, Select, Badge, Modal, Textarea } from "../components/ui";
import { Calendar, Plus, MapPin, Users, Wallet, Edit2 } from "lucide-react";

export default function Events() {
  const { hasPermission } = useAuth();
  const [db, setDB] = useState(loadDB());
  const [edit, setEdit] = useState<Evenement | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [inscriptions, setInscriptions] = useState<string | null>(null);

  const canManage = hasPermission("gerer_evenements");

  const save = (evenements: Evenement[]) => {
    const newDB = { ...db, evenements };
    saveDB(newDB); setDB(newDB);
  };

  const handleSave = (e: Evenement) => {
    const exists = db.evenements.find((x) => x.id === e.id);
    const next = exists ? db.evenements.map((x) => (x.id === e.id ? e : x)) : [...db.evenements, { ...e, id: uid("e") }];
    save(next);
    setEdit(null); setShowAdd(false);
  };

  const toggleParticipant = (eventId: string, memberId: string) => {
    save(db.evenements.map((e) => {
      if (e.id !== eventId) return e;
      const has = e.participants.includes(memberId);
      return { ...e, participants: has ? e.participants.filter((id) => id !== memberId) : [...e.participants, memberId] };
    }));
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">Événements</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">Camps, séminaires, conférences, mariages</p>
        </div>
        {canManage && <Button onClick={() => setShowAdd(true)}><Plus size={16} /> Nouvel événement</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {db.evenements.map((e) => {
          const dateDebut = new Date(e.dateDebut);
          const totalBudget = e.budget;
          return (
            <Card key={e.id} className="overflow-hidden">
              <div className="h-2 bg-gradient-to-r from-mdc-blue to-mdc-gold" />
              <div className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-lg bg-mdc-gold/20 flex flex-col items-center justify-center">
                      <span className="text-xs font-bold text-mdc-gold-dark dark:text-mdc-gold uppercase">
                        {dateDebut.toLocaleDateString("fr-FR", { month: "short" })}
                      </span>
                      <span className="text-lg font-bold text-mdc-blue dark:text-mdc-blue-light leading-none">
                        {dateDebut.getDate()}
                      </span>
                    </div>
                    <div>
                      <Badge color="blue">{e.type}</Badge>
                      <h3 className="font-bold text-slate-900 dark:text-slate-100 mt-1">{e.nom}</h3>
                    </div>
                  </div>
                </div>

                <div className="space-y-1.5 text-sm text-slate-600 dark:text-slate-400 mb-4">
                  <p className="flex items-center gap-2"><Calendar size={14} /> {new Date(e.dateDebut).toLocaleDateString("fr-FR")} → {new Date(e.dateFin).toLocaleDateString("fr-FR")}</p>
                  <p className="flex items-center gap-2"><MapPin size={14} /> {e.lieu}</p>
                  <p className="flex items-center gap-2"><Users size={14} /> {e.participants.length} inscrit(s)</p>
                  <p className="flex items-center gap-2"><Wallet size={14} /> Budget : {totalBudget.toLocaleString("fr-FR")} FCFA</p>
                </div>

                <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">{e.description}</p>

                <div className="flex gap-2">
                  <Button variant="secondary" onClick={() => setInscriptions(e.id)} className="flex-1">
                    <Users size={14} /> Inscriptions
                  </Button>
                  {canManage && (
                    <button onClick={() => setEdit(e)} className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800">
                      <Edit2 size={14} />
                    </button>
                  )}
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {(showAdd || edit) && <EventForm initial={edit} onClose={() => { setEdit(null); setShowAdd(false); }} onSave={handleSave} />}
      {inscriptions && (
        <InscriptionsModal
          eventId={inscriptions}
          db={db}
          onClose={() => setInscriptions(null)}
          onToggle={(mId) => toggleParticipant(inscriptions, mId)}
        />
      )}
    </div>
  );
}

function EventForm({ initial, onClose, onSave }: {
  initial: Evenement | null;
  onClose: () => void;
  onSave: (e: Evenement) => void;
}) {
  const [e, setE] = useState<Evenement>(initial ?? {
    id: "", nom: "", type: "Séminaire", dateDebut: new Date().toISOString().slice(0, 10),
    dateFin: new Date().toISOString().slice(0, 10), lieu: "", budget: 0, participants: [], description: ""
  });
  const update = <K extends keyof Evenement>(k: K, v: Evenement[K]) => setE({ ...e, [k]: v });
  return (
    <Modal open onClose={onClose} title={initial ? "Modifier l'événement" : "Nouvel événement"} maxWidth="lg">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="md:col-span-2"><Label>Nom *</Label><Input value={e.nom} onChange={(ev) => update("nom", ev.target.value)} /></div>
        <div><Label>Type</Label>
          <Select value={e.type} onChange={(ev) => update("type", ev.target.value as Evenement["type"])}>
            {["Camp", "Séminaire", "Mariage", "Conférence", "Retraite"].map((t) => <option key={t}>{t}</option>)}
          </Select>
        </div>
        <div><Label>Budget (FCFA)</Label><Input type="number" value={e.budget} onChange={(ev) => update("budget", +ev.target.value)} /></div>
        <div><Label>Date début</Label><Input type="date" value={e.dateDebut} onChange={(ev) => update("dateDebut", ev.target.value)} /></div>
        <div><Label>Date fin</Label><Input type="date" value={e.dateFin} onChange={(ev) => update("dateFin", ev.target.value)} /></div>
        <div className="md:col-span-2"><Label>Lieu</Label><Input value={e.lieu} onChange={(ev) => update("lieu", ev.target.value)} /></div>
        <div className="md:col-span-2"><Label>Description</Label><Textarea rows={3} value={e.description} onChange={(ev) => update("description", ev.target.value)} /></div>
      </div>
      <div className="flex justify-end gap-2 mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
        <Button variant="ghost" onClick={onClose}>Annuler</Button>
        <Button onClick={() => {
          if (!e.nom.trim()) { alert("Nom requis."); return; }
          onSave(e);
        }}>Enregistrer</Button>
      </div>
    </Modal>
  );
}

function InscriptionsModal({ eventId, db, onClose, onToggle }: {
  eventId: string;
  db: ReturnType<typeof loadDB>;
  onClose: () => void;
  onToggle: (memberId: string) => void;
}) {
  const e = db.evenements.find((x) => x.id === eventId)!;
  const participants = new Set(e.participants);
  return (
    <Modal open onClose={onClose} title={`Inscriptions — ${e.nom}`} maxWidth="lg">
      <p className="text-sm text-slate-500 mb-3">Cochez les membres inscrits ({participants.size} au total).</p>
      <div className="max-h-96 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 border rounded-lg">
        {db.membres.filter((m) => !m.archived).map((m) => (
          <label key={m.id} className="flex items-center gap-3 p-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer">
            <input type="checkbox" checked={participants.has(m.id)} onChange={() => onToggle(m.id)} className="rounded" />
            <div className="flex-1 min-w-0">
              <p className="font-medium text-slate-900 dark:text-slate-100 truncate">{m.prenom} {m.nom}</p>
              <p className="text-xs text-slate-500 truncate">{m.telephone}</p>
            </div>
          </label>
        ))}
      </div>
      <div className="flex justify-end mt-4">
        <Button onClick={onClose}>Fermer</Button>
      </div>
    </Modal>
  );
}
