import { InstallApp } from "../components/InstallApp";
import { Card, Badge } from "../components/ui";
import { Smartphone, WifiLow, DownloadCloud, Church } from "lucide-react";

export default function InstallerPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-mdc-blue via-mdc-blue-dark to-slate-900 px-4 py-8">
      <div className="max-w-lg mx-auto space-y-4">
        <div className="text-center text-white pt-4">
          <Badge color="gold">Installation rapide</Badge>
          <h1 className="text-3xl font-bold mt-3">MDC Église</h1>
          <p className="text-white/80 mt-2 text-base">
            Installez l'application sur votre téléphone en quelques secondes.
          </p>
        </div>

        <Card className="p-6">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-mdc-blue/10 dark:bg-mdc-blue/20 flex items-center justify-center">
              <DownloadCloud size={22} className="text-mdc-blue" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-slate-100">Installer MDC Église</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                L'application fonctionne bien sur Android et iPhone, même avec une connexion 3G faible à Douala.
              </p>
            </div>
          </div>

          <InstallApp />
        </Card>

        <Card className="p-5">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-3">Pourquoi installer l'application ?</h3>
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-3">
              <Smartphone size={18} className="text-mdc-blue mt-0.5" />
              <div>
                <p className="font-medium text-slate-900 dark:text-slate-100">Accès direct depuis l'écran d'accueil</p>
                <p className="text-slate-500 dark:text-slate-400">Ouvrez MDC comme une vraie application, sans passer par le navigateur.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <WifiLow size={18} className="text-mdc-blue mt-0.5" />
              <div>
                <p className="font-medium text-slate-900 dark:text-slate-100">Optimisée pour réseau faible</p>
                <p className="text-slate-500 dark:text-slate-400">Chargement plus rapide et expérience plus fluide pour les membres au Cameroun.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Church size={18} className="text-mdc-blue mt-0.5" />
              <div>
                <p className="font-medium text-slate-900 dark:text-slate-100">Tous les services MDC</p>
                <p className="text-slate-500 dark:text-slate-400">Présences, cellules, dîmes, annonces, communication et vie d'église au même endroit.</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
