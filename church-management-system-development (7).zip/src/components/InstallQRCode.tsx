import { useMemo } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Card, Button } from "./ui";
import { Download, QrCode, Smartphone } from "lucide-react";

export function InstallQRCode() {
  const installUrl = useMemo(() => {
    if (typeof window === "undefined") return "https://mdc-eglise.com/installer";
    return `${window.location.origin}/installer`;
  }, []);

  const handleDownload = () => {
    const svg = document.getElementById("mdc-install-qr");
    if (!svg) return;
    const data = new XMLSerializer().serializeToString(svg);
    const blob = new Blob([data], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "qr-installation-mdc-eglise.svg";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card className="p-5">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-11 h-11 rounded-xl bg-mdc-gold/10 dark:bg-mdc-gold/20 flex items-center justify-center">
          <QrCode size={20} className="text-mdc-gold-dark dark:text-mdc-gold" />
        </div>
        <div>
          <h3 className="font-semibold text-slate-900 dark:text-slate-100">QR Code d'installation</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Scannez avec l'appareil photo du téléphone pour ouvrir directement la page d'installation.
          </p>
        </div>
      </div>

      <div className="flex flex-col items-center gap-4">
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200">
          <QRCodeSVG
            id="mdc-install-qr"
            value={installUrl}
            size={220}
            includeMargin
            level="H"
            fgColor="#1E3A8A"
            bgColor="#FFFFFF"
          />
        </div>

        <div className="text-center">
          <p className="text-sm font-medium text-slate-900 dark:text-slate-100">Lien encodé</p>
          <p className="text-xs text-slate-500 dark:text-slate-400 break-all max-w-xs">{installUrl}</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full">
          <Button onClick={handleDownload} variant="secondary" className="min-h-12">
            <Download size={16} /> Télécharger le QR
          </Button>
          <a
            href={installUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center justify-center gap-2 min-h-12 px-4 py-2 rounded-lg text-sm font-medium bg-mdc-blue hover:bg-mdc-blue-dark text-white shadow-sm transition"
          >
            <Smartphone size={16} /> Ouvrir le lien
          </a>
        </div>
      </div>
    </Card>
  );
}
