// V2.1 — Modal RGPD consentement notifications push
import { useState } from "react";
import { useAppStore } from "../lib/store";
import { Button, Modal } from "./ui";
import { Bell, BellOff, Shield } from "lucide-react";

export function PushConsent() {
  const { pushEnabled, setPushEnabled } = useAppStore();
  const [showModal, setShowModal] = useState(false);
  const [status, setStatus] = useState<"idle" | "granted" | "denied">("idle");

  const requestPush = async () => {
    if (!("Notification" in window)) {
      setStatus("denied");
      return;
    }

    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      setPushEnabled(true);
      setStatus("granted");

      // Enregistrer la subscription push dans le service worker
      if ("serviceWorker" in navigator) {
        const registration = await navigator.serviceWorker.ready;
        const subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: "BDummyKeyForDemo_ReplaceWithVAPIDPublicKey",
        }).catch(() => null);

        if (subscription) {
          // En production : envoyer à /api/push/subscribe
          console.log("Push subscription:", JSON.stringify(subscription));
        }
      }

      // Notification de bienvenue
      new Notification("MDC Église", {
        body: "Rappels de culte activés ! Soyez béni(e) 🙏",
        icon: "/icon-512.png",
      });
    } else {
      setStatus("denied");
    }
    setShowModal(false);
  };

  if (pushEnabled) {
    return (
      <div className="flex items-center gap-2 text-sm text-green-700 dark:text-green-300">
        <Bell size={14} /> Rappels de culte activés
      </div>
    );
  }

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-100 dark:hover:bg-amber-900/30 transition"
      >
        <BellOff size={14} /> Activer les rappels
      </button>

      <Modal open={showModal} onClose={() => setShowModal(false)} title="Rappels de culte">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-mdc-blue/10 flex items-center justify-center flex-shrink-0">
              <Bell size={20} className="text-mdc-blue" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900 dark:text-slate-100">
                Recevoir les notifications MDC ?
              </h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                Vous recevrez des rappels avant chaque culte, les annonces importantes et les messages du pasteur.
              </p>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <div className="flex items-start gap-2">
              <Shield size={14} className="text-mdc-blue mt-0.5" />
              <p className="text-xs text-slate-600 dark:text-slate-400">
                <strong>RGPD :</strong> Vos données restent sur votre appareil.
                Vous pouvez désactiver les notifications à tout moment dans les paramètres de votre navigateur.
                Aucune information personnelle n'est partagée avec des tiers.
              </p>
            </div>
          </div>

          {status === "denied" && (
            <p className="text-sm text-red-600">
              Les notifications ont été refusées. Autorisez-les dans les paramètres de votre navigateur.
            </p>
          )}

          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => setShowModal(false)} className="flex-1">
              Plus tard
            </Button>
            <Button onClick={requestPush} variant="gold" className="flex-1">
              <Bell size={14} /> Oui, activer
            </Button>
          </div>
        </div>
      </Modal>
    </>
  );
}
