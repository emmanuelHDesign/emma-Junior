import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth";
import { useTheme } from "../lib/theme";
import {
  LayoutDashboard, Users, QrCode, Home, Wallet, Calendar,
  MessageSquare, Network, Moon, Sun, LogOut, Menu, Shield, ScanLine,
  Bell, User, UserCog, Sparkles, Tv, CreditCard, MapPin,
  BookOpen, Headphones, BookHeart, Bot
} from "lucide-react";
import { useState } from "react";
import { loadDB } from "../lib/data";

const NAV = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, permission: "voir_dashboard_pasteur" as const, always: false },
  { to: "/membres", label: "Membres", icon: Users, permission: "voir_tous_membres" as const, always: true },
  { to: "/presence", label: "Présence", icon: QrCode, permission: undefined, always: true },
  { to: "/scan", label: "Scanner ma présence", icon: ScanLine, permission: undefined, always: true },
  { to: "/cellules", label: "Cellules", icon: Home, permission: undefined, always: true },
  { to: "/dimes", label: "Dîmes & Offrandes", icon: Wallet, permission: "enregistrer_dime" as const, always: false },
  { to: "/dime-mobile", label: "Dîme Mobile Money", icon: CreditCard, permission: undefined, always: true },
  { to: "/live", label: "Culte en direct", icon: Tv, permission: undefined, always: true },
  { to: "/cellules-quartiers", label: "Cellules Douala", icon: MapPin, permission: undefined, always: true },
  { to: "/ia", label: "Esaïe IA ✨", icon: Bot, permission: undefined, always: true },
  { to: "/medias", label: "Prédications", icon: Headphones, permission: undefined, always: true },
  { to: "/priere", label: "Carnet de prière", icon: BookHeart, permission: undefined, always: true },
  { to: "/annuaire", label: "Annuaire", icon: BookOpen, permission: undefined, always: true },
  { to: "/evenements", label: "Événements", icon: Calendar, permission: undefined, always: true },
  { to: "/communication", label: "Communication", icon: MessageSquare, permission: "envoyer_messages" as const, always: false },
  { to: "/departements", label: "Départements", icon: Network, permission: undefined, always: true },
  { to: "/utilisateurs", label: "Utilisateurs", icon: UserCog, permission: "gerer_utilisateurs" as const, always: false },
];

import { ModeCulteOverlay } from "./ModeCulte";
import { UserAvatar } from "./PhotoUpload";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout, hasPermission } = useAuth();
  const { dark, toggle } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const items = NAV.filter((n) => n.always || (n.permission && hasPermission(n.permission)));

  // Notifications non lues
  const db = loadDB();
  const unreadCount = db.notifications.filter(n => !n.lu && (!n.userId || n.userId === user?.id)).length;

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50 dark:bg-slate-950">
      <ModeCulteOverlay />
      {/* Sidebar desktop */}
      <aside className="hidden lg:flex lg:flex-col w-64 bg-mdc-blue text-white flex-shrink-0">
        <SidebarContent user={user} items={items} hasPermission={hasPermission} onNavigate={() => setMobileOpen(false)} />
      </aside>

      {/* Sidebar mobile */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex" onClick={() => setMobileOpen(false)}>
          <div className="bg-black/50 flex-1" />
          <aside className="w-64 bg-mdc-blue text-white flex flex-col" onClick={(e) => e.stopPropagation()}>
            <SidebarContent user={user} items={items} hasPermission={hasPermission} onNavigate={() => setMobileOpen(false)} />
          </aside>
        </div>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 lg:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => setMobileOpen(true)} className="lg:hidden text-slate-600 dark:text-slate-300">
              <Menu size={22} />
            </button>
            <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
              <em>"L'Esprit du Seigneur est sur moi, Il m'a oint pour annoncer une année de grâce..."</em> — Ésaïe 61:1-3
            </p>
          </div>
          <div className="flex items-center gap-2">
            {/* Notifications */}
            <button
              onClick={() => navigate("/notifications")}
              className="relative p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
              title="Notifications"
            >
              <Bell size={18} />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              )}
            </button>

            <button
              onClick={toggle}
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
              title="Basculer mode sombre"
            >
              {dark ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {/* Menu utilisateur dropdown */}
            {user && (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 pl-3 pr-2 py-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 border-l border-slate-200 dark:border-slate-700"
                >
                  <UserAvatar user={user} size={32} />
                  <div className="hidden sm:block text-xs text-left">
                    <p className="font-medium text-slate-900 dark:text-slate-100">{user.nom}</p>
                    <p className="text-slate-500 dark:text-slate-400">{user.role}</p>
                  </div>
                </button>

                {userMenuOpen && (
                  <>
                    <div className="fixed inset-0 z-30" onClick={() => setUserMenuOpen(false)} />
                    <div className="absolute right-0 mt-2 w-56 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg z-40 overflow-hidden animate-fade-in">
                      <div className="p-3 border-b border-slate-200 dark:border-slate-800">
                        <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">{user.nom}</p>
                        <p className="text-xs text-slate-500 truncate">{user.email}</p>
                      </div>
                      <div className="p-1">
                        <button
                          onClick={() => { setUserMenuOpen(false); navigate("/profil"); }}
                          className="w-full flex items-center gap-2 px-3 py-2 rounded text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <User size={14} /> Mon profil
                        </button>
                        <button
                          onClick={() => { setUserMenuOpen(false); navigate("/notifications"); }}
                          className="w-full flex items-center justify-between gap-2 px-3 py-2 rounded text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                        >
                          <span className="flex items-center gap-2"><Bell size={14} /> Notifications</span>
                          {unreadCount > 0 && (
                            <span className="bg-red-500 text-white text-[10px] font-bold rounded-full px-1.5 py-0.5">{unreadCount}</span>
                          )}
                        </button>
                        <div className="my-1 border-t border-slate-200 dark:border-slate-800" />
                        <button
                          onClick={() => { setUserMenuOpen(false); handleLogout(); }}
                          className="w-full flex items-center gap-2 px-3 py-2 rounded text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20"
                        >
                          <LogOut size={14} /> Se déconnecter
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 lg:p-6 animate-fade-in">
          {children}
        </main>
      </div>
    </div>
  );
}

function SidebarContent({ user, items, onNavigate }: {
  user: ReturnType<typeof useAuth>["user"];
  items: typeof NAV;
  hasPermission: ReturnType<typeof useAuth>["hasPermission"];
  onNavigate: () => void;
}) {
  return (
    <>
      <div className="p-5 border-b border-white/10">
        <div className="flex items-center justify-between mb-1">
          <h1 className="font-bold text-xl leading-none">MDC</h1>
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-mdc-gold/20 border border-mdc-gold/30 text-[10px] font-semibold text-mdc-gold">
            <Sparkles size={9} /> V3.0 IA
          </span>
        </div>
        <p className="text-xs text-white/70 mt-1">Ministère des Déterminés pour Christ</p>
      </div>

      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            onClick={onNavigate}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition ${
                isActive
                  ? "bg-white text-mdc-blue font-semibold shadow"
                  : "text-white/80 hover:bg-white/10"
              }`
            }
          >
            <item.icon size={18} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      {user && (
        <div className="p-4 border-t border-white/10 text-xs space-y-2">
          <div className="flex items-center gap-2">
            <Shield size={14} />
            <span className="text-white/80">Douala, Cameroun</span>
          </div>
          <p className="text-white/50">v3.0.0 · Église MDC</p>
          <div className="pt-2 border-t border-white/10">
            <p className="text-white/40 text-[10px] uppercase tracking-wider">Développé par</p>
            <p className="text-mdc-gold font-semibold text-xs mt-0.5">
              Emmanuel Junior Bona
            </p>
            <p className="text-white/50 text-[10px]">Consultant Église Digitale</p>
          </div>
        </div>
      )}
    </>
  );
}


