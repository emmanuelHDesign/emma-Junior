// Upload photo de couverture avec compression paysage 1200×400
import { useRef, useState } from "react";
import { Camera, ImagePlus, Trash2 } from "lucide-react";

interface CoverUploadProps {
  currentCover?: string;
  onCoverChange: (dataUrl: string | undefined) => void;
  editing: boolean;
}

// Compresse en format paysage 1200×400 (ratio 3:1)
function compressCover(file: File, width = 1200, height = 400, quality = 0.75): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) { reject("Canvas non supporté"); return; }

        // Crop centré au ratio 3:1
        const targetRatio = width / height;
        const imgRatio = img.width / img.height;
        let sx = 0, sy = 0, sw = img.width, sh = img.height;
        if (imgRatio > targetRatio) {
          sw = img.height * targetRatio;
          sx = (img.width - sw) / 2;
        } else {
          sh = img.width / targetRatio;
          sy = (img.height - sh) / 2;
        }

        ctx.drawImage(img, sx, sy, sw, sh, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = () => reject("Image invalide");
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject("Erreur de lecture");
    reader.readAsDataURL(file);
  });
}

export function CoverUpload({ currentCover, onCoverChange, editing }: CoverUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError("");

    if (!file.type.startsWith("image/")) {
      setError("Sélectionnez une image (JPG, PNG, WEBP).");
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      setError("Image trop lourde (max 15 Mo).");
      return;
    }

    setLoading(true);
    try {
      const compressed = await compressCover(file);
      onCoverChange(compressed);
    } catch {
      setError("Erreur lors du traitement.");
    } finally {
      setLoading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const defaultGradient = "bg-gradient-to-r from-mdc-blue via-mdc-blue-light to-mdc-gold";

  return (
    <div className="relative group">
      {/* Image de couverture */}
      <div className={`h-40 sm:h-48 w-full rounded-t-xl overflow-hidden ${!currentCover ? defaultGradient : ""}`}>
        {currentCover && (
          <img
            src={currentCover}
            alt="Photo de couverture"
            className="w-full h-full object-cover"
          />
        )}
      </div>

      {/* Overlay au survol (toujours visible, même hors editing) */}
      {editing && (
        <div className="absolute inset-0 rounded-t-xl bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
          <button
            onClick={() => inputRef.current?.click()}
            disabled={loading}
            className="px-4 py-2 rounded-lg bg-white/90 hover:bg-white text-slate-900 text-sm font-medium flex items-center gap-2 shadow-lg transition min-h-[44px]"
          >
            {loading ? (
              <>
                <span className="w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" />
                Traitement...
              </>
            ) : (
              <>
                <ImagePlus size={16} />
                {currentCover ? "Changer la couverture" : "Ajouter une couverture"}
              </>
            )}
          </button>
          {currentCover && (
            <button
              onClick={() => onCoverChange(undefined)}
              className="px-3 py-2 rounded-lg bg-red-500/90 hover:bg-red-600 text-white text-sm font-medium flex items-center gap-2 shadow-lg transition min-h-[44px]"
            >
              <Trash2 size={14} /> Supprimer
            </button>
          )}
        </div>
      )}

      {/* Bouton discret en bas à droite (visible même sans hover sur mobile) */}
      {editing && (
        <button
          onClick={() => inputRef.current?.click()}
          disabled={loading}
          className="absolute bottom-3 right-3 px-3 py-1.5 rounded-lg bg-black/60 hover:bg-black/80 text-white text-xs font-medium flex items-center gap-1.5 transition backdrop-blur-sm min-h-[36px]"
        >
          <Camera size={14} />
          {currentCover ? "Modifier" : "Ajouter couverture"}
        </button>
      )}

      {/* Input caché */}
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        onChange={handleFile}
        className="hidden"
      />

      {/* Erreur */}
      {error && (
        <div className="absolute bottom-3 left-3 px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-medium shadow-lg">
          {error}
        </div>
      )}
    </div>
  );
}
