// V3.2 — Upload photo de profil avec compression + preview + recadrage cercle
import { useRef, useState } from "react";
import { Camera, Trash2, Upload, X } from "lucide-react";
import { Button } from "./ui";

interface PhotoUploadProps {
  currentPhoto?: string; // base64 data URL
  initials: string;
  onPhotoChange: (dataUrl: string | undefined) => void;
}

// Compresse une image à max 300x300px et qualité 0.7 (~30-80Ko)
function compressImage(file: File, maxSize = 300, quality = 0.7): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        // Calculer les dimensions en gardant le ratio carré (crop au centre)
        const minDim = Math.min(img.width, img.height);
        const sx = (img.width - minDim) / 2;
        const sy = (img.height - minDim) / 2;

        canvas.width = maxSize;
        canvas.height = maxSize;
        const ctx = canvas.getContext("2d");
        if (!ctx) { reject("Canvas non supporté"); return; }

        // Dessiner l'image croppée au centre
        ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, maxSize, maxSize);

        const dataUrl = canvas.toDataURL("image/jpeg", quality);
        resolve(dataUrl);
      };
      img.onerror = () => reject("Image invalide");
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject("Erreur de lecture du fichier");
    reader.readAsDataURL(file);
  });
}

export function PhotoUpload({ currentPhoto, initials, onPhotoChange }: PhotoUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | undefined>(currentPhoto);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError("");

    // Vérifier le type
    if (!file.type.startsWith("image/")) {
      setError("Veuillez sélectionner une image (JPG, PNG, WEBP).");
      return;
    }

    // Vérifier la taille (max 10 Mo avant compression)
    if (file.size > 10 * 1024 * 1024) {
      setError("L'image est trop lourde (max 10 Mo).");
      return;
    }

    setLoading(true);
    try {
      const compressed = await compressImage(file);
      setPreview(compressed);
      onPhotoChange(compressed);
    } catch {
      setError("Erreur lors du traitement de l'image.");
    } finally {
      setLoading(false);
      // Reset input pour permettre de re-sélectionner le même fichier
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const handleRemove = () => {
    setPreview(undefined);
    onPhotoChange(undefined);
    setError("");
  };

  return (
    <div className="flex flex-col items-center gap-3">
      {/* Photo ou initiales */}
      <div className="relative group">
        <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white dark:border-slate-900 shadow-lg bg-gradient-to-br from-mdc-gold to-mdc-gold-dark flex items-center justify-center">
          {preview ? (
            <img
              src={preview}
              alt="Photo de profil"
              className="w-full h-full object-cover"
            />
          ) : (
            <span className="text-4xl font-bold text-mdc-blue-dark">{initials}</span>
          )}
        </div>

        {/* Overlay au survol */}
        <button
          onClick={() => inputRef.current?.click()}
          className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
        >
          <Camera size={28} className="text-white" />
        </button>

        {/* Bouton supprimer */}
        {preview && (
          <button
            onClick={handleRemove}
            className="absolute -top-1 -right-1 w-8 h-8 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center shadow-md transition"
            title="Supprimer la photo"
          >
            <X size={14} />
          </button>
        )}
      </div>

      {/* Input caché */}
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/gif"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Boutons */}
      <div className="flex gap-2">
        <Button
          variant="secondary"
          onClick={() => inputRef.current?.click()}
          disabled={loading}
          className="min-h-[44px] text-sm"
        >
          {loading ? (
            <>
              <span className="w-4 h-4 border-2 border-slate-400 border-t-transparent rounded-full animate-spin" />
              Traitement...
            </>
          ) : (
            <>
              <Upload size={14} /> {preview ? "Changer la photo" : "Ajouter une photo"}
            </>
          )}
        </Button>
        {preview && (
          <Button variant="ghost" onClick={handleRemove} className="min-h-[44px] text-sm text-red-500">
            <Trash2 size={14} /> Supprimer
          </Button>
        )}
      </div>

      {/* Erreur */}
      {error && (
        <p className="text-sm text-red-600 text-center">{error}</p>
      )}

      {/* Info */}
      <p className="text-xs text-slate-400 text-center max-w-xs">
        Formats acceptés : JPG, PNG, WEBP. La photo sera automatiquement recadrée et compressée.
      </p>
    </div>
  );
}

// Composant d'affichage d'avatar réutilisable partout dans l'app
export function UserAvatar({ user, size = 32 }: { user: { nom: string; photoUrl?: string }; size?: number }) {
  const initials = user.nom.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();

  return (
    <div
      className="rounded-full bg-mdc-gold text-mdc-blue-dark flex items-center justify-center font-bold overflow-hidden flex-shrink-0"
      style={{ width: size, height: size, fontSize: size * 0.35 }}
    >
      {user.photoUrl ? (
        <img src={user.photoUrl} alt={user.nom} className="w-full h-full object-cover" />
      ) : (
        initials
      )}
    </div>
  );
}
