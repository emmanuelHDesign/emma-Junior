// V2.1 — Mode Culte : UI épurée pendant le service
import { useEffect } from "react";
import { useAppStore } from "../lib/store";
import { Church, X, BookOpen, Tv } from "lucide-react";

export function ModeCulteToggle() {
  const { modeCulte, toggleModeCulte } = useAppStore();

  return (
    <button
      onClick={toggleModeCulte}
      className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition ${
        modeCulte
          ? "bg-mdc-gold text-mdc-blue-dark"
          : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
      }`}
      title={modeCulte ? "Quitter le mode culte" : "Activer le mode culte"}
    >
      <Church size={16} />
      {modeCulte ? "Mode Culte ON" : "Mode Culte"}
    </button>
  );
}

export function ModeCulteOverlay() {
  const { modeCulte, toggleModeCulte } = useAppStore();

  useEffect(() => {
    if (modeCulte) {
      document.body.classList.add("mode-culte-active");
    } else {
      document.body.classList.remove("mode-culte-active");
    }
    return () => document.body.classList.remove("mode-culte-active");
  }, [modeCulte]);

  if (!modeCulte) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-mdc-blue flex flex-col items-center justify-center text-white p-6">
      <button
        onClick={toggleModeCulte}
        className="absolute top-4 right-4 p-2 rounded-full bg-white/20 hover:bg-white/30 transition"
        aria-label="Quitter le mode culte"
      >
        <X size={24} />
      </button>

      <div className="text-center space-y-6 max-w-md w-full">
        <Church size={64} className="mx-auto text-mdc-gold" />
        <h1 className="text-3xl font-bold">MDC Église</h1>
        <p className="text-white/80 text-lg italic">
          "L'Esprit du Seigneur est sur moi…"
        </p>
        <p className="text-mdc-gold font-semibold">Ésaïe 61:1-3</p>

        <div className="pt-8 space-y-4">
          <a
            href="https://www.youtube.com/@mdceglise"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-3 w-full py-4 px-6 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-lg transition min-h-[56px]"
          >
            <Tv size={22} /> Culte en direct
          </a>

          <button
            onClick={() => {
              toggleModeCulte();
              window.location.hash = "#bible";
            }}
            className="flex items-center justify-center gap-3 w-full py-4 px-6 rounded-xl bg-mdc-gold hover:bg-mdc-gold-dark text-mdc-blue-dark font-bold text-lg transition min-h-[56px]"
          >
            <BookOpen size={22} /> Lire la Bible
          </button>
        </div>

        <p className="text-white/40 text-xs mt-8">
          Mettez votre téléphone en silencieux · Bonne adoration 🙏
        </p>
      </div>
    </div>
  );
}
