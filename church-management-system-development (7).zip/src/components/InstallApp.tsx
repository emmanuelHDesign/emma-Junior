import { useEffect, useMemo, useState } from "react";
import { Button, Card, Badge } from "./ui";
import { Download, Share2, Smartphone, CheckCircle2 } from "lucide-react";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
};

export function InstallApp({ compact = false }: { compact?: boolean }) {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    const ua = window.navigator.userAgent;
    const ios = /iPad|iPhone|iPod/.test(ua) || ((navigator as Navigator & { standalone?: boolean }).standalone !== undefined && /Mac/.test(ua));
    const standalone = window.matchMedia("(display-mode: standalone)").matches || Boolean((navigator as Navigator & { standalone?: boolean }).standalone);

    setIsIOS(ios);
    setIsStandalone(standalone);
    setInstalled(standalone);

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const installedHandler = () => {
      setInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener("beforeinstallprompt", handler);
    window.addEventListener("appinstalled", installedHandler);

    return () => {
      window.removeEventListener("beforeinstallprompt", handler);
      window.removeEventListener("appinstalled", installedHandler);
    };
  }, []);

  const canInstall = useMemo(() => Boolean(deferredPrompt) || isIOS, [deferredPrompt, isIOS]);

  const handleInstall = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === "accepted") {
        setInstalled(true);
      }
      setDeferredPrompt(null);
    }
  };

  if (installed || isStandalone) {
    return compact ? (
      <Badge color="green"><CheckCircle2 size={12} /> Installée</Badge>
    ) : (
      <Card className="p-4 border-green-200 dark:border-green-900/40 bg-green-50 dark:bg-green-900/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
            <CheckCircle2 size={20} className="text-green-600" />
          </div>
          <div>
            <p className="font-semibold text-green-800 dark:text-green-200">Application déjà installée</p>
            <p className="text-sm text-green-700/80 dark:text-green-300/80">Ouvrez MDC Église directement depuis l'écran d'accueil.</p>
          </div>
        </div>
      </Card>
    );
  }

  if (compact) {
    return canInstall ? (
      <Button onClick={handleInstall} variant="gold">
        <Download size={14} /> Installer
      </Button>
    ) : null;
  }

  return (
    <Card className="p-5">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-11 h-11 rounded-xl bg-mdc-blue/10 dark:bg-mdc-blue/20 flex items-center justify-center">
          <Smartphone size={20} className="text-mdc-blue" />
        </div>
        <div>
          <h3 className="font-semibold text-slate-900 dark:text-slate-100">Installer MDC Église</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Accès rapide depuis votre téléphone, idéal pour les membres à Douala avec connexion 3G.
          </p>
        </div>
      </div>

      {deferredPrompt && (
        <Button onClick={handleInstall} variant="gold" className="w-full min-h-12 text-base">
          <Download size={18} /> Installer l'application maintenant
        </Button>
      )}

      {!deferredPrompt && isIOS && (
        <div className="space-y-3">
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
            <p className="font-medium text-slate-900 dark:text-slate-100 mb-2">Installer sur iPhone / iPad</p>
            <ol className="text-sm text-slate-600 dark:text-slate-300 space-y-1 list-decimal list-inside">
              <li>Appuyez sur <strong>Partager</strong> <Share2 className="inline" size={14} /></li>
              <li>Choisissez <strong>Sur l'écran d'accueil</strong></li>
              <li>Validez pour installer <strong>MDC Église</strong></li>
            </ol>
          </div>
        </div>
      )}

      {!deferredPrompt && !isIOS && !canInstall && (
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
          <p className="text-sm text-slate-600 dark:text-slate-300">
            Ouvrez cette page dans <strong>Chrome</strong> ou <strong>Edge</strong> sur Android pour installer l'application.
          </p>
        </div>
      )}
    </Card>
  );
}
