import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import { clsx } from "clsx";

// === Button ===
type BtnVariant = "primary" | "secondary" | "ghost" | "danger" | "gold";
export function Button({
  variant = "primary", className, children, ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant }) {
  const base = "inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition disabled:opacity-50 disabled:cursor-not-allowed";
  const styles: Record<BtnVariant, string> = {
    primary: "bg-mdc-blue hover:bg-mdc-blue-dark text-white shadow-sm",
    gold: "bg-mdc-gold hover:bg-mdc-gold-dark text-mdc-blue-dark shadow-sm",
    secondary: "bg-slate-100 hover:bg-slate-200 text-slate-900 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-100",
    ghost: "hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200",
    danger: "bg-red-600 hover:bg-red-700 text-white",
  };
  return <button className={clsx(base, styles[variant], className)} {...rest}>{children}</button>;
}

// === Card ===
export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={clsx(
      "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm",
      className
    )}>{children}</div>
  );
}

// === Input ===
export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={clsx(
        "w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-900 text-sm",
        "border-slate-300 dark:border-slate-700",
        "focus:outline-none focus:ring-2 focus:ring-mdc-blue/40 focus:border-mdc-blue",
        "text-slate-900 dark:text-slate-100 placeholder:text-slate-400",
        props.className
      )}
    />
  );
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={clsx(
        "w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-900 text-sm",
        "border-slate-300 dark:border-slate-700",
        "focus:outline-none focus:ring-2 focus:ring-mdc-blue/40 focus:border-mdc-blue",
        "text-slate-900 dark:text-slate-100",
        props.className
      )}
    />
  );
}

export function Textarea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={clsx(
        "w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-900 text-sm",
        "border-slate-300 dark:border-slate-700",
        "focus:outline-none focus:ring-2 focus:ring-mdc-blue/40 focus:border-mdc-blue",
        "text-slate-900 dark:text-slate-100",
        props.className
      )}
    />
  );
}

export function Label({ children, htmlFor }: { children: ReactNode; htmlFor?: string }) {
  return (
    <label htmlFor={htmlFor} className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
      {children}
    </label>
  );
}

// === Badge ===
export function Badge({ children, color = "slate" }: { children: ReactNode; color?: "slate" | "blue" | "gold" | "green" | "red" | "purple" }) {
  const map = {
    slate: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
    blue: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
    gold: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
    green: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300",
    red: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
    purple: "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300",
  };
  return <span className={clsx("inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium", map[color])}>{children}</span>;
}

// === Modal ===
export function Modal({ open, onClose, title, children, maxWidth = "md" }: { open: boolean; onClose: () => void; title: string; children: ReactNode; maxWidth?: "sm" | "md" | "lg" | "xl" }) {
  if (!open) return null;
  const widths = { sm: "max-w-sm", md: "max-w-md", lg: "max-w-2xl", xl: "max-w-4xl" };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in" onClick={onClose}>
      <div className={clsx("bg-white dark:bg-slate-900 rounded-xl shadow-xl w-full", widths[maxWidth])} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-200 dark:border-slate-800">
          <h3 className="font-semibold text-slate-900 dark:text-slate-100">{title}</h3>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-900 dark:hover:text-slate-100 text-xl leading-none">×</button>
        </div>
        <div className="p-5 max-h-[80vh] overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

// === StatCard ===
export function StatCard({ label, value, hint, icon, color = "blue" }: { label: string; value: string | number; hint?: string; icon: ReactNode; color?: "blue" | "gold" | "green" | "purple" }) {
  const bg = {
    blue: "bg-blue-50 text-mdc-blue dark:bg-mdc-blue/10",
    gold: "bg-amber-50 text-amber-700 dark:bg-amber-900/20",
    green: "bg-green-50 text-green-700 dark:bg-green-900/20",
    purple: "bg-purple-50 text-purple-700 dark:bg-purple-900/20",
  };
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide">{label}</p>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-slate-100">{value}</p>
          {hint && <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{hint}</p>}
        </div>
        <div className={clsx("p-2.5 rounded-lg", bg[color])}>{icon}</div>
      </div>
    </Card>
  );
}
