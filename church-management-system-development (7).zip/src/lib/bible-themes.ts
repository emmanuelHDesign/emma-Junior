// V3.1 — Thèmes bibliques exhaustifs pour Esaïe IA
// Chaque thème contient : mots-clés de détection, versets, explication détaillée, application, prière

export interface ThemeResponse {
  theme: string;
  keywords: string[];
  build: () => string;
}

// Générateur de réponse formatée
function fmt(titre: string, intro: string, points: string[], versets: string[], application: string, priere: string): string {
  return `📖 **${titre}**

${intro}

${points.map((p, i) => `**${i + 1}.** ${p}`).join("\n\n")}

📌 **Versets clés :** ${versets.join(" · ")}

💡 **Application pour ta vie :** ${application}

🙏 *${priere}*`;
}

export const THEMES: ThemeResponse[] = [
  // ============ SALUT & CONVERSION ============
  {
    theme: "salut",
    keywords: ["salut", "sauvé", "sauver", "conversion", "converti", "né de nouveau", "naitre de nouveau", "accepter jesus", "accepter jésus", "accepter christ", "donner sa vie", "comment être sauvé", "pécheur", "pecheur", "repentance", "repentir", "pardon de dieu", "pardon des péchés"],
    build: () => fmt(
      "Le Salut en Jésus-Christ",
      "Le salut est le don le plus précieux de Dieu. Il n'est pas gagné par nos œuvres, mais reçu par la foi en Jésus-Christ qui est mort et ressuscité pour nous.\n\n\"Car Dieu a tant aimé le monde qu'il a donné son Fils unique, afin que quiconque croit en lui ne périsse point, mais qu'il ait la vie éternelle.\" — **Jean 3:16**",
      [
        "**Reconnaître son péché** : \"Car tous ont péché et sont privés de la gloire de Dieu\" (Romains 3:23). Nous avons tous besoin d'un Sauveur.",
        "**Croire en Jésus-Christ** : \"Si tu confesses de ta bouche le Seigneur Jésus, et si tu crois dans ton cœur que Dieu l'a ressuscité des morts, tu seras sauvé\" (Romains 10:9).",
        "**Se repentir** : \"Repentez-vous et que chacun de vous soit baptisé au nom de Jésus-Christ, pour le pardon de vos péchés\" (Actes 2:38).",
        "**Recevoir la grâce** : \"Car c'est par la grâce que vous êtes sauvés, par le moyen de la foi. Et cela ne vient pas de vous, c'est le don de Dieu\" (Éphésiens 2:8).",
        "**Devenir une nouvelle créature** : \"Si quelqu'un est en Christ, il est une nouvelle créature. Les choses anciennes sont passées ; voici, toutes choses sont devenues nouvelles\" (2 Corinthiens 5:17)."
      ],
      ["Jean 3:16", "Romains 3:23", "Romains 10:9", "Éphésiens 2:8-9", "2 Corinthiens 5:17", "Actes 16:31", "Romains 6:23"],
      "Si tu n'as pas encore donné ta vie à Jésus, tu peux le faire maintenant. Dis simplement : \"Seigneur Jésus, je reconnais que je suis pécheur. Je crois que Tu es mort pour moi et ressuscité. Entre dans ma vie et sois mon Sauveur.\" Parle ensuite à ton berger de cellule MDC pour être suivi dans ta nouvelle vie.",
      "Seigneur Jésus, merci pour ton amour infini. Merci d'avoir donné ta vie à la croix pour nous sauver. Nous te prions pour tous ceux qui cherchent le salut aujourd'hui. Ouvre leurs cœurs à Ta grâce. Au nom de Jésus, amen."
    )
  },

  // ============ FOI ============
  {
    theme: "foi",
    keywords: ["foi", "croire", "confiance", "confier", "doute", "douter", "incrédulité", "grandir dans la foi", "avoir la foi", "augmenter ma foi", "fortifier", "croyance"],
    build: () => fmt(
      "La foi selon la Bible",
      "\"Or la foi est une ferme assurance des choses qu'on espère, une démonstration de celles qu'on ne voit pas.\" — **Hébreux 11:1**\n\nLa foi est le fondement de notre relation avec Dieu. Sans elle, il est impossible de Lui être agréable (Hébreux 11:6).",
      [
        "**La foi vient de la Parole** : \"Ainsi la foi vient de ce qu'on entend, et ce qu'on entend vient de la Parole de Christ\" (Romains 10:17). Plus vous lisez la Bible, plus votre foi grandit.",
        "**La foi agit** : \"La foi sans les œuvres est morte\" (Jacques 2:26). La vraie foi se manifeste par des actes d'obéissance.",
        "**La foi déplace les montagnes** : \"Si vous aviez de la foi comme un grain de sénevé, vous diriez à cette montagne : Transporte-toi d'ici là, et elle se transporterait\" (Matthieu 17:20).",
        "**La foi est un combat** : \"Combats le bon combat de la foi\" (1 Timothée 6:12). Il faut la défendre contre les doutes et les découragements.",
        "**La foi est perfectionnée par les épreuves** : \"L'épreuve de votre foi produit la patience\" (Jacques 1:3). Dieu utilise les difficultés pour fortifier notre foi.",
        "**Les héros de la foi** : Hébreux chapitre 11 liste Abraham, Moïse, Rahab, David et d'autres qui ont vécu par la foi malgré les circonstances difficiles."
      ],
      ["Hébreux 11:1", "Hébreux 11:6", "Romains 10:17", "Matthieu 17:20", "Jacques 2:26", "2 Corinthiens 5:7", "Philippiens 1:6"],
      "Pour grandir dans la foi : 1) Lis ta Bible chaque jour, 2) Prie régulièrement, 3) Rejoins une cellule MDC pour la communion fraternelle, 4) Mets en pratique ce que tu apprends, 5) Témoigne de ce que Dieu fait dans ta vie.",
      "Seigneur, augmente notre foi ! Aide-nous à Te faire confiance même quand nous ne comprenons pas Tes voies. Fortifie-nous par Ta Parole et Ton Esprit. Au nom de Jésus, amen."
    )
  },

  // ============ PRIÈRE ============
  {
    theme: "priere",
    keywords: ["prier", "prière", "priere", "intercession", "interceder", "comment prier", "prie pour moi", "sujet de prière", "jeûne", "jeune", "veillée", "oraison", "requête", "supplication"],
    build: () => fmt(
      "La prière selon la Bible",
      "La prière est la conversation intime entre nous et Dieu. C'est notre ligne directe avec le Créateur de l'univers.\n\n\"Ne vous inquiétez de rien ; mais en toute chose faites connaître vos besoins à Dieu par des prières et des supplications, avec des actions de grâces.\" — **Philippiens 4:6**",
      [
        "**Le modèle du Notre Père** (Matthieu 6:9-13) : Adoration → Soumission → Demande → Pardon → Protection. Jésus nous a enseigné un schéma complet de prière.",
        "**Priez sans cesse** : \"Priez sans cesse\" (1 Thessaloniciens 5:17). La prière n'est pas un rituel mais un style de vie, une attitude permanente du cœur.",
        "**Priez avec foi** : \"Tout ce que vous demanderez en priant, croyez que vous l'avez reçu, et vous le verrez s'accomplir\" (Marc 11:24). La foi est la clé de la prière exaucée.",
        "**La prière du juste** : \"La prière fervente du juste a une grande efficacité\" (Jacques 5:16). Dieu écoute ceux qui vivent dans la justice.",
        "**Priez les uns pour les autres** : L'intercession est un ministère puissant. Moïse, Daniel, Paul intercédaient constamment pour les autres.",
        "**Le jeûne accompagne la prière** : \"Cette sorte de démon ne sort que par la prière et par le jeûne\" (Matthieu 17:21). Le jeûne intensifie notre vie spirituelle.",
        "**Le Saint-Esprit nous aide** : \"L'Esprit lui-même intercède par des soupirs inexprimables\" (Romains 8:26). Quand nous ne savons pas comment prier, l'Esprit prie pour nous."
      ],
      ["Philippiens 4:6-7", "Matthieu 6:9-13", "1 Thessaloniciens 5:17", "Jacques 5:16", "Marc 11:24", "Romains 8:26", "Jérémie 33:3"],
      "Utilisez le Carnet de Prière de l'application MDC pour noter vos sujets. Participez aux soirées de prière le mardi au temple MDC à 18h.",
      "Père céleste, apprends-nous à prier selon Ta volonté. Donne-nous la discipline de la prière quotidienne. Que notre vie de prière soit transformée pour Ta gloire. Au nom de Jésus, amen."
    )
  },

  // ============ DÎME & FINANCES ============
  {
    theme: "dime",
    keywords: ["dîme", "dime", "offrande", "argent", "finance", "donner", "générosité", "don", "bénédiction financière", "prospérité", "provision", "dette", "pauvreté", "richesse", "mobile money", "momo"],
    build: () => fmt(
      "La dîme et les offrandes selon la Bible",
      "La dîme est un acte de foi, d'obéissance et de reconnaissance envers Dieu. C'est le seul domaine où Dieu nous invite à Le mettre à l'épreuve.\n\n\"Apportez à la maison du trésor toutes les dîmes... mettez-moi de la sorte à l'épreuve, dit l'Éternel. Et vous verrez si je n'ouvre pas pour vous les écluses des cieux.\" — **Malachie 3:10**",
      [
        "**L'origine de la dîme** : Abraham a donné la dîme à Melchisédek (Genèse 14:20). C'est un principe qui précède la Loi de Moïse.",
        "**La dîme = 10% des revenus** : Le mot \"dîme\" signifie \"dixième\". C'est la première portion que nous rendons à Dieu.",
        "**Les offrandes vont au-delà** : \"Que chacun donne comme il l'a résolu en son cœur, sans tristesse ni contrainte ; car Dieu aime celui qui donne avec joie\" (2 Corinthiens 9:7).",
        "**Les promesses de Dieu** : \"Donnez, et il vous sera donné : on versera dans votre sein une bonne mesure, serrée, secouée et qui déborde\" (Luc 6:38).",
        "**Honorer Dieu avec ses biens** : \"Honore l'Éternel avec tes biens, et avec les prémices de tout ton revenu ; alors tes greniers seront remplis d'abondance\" (Proverbes 3:9-10).",
        "**Jésus et la dîme** : Jésus n'a pas aboli la dîme. Il a dit : \"Il ne fallait pas négliger ces choses\" (Matthieu 23:23).",
        "**Le principe de la semence** : \"Celui qui sème peu moissonnera peu, et celui qui sème abondamment moissonnera abondamment\" (2 Corinthiens 9:6)."
      ],
      ["Malachie 3:10", "2 Corinthiens 9:6-7", "Luc 6:38", "Proverbes 3:9-10", "Genèse 14:20", "Matthieu 23:23", "Philippiens 4:19"],
      "Vous pouvez donner votre dîme via MTN Mobile Money ou Orange Money dans l'onglet \"Dîme Mobile Money\" de l'application MDC. Un reçu PDF sera automatiquement généré.",
      "Seigneur, nous te remercions pour ta provision fidèle. Aide-nous à être de bons gestionnaires de ce que Tu nous confies. Bénis le travail de nos mains et ouvre les écluses des cieux sur nos vies. Au nom de Jésus, amen."
    )
  },

  // ============ ÉPREUVE & SOUFFRANCE ============
  {
    theme: "epreuve",
    keywords: ["épreuve", "epreuve", "souffrance", "souffrir", "difficile", "difficulté", "mal", "triste", "tristesse", "dépression", "depression", "découragement", "decouragement", "maladie", "douleur", "pleurer", "larme", "angoisse", "anxiété", "anxiete", "peur", "crainte", "stress", "fatigue", "problème", "probleme", "pourquoi dieu"],
    build: () => fmt(
      "Dieu dans l'épreuve et la souffrance",
      "Si tu traverses une période difficile, sache que tu n'es pas seul. Dieu est particulièrement proche de ceux qui souffrent.\n\n\"L'Éternel est près de ceux qui ont le cœur brisé, et il sauve ceux qui ont l'esprit dans l'abattement.\" — **Psaume 34:18**",
      [
        "**Dieu est avec toi** : \"Ne crains rien, car je suis avec toi ; je te fortifie, je viens à ton secours\" (Ésaïe 41:10). Sa présence ne dépend pas de tes circonstances.",
        "**L'épreuve est temporaire** : \"Car nos légères afflictions du moment présent produisent pour nous, au-delà de toute mesure, un poids éternel de gloire\" (2 Corinthiens 4:17).",
        "**Dieu ne permet pas au-delà de tes forces** : \"Aucune tentation ne vous est survenue qui n'ait été humaine, et Dieu ne permettra pas que vous soyez tentés au-delà de vos forces\" (1 Corinthiens 10:13).",
        "**L'épreuve produit du fruit** : \"Regardez comme un sujet de joie les diverses épreuves, sachant que l'épreuve de votre foi produit la patience\" (Jacques 1:2-4).",
        "**Jésus comprend ta douleur** : Il a été \"un homme de douleur et habitué à la souffrance\" (Ésaïe 53:3). Il peut compatir avec toi parce qu'il a souffert aussi.",
        "**Toutes choses concourent au bien** : \"Nous savons que toutes choses concourent au bien de ceux qui aiment Dieu\" (Romains 8:28). Même ce qui semble négatif, Dieu le transforme.",
        "**La délivrance vient** : \"Ceux qui sèment avec larmes moissonneront avec chants d'allégresse\" (Psaume 126:5). Ton temps de pleurs sera suivi d'une saison de joie."
      ],
      ["Psaume 34:18", "Ésaïe 41:10", "2 Corinthiens 4:17", "Romains 8:28", "1 Corinthiens 10:13", "Jacques 1:2-4", "Psaume 23:4", "Jean 16:33"],
      "N'hésite pas à écrire dans ton Carnet de Prière dans l'app. Contacte ton berger de cellule MDC pour un soutien personnel. Participe aux soirées de prière le mardi.",
      "Père céleste, je te confie cette épreuve. Tu connais ma situation mieux que quiconque. Donne-moi la force de tenir ferme, la paix qui surpasse toute intelligence, et la certitude que Tu es avec moi. Tu es fidèle et Tu ne m'abandonneras jamais. Au nom de Jésus, amen."
    )
  },

  // ============ MARIAGE & COUPLE ============
  {
    theme: "mariage",
    keywords: ["mariage", "couple", "femme", "mari", "époux", "épouse", "epoux", "epouse", "fiançailles", "fiancailles", "divorce", "adultère", "adultere", "infidélité", "infidelite", "sexualité", "relation amoureuse", "célibat", "celibat", "conjoint"],
    build: () => fmt(
      "Le mariage et le couple selon la Bible",
      "Le mariage est une institution divine, créée par Dieu dès le jardin d'Éden.\n\n\"C'est pourquoi l'homme quittera son père et sa mère, et s'attachera à sa femme, et ils deviendront une seule chair.\" — **Genèse 2:24**",
      [
        "**Le mariage est institué par Dieu** : C'est Dieu lui-même qui a uni Adam et Ève. Le mariage n'est pas une invention humaine, mais un dessein divin (Genèse 2:18-24).",
        "**L'amour sacrificiel du mari** : \"Maris, aimez vos femmes, comme Christ a aimé l'Église, et s'est livré lui-même pour elle\" (Éphésiens 5:25). L'amour du mari doit être total et désintéressé.",
        "**Le respect mutuel** : \"Que chacun de vous aime sa femme comme lui-même, et que la femme respecte son mari\" (Éphésiens 5:33). Amour et respect sont les deux piliers.",
        "**La prière ensemble** : \"Si deux d'entre vous s'accordent sur la terre pour demander une chose quelconque, elle leur sera accordée\" (Matthieu 18:19). Un couple qui prie ensemble reste uni.",
        "**L'amour véritable** : 1 Corinthiens 13:4-7 décrit l'amour : patient, bon, ne cherche pas son intérêt, supporte tout, croit tout, espère tout.",
        "**Fuir l'adultère** : \"Que le mariage soit honoré de tous, et le lit conjugal exempt de souillure\" (Hébreux 13:4). La fidélité est non négociable.",
        "**Le pardon dans le couple** : \"Supportez-vous les uns les autres, et, si l'un a sujet de se plaindre de l'autre, pardonnez-vous réciproquement\" (Colossiens 3:13)."
      ],
      ["Genèse 2:24", "Éphésiens 5:25-33", "1 Corinthiens 13:4-7", "Matthieu 19:6", "Proverbes 31:10", "Hébreux 13:4", "Colossiens 3:18-19"],
      "Participez aux séminaires couples organisés par MDC. Priez ensemble chaque jour. En cas de difficulté conjugale, n'hésitez pas à contacter le pasteur pour un accompagnement.",
      "Seigneur, bénis les couples de MDC. Fortifie les mariages, restaure ceux qui traversent des tempêtes, et prépare les cœurs de ceux qui cherchent un(e) conjoint(e) selon Ton cœur. Au nom de Jésus, amen."
    )
  },

  // ============ SAINT-ESPRIT ============
  {
    theme: "saint-esprit",
    keywords: ["saint-esprit", "saint esprit", "esprit saint", "esprit de dieu", "baptême du saint-esprit", "bapteme du saint esprit", "don spirituel", "dons spirituels", "parler en langues", "langue", "prophétie", "prophetie", "onction", "remplir", "consolateur", "paraclet", "fruit de l'esprit"],
    build: () => fmt(
      "Le Saint-Esprit dans la vie du chrétien",
      "Le Saint-Esprit est la troisième personne de la Trinité. Il est notre Consolateur, notre Guide et notre Source de puissance.\n\n\"Vous recevrez une puissance, le Saint-Esprit survenant sur vous, et vous serez mes témoins\" — **Actes 1:8**",
      [
        "**Qui est le Saint-Esprit ?** : Il est Dieu en personne, pas une force impersonnelle. Jésus l'appelle \"le Consolateur\" et \"l'Esprit de vérité\" (Jean 14:16-17).",
        "**Le baptême du Saint-Esprit** : C'est une expérience distincte de la conversion. Les disciples l'ont reçu à la Pentecôte : \"Ils furent tous remplis du Saint-Esprit\" (Actes 2:4).",
        "**Les dons du Saint-Esprit** : Parole de sagesse, parole de connaissance, foi, guérison, miracles, prophétie, discernement, diversité des langues, interprétation (1 Corinthiens 12:8-10).",
        "**Le fruit de l'Esprit** : \"Le fruit de l'Esprit, c'est l'amour, la joie, la paix, la patience, la bonté, la bénignité, la fidélité, la douceur, la tempérance\" (Galates 5:22-23).",
        "**L'Esprit nous guide** : \"Quand le consolateur sera venu, l'Esprit de vérité, il vous conduira dans toute la vérité\" (Jean 16:13).",
        "**L'Esprit intercède pour nous** : \"L'Esprit lui-même intercède par des soupirs inexprimables\" (Romains 8:26). Quand on ne sait pas prier, l'Esprit prie pour nous.",
        "**Ne pas attrister l'Esprit** : \"N'attristez pas le Saint-Esprit de Dieu\" (Éphésiens 4:30). Notre vie doit honorer Sa présence en nous."
      ],
      ["Actes 1:8", "Actes 2:4", "Jean 14:16-17", "1 Corinthiens 12:8-10", "Galates 5:22-23", "Romains 8:26", "Jean 16:13"],
      "Si vous n'avez pas encore reçu le baptême du Saint-Esprit, demandez-le à Dieu avec foi. Participez aux soirées de prière MDC le mardi. Parlez-en à votre berger de cellule.",
      "Seigneur, remplis-nous de Ton Esprit Saint. Baptise-nous de feu. Manifeste Tes dons parmi nous pour l'édification de Ton Église MDC. Au nom de Jésus, amen."
    )
  },

  // ============ GUÉRISON ============
  {
    theme: "guerison",
    keywords: ["guérison", "guerison", "guérir", "guerir", "maladie", "malade", "santé", "sante", "médecin", "medecin", "hôpital", "hopital", "cancer", "handicap", "infirmité", "infirmite", "miracle", "toucher", "imposition des mains"],
    build: () => fmt(
      "La guérison divine selon la Bible",
      "Dieu est le Guérisseur suprême. Son nom \"Yahweh Rapha\" signifie \"L'Éternel qui te guérit\".\n\n\"C'est par ses meurtrissures que nous sommes guéris.\" — **Ésaïe 53:5**",
      [
        "**Dieu est le Guérisseur** : \"Car je suis l'Éternel, qui te guérit\" (Exode 15:26). La guérison fait partie de la nature même de Dieu.",
        "**Jésus guérissait tous** : \"Il guérissait tous les malades\" (Matthieu 8:16). Dans Son ministère terrestre, Jésus n'a jamais refusé de guérir quelqu'un.",
        "**La guérison est dans l'expiation** : \"Il était blessé pour nos péchés... et c'est par ses meurtrissures que nous sommes guéris\" (Ésaïe 53:5). La croix couvre la maladie aussi.",
        "**La prière de la foi** : \"La prière de la foi sauvera le malade, et le Seigneur le relèvera\" (Jacques 5:15).",
        "**L'imposition des mains** : \"Ils imposeront les mains aux malades, et les malades seront guéris\" (Marc 16:18). C'est un ministère confié à tous les croyants.",
        "**La foi personnelle** : \"Ta foi t'a sauvé\" (Luc 7:50). Souvent, Jésus associait la guérison à la foi de la personne.",
        "**La patience et la confiance** : Parfois la guérison est immédiate, parfois progressive. Dans tous les cas, faisons confiance à Dieu qui connaît le meilleur timing."
      ],
      ["Ésaïe 53:5", "Exode 15:26", "Psaume 103:3", "Jacques 5:14-15", "Marc 16:18", "Matthieu 8:17", "3 Jean 1:2"],
      "Demande la prière à ton berger de cellule ou au pasteur. Participe aux cultes MDC où l'on prie pour les malades. Continue également ton traitement médical : Dieu utilise aussi la médecine.",
      "Dieu Tout-Puissant, Yahweh Rapha, nous te prions pour la guérison. Touche chaque membre malade de l'église MDC. Que Ta puissance se manifeste dans nos corps. Nous croyons en Tes promesses. Au nom de Jésus, amen."
    )
  },

  // ============ COMBAT SPIRITUEL ============
  {
    theme: "combat",
    keywords: ["combat spirituel", "démon", "demon", "diable", "ennemi", "attaque", "oppression", "délivrance", "delivrance", "libération", "liberation", "tentations", "tentation", "armure", "guerre spirituelle", "victoire", "résister", "resister", "lier", "chasser"],
    build: () => fmt(
      "Le combat spirituel et la victoire en Christ",
      "Le chrétien est engagé dans un combat spirituel. Mais la bonne nouvelle, c'est que Christ a déjà remporté la victoire !\n\n\"Revêtez-vous de toutes les armes de Dieu, afin de pouvoir tenir ferme contre les ruses du diable.\" — **Éphésiens 6:11**",
      [
        "**L'ennemi est réel** : \"Soyez sobres, veillez. Votre adversaire, le diable, rôde comme un lion rugissant, cherchant qui il dévorera\" (1 Pierre 5:8). Ne soyons pas naïfs.",
        "**Christ a vaincu** : \"Il a dépouillé les dominations et les autorités, et les a livrées publiquement en spectacle, en triomphant d'elles par la croix\" (Colossiens 2:15).",
        "**Les armes de Dieu** (Éphésiens 6:14-18) : la ceinture de la vérité, la cuirasse de la justice, les chaussures du zèle, le bouclier de la foi, le casque du salut, l'épée de l'Esprit (la Parole de Dieu), la prière.",
        "**Résister** : \"Soumettez-vous donc à Dieu ; résistez au diable, et il fuira loin de vous\" (Jacques 4:7). Le diable fuit devant le croyant qui résiste.",
        "**Le nom de Jésus** : \"En mon nom, ils chasseront les démons\" (Marc 16:17). Le nom de Jésus a toute autorité sur les puissances des ténèbres.",
        "**Nous sommes plus que vainqueurs** : \"Dans toutes ces choses nous sommes plus que vainqueurs par celui qui nous a aimés\" (Romains 8:37).",
        "**La puissance du sang** : \"Ils l'ont vaincu à cause du sang de l'Agneau et à cause de la parole de leur témoignage\" (Apocalypse 12:11)."
      ],
      ["Éphésiens 6:10-18", "Jacques 4:7", "1 Jean 4:4", "Romains 8:37", "Colossiens 2:15", "Marc 16:17", "2 Corinthiens 10:4"],
      "Prie chaque matin en revêtant les armes de Dieu (Éphésiens 6). Lis la Parole quotidiennement — c'est ton épée. Participe aux veillées de prière MDC pour renforcer ta vie spirituelle.",
      "Seigneur Jésus, nous nous revêtons de Tes armes. Par Ton sang précieux, nous résistons à toute attaque de l'ennemi. Tu es notre victoire. Nous nous tenons fermes dans la foi. Au nom puissant de Jésus, amen."
    )
  },

  // ============ FAMILLE & ENFANTS ============
  {
    theme: "famille",
    keywords: ["famille", "enfant", "enfants", "parent", "père", "pere", "mère", "mere", "fils", "fille", "éducation", "education", "élever", "elever", "discipline", "honorer ses parents", "héritage", "heritage", "génération", "generation"],
    build: () => fmt(
      "La famille selon le plan de Dieu",
      "La famille est la première institution créée par Dieu. C'est le socle de la société et de l'Église.\n\n\"Instruis l'enfant selon la voie qu'il doit suivre ; et quand il sera vieux, il ne s'en détournera pas.\" — **Proverbes 22:6**",
      [
        "**La famille est un don de Dieu** : \"Voici, des fils sont un héritage de l'Éternel, le fruit des entrailles est une récompense\" (Psaume 127:3).",
        "**Éduquer dans la foi** : \"Tu les inculqueras à tes enfants, et tu en parleras quand tu seras dans ta maison, quand tu iras en voyage\" (Deutéronome 6:7).",
        "**Honorer ses parents** : \"Honore ton père et ta mère, afin que tes jours se prolongent\" (Exode 20:12). C'est le premier commandement avec une promesse.",
        "**L'exemple parental** : Les parents sont les premiers modèles de foi. Vivez ce que vous enseignez à vos enfants.",
        "**La discipline avec amour** : \"Mon fils, ne méprise pas la correction de l'Éternel\" (Proverbes 3:11). La discipline est une preuve d'amour, pas de rejet.",
        "**Prier pour sa famille** : Josué a dit : \"Moi et ma maison, nous servirons l'Éternel\" (Josué 24:15). Couvrez votre famille de prière."
      ],
      ["Proverbes 22:6", "Psaume 127:3", "Deutéronome 6:7", "Exode 20:12", "Éphésiens 6:4", "Josué 24:15", "Psaume 128:3"],
      "Inscrivez vos enfants à l'école du dimanche MDC. Priez en famille chaque soir avant le coucher. Participez aux événements familiaux organisés par l'église.",
      "Seigneur, bénis chaque famille de MDC. Protège nos enfants, fortifie les parents, et que chaque foyer soit un autel de prière et d'amour. Au nom de Jésus, amen."
    )
  },

  // ============ PARDON ============
  {
    theme: "pardon",
    keywords: ["pardon", "pardonner", "rancune", "rancœur", "rancoeur", "colère", "colere", "blessure", "offensé", "offense", "offense", "réconciliation", "reconciliation", "vengeance", "amertume", "oublier", "culpabilité", "culpabilite"],
    build: () => fmt(
      "Le pardon selon la Bible",
      "Le pardon est au cœur de l'Évangile. Dieu nous a pardonnés gratuitement en Christ, et Il nous demande de pardonner aux autres.\n\n\"Si nous confessons nos péchés, il est fidèle et juste pour nous les pardonner, et pour nous purifier de toute iniquité.\" — **1 Jean 1:9**",
      [
        "**Dieu pardonne complètement** : \"Autant l'orient est éloigné de l'occident, autant il éloigne de nous nos transgressions\" (Psaume 103:12). Dieu ne garde pas le compte de nos fautes confessées.",
        "**Pardonner comme Dieu** : \"Pardonnez-vous réciproquement, comme Dieu vous a pardonné en Christ\" (Éphésiens 4:32). Le pardon n'est pas optionnel pour le chrétien.",
        "**70 fois 7 fois** : Pierre a demandé combien de fois pardonner. Jésus a répondu : 70 fois 7 (Matthieu 18:22). Autrement dit, toujours.",
        "**Le pardon libère** : Le manque de pardon emprisonne celui qui refuse de pardonner, pas l'offenseur. Pardonner, c'est se libérer soi-même.",
        "**Pardonner ne veut pas dire oublier** : C'est choisir de ne plus tenir quelqu'un responsable devant Dieu. La guérison émotionnelle peut prendre du temps.",
        "**La croix, modèle suprême** : \"Père, pardonne-leur, car ils ne savent ce qu'ils font\" (Luc 23:34). Jésus a pardonné ses bourreaux sur la croix."
      ],
      ["1 Jean 1:9", "Éphésiens 4:32", "Matthieu 18:21-22", "Colossiens 3:13", "Psaume 103:12", "Luc 23:34", "Matthieu 6:14-15"],
      "Si tu as du mal à pardonner quelqu'un, commence par le dire à Dieu dans la prière. Écris-le dans ton Carnet de Prière. Parle à ton berger de cellule pour un accompagnement.",
      "Seigneur, merci pour Ton pardon immérité. Aide-nous à pardonner ceux qui nous ont blessés. Libère nos cœurs de toute amertume. Guéris nos blessures profondes. Au nom de Jésus, amen."
    )
  },

  // ============ LOUANGE & ADORATION ============
  {
    theme: "louange",
    keywords: ["louange", "adoration", "adorer", "louez", "louer", "chant", "chanter", "musique", "culte", "glorifier", "gloire", "honneur", "célébration", "celebration", "psaume", "cantique", "worship"],
    build: () => fmt(
      "La louange et l'adoration",
      "La louange est notre réponse à la grandeur de Dieu. L'adoration est l'expression la plus profonde de notre amour pour Lui.\n\n\"Que tout ce qui respire loue l'Éternel !\" — **Psaume 150:6**",
      [
        "**Dieu habite la louange** : \"Tu sièges au milieu des louanges d'Israël\" (Psaume 22:3). Quand nous louons, Dieu manifeste Sa présence.",
        "**La louange est une arme** : Paul et Silas en prison ont loué Dieu, et les chaînes sont tombées (Actes 16:25-26). La louange brise les forteresses.",
        "**Louez en tout temps** : \"Je bénirai l'Éternel en tout temps ; sa louange sera toujours dans ma bouche\" (Psaume 34:1). Même dans l'épreuve, louons-Le.",
        "**L'adoration en esprit et en vérité** : \"Les vrais adorateurs adoreront le Père en esprit et en vérité\" (Jean 4:23-24). L'adoration va au-delà de la musique.",
        "**Le sacrifice de louange** : \"Par lui, offrons sans cesse à Dieu un sacrifice de louange\" (Hébreux 13:15). Parfois, la louange est un acte de foi malgré les circonstances.",
        "**Toute la création loue Dieu** : \"Les cieux racontent la gloire de Dieu\" (Psaume 19:1). Nous rejoignons un concert universel de louange."
      ],
      ["Psaume 150:6", "Psaume 34:1", "Psaume 22:3", "Jean 4:23-24", "Hébreux 13:15", "Actes 16:25-26", "Psaume 100"],
      "Participez au ministère de louange MDC. Louez Dieu chez vous avec de la musique chrétienne. Venez au culte dimanche à 9h au temple de Bonapriso.",
      "Seigneur, Tu es digne de toute louange ! Que notre vie entière soit un cantique à Ta gloire. Remplis nos bouches de Ta louange et nos cœurs de Ton adoration. Amen !"
    )
  },

  // ============ BAPTÊME ============
  {
    theme: "bapteme",
    keywords: ["baptême", "bapteme", "baptiser", "immersion", "eau"],
    build: () => fmt(
      "Le baptême chrétien",
      "Le baptême est un acte d'obéissance et un témoignage public de notre foi en Jésus-Christ.\n\n\"Repentez-vous, et que chacun de vous soit baptisé au nom de Jésus-Christ, pour le pardon de vos péchés.\" — **Actes 2:38**",
      [
        "**Jésus a été baptisé** : \"Alors Jésus vint de la Galilée au Jourdain vers Jean, pour être baptisé par lui\" (Matthieu 3:13). Si Jésus l'a fait, combien plus devons-nous le faire.",
        "**Le baptême symbolise** : notre mort au péché et notre résurrection à une vie nouvelle. \"Nous avons été ensevelis avec lui par le baptême en sa mort, afin que, comme Christ est ressuscité des morts, nous marchions nous aussi en nouveauté de vie\" (Romains 6:4).",
        "**C'est un commandement** : \"Allez, faites de toutes les nations des disciples, les baptisant au nom du Père, du Fils et du Saint-Esprit\" (Matthieu 28:19).",
        "**Le baptême suit la conversion** : On est baptisé après avoir cru, pas avant. \"Celui qui croira et qui sera baptisé sera sauvé\" (Marc 16:16).",
        "**Le baptême du Saint-Esprit** : C'est une expérience distincte. \"Vous serez baptisés du Saint-Esprit dans peu de jours\" (Actes 1:5). Il donne la puissance pour le service."
      ],
      ["Actes 2:38", "Matthieu 3:13-17", "Romains 6:3-4", "Matthieu 28:19", "Marc 16:16", "Actes 1:8"],
      "Si vous n'êtes pas encore baptisé(e), parlez-en au pasteur à MDC. Les baptêmes sont organisés régulièrement.",
      "Seigneur, bénis ceux qui se préparent au baptême. Que cette étape marque un tournant dans leur marche avec Toi. Baptise-nous aussi de Ton Saint-Esprit et de feu. Amen."
    )
  },

  // ============ ÉSAÏE 61 (verset fondateur MDC) ============
  {
    theme: "esaie61",
    keywords: ["esaïe", "esaie", "isaïe", "isaie", "61", "esaie 61", "esaïe 61", "oint", "oindre", "année de grâce", "bonne nouvelle", "cœur brisé", "captif", "prisonnier", "liberté"],
    build: () => fmt(
      "Ésaïe 61:1-3 — Le verset fondateur de MDC",
      "Ce passage est le cœur de l'identité du Ministère des Déterminés pour Christ. C'est la mission que Dieu a confiée à Son Église.\n\n**\"L'Esprit du Seigneur, l'Éternel, est sur moi, car l'Éternel m'a oint pour porter de bonnes nouvelles aux malheureux ; Il m'a envoyé pour guérir ceux qui ont le cœur brisé, pour proclamer aux captifs la liberté, et aux prisonniers la délivrance ; pour publier une année de grâce de l'Éternel.\"** — **Ésaïe 61:1-2**",
      [
        "**\"L'Esprit du Seigneur est sur moi\"** : Cette prophétie a été accomplie par Jésus (Luc 4:18-21). Mais par le Saint-Esprit, elle s'applique aussi à chaque croyant oint pour servir.",
        "**\"Oint pour porter de bonnes nouvelles\"** : L'Évangile est une bonne nouvelle ! Nous sommes appelés à partager l'espérance en Christ avec un monde qui souffre.",
        "**\"Guérir ceux qui ont le cœur brisé\"** : MDC est un lieu de guérison et de restauration. Dieu veut panser les blessures émotionnelles, familiales et spirituelles.",
        "**\"Proclamer la liberté aux captifs\"** : Beaucoup sont captifs du péché, des addictions, de la peur, du passé. En Christ, la liberté est réelle et totale (Jean 8:36).",
        "**\"Publier une année de grâce\"** : C'est l'année de la faveur divine. Dieu veut bénir, restaurer et élever Son peuple.",
        "**Le verset 3 ajoute** : \"Pour accorder aux affligés de Sion... un diadème au lieu de la cendre, une huile de joie au lieu du deuil, un vêtement de louange au lieu d'un esprit abattu.\" Dieu transforme notre tristesse en joie !",
        "**La mission de MDC** : Comme Jésus, nous sommes déterminés à apporter la liberté, la guérison et la grâce à Douala, au Cameroun et au monde entier."
      ],
      ["Ésaïe 61:1-3", "Luc 4:18-21", "Jean 8:36", "2 Corinthiens 3:17", "Ésaïe 61:3", "Ésaïe 61:7"],
      "Médite Ésaïe 61 cette semaine. Demande au Saint-Esprit de t'oindre pour accomplir cette mission dans ta famille, ton quartier et ton lieu de travail à Douala.",
      "Seigneur, que l'Esprit qui était sur Jésus soit aussi sur nous à MDC. Utilise-nous pour guérir les cœurs brisés, libérer les captifs et proclamer Ta grâce dans la ville de Douala et au-delà. Nous sommes déterminés pour Christ ! Amen."
    )
  },

  // ============ AMOUR DE DIEU ============
  {
    theme: "amour",
    keywords: ["amour", "aimer", "amour de dieu", "dieu m'aime", "je suis aimé", "affection", "tendresse", "compassion", "miséricorde", "misericorde", "bonté", "bonte"],
    build: () => fmt(
      "L'amour inconditionnel de Dieu",
      "L'amour de Dieu est le fondement de toute la Bible. Il est infini, inconditionnel et éternel.\n\n\"Car Dieu a tant aimé le monde qu'il a donné son Fils unique, afin que quiconque croit en lui ne périsse point, mais qu'il ait la vie éternelle.\" — **Jean 3:16**",
      [
        "**L'amour de Dieu est premier** : \"Nous l'aimons, parce qu'il nous a aimés le premier\" (1 Jean 4:19). Il nous a aimés avant même que nous le connaissions.",
        "**Rien ne peut nous séparer** : \"Ni la mort, ni la vie, ni les anges, ni les dominations... ne pourra nous séparer de l'amour de Dieu manifesté en Jésus-Christ\" (Romains 8:38-39).",
        "**L'amour parfait chasse la crainte** : \"Il n'y a pas de crainte dans l'amour ; mais l'amour parfait bannit la crainte\" (1 Jean 4:18).",
        "**Dieu EST amour** : \"Celui qui n'aime pas n'a pas connu Dieu, car Dieu est amour\" (1 Jean 4:8). L'amour n'est pas juste ce que Dieu fait, c'est ce qu'Il EST.",
        "**La preuve suprême** : \"Dieu prouve son amour envers nous, en ce que, lorsque nous étions encore des pécheurs, Christ est mort pour nous\" (Romains 5:8).",
        "**Aimer les autres** : \"Aimez-vous les uns les autres, comme je vous ai aimés\" (Jean 15:12). L'amour reçu doit être partagé."
      ],
      ["Jean 3:16", "1 Jean 4:8", "1 Jean 4:19", "Romains 8:38-39", "Romains 5:8", "1 Corinthiens 13:4-7", "Jean 15:12"],
      "Tu es aimé(e) de Dieu tel(le) que tu es, avec tes imperfections. Rien ne peut changer cet amour. Partage cet amour avec les membres de ta cellule MDC.",
      "Père, merci pour Ton amour qui ne faillit jamais. Aide-nous à recevoir cet amour pleinement et à le partager autour de nous à Douala et partout. Au nom de Jésus, amen."
    )
  },

  // ============ GRÂCE ============
  {
    theme: "grace",
    keywords: ["grâce", "grace", "miséricorde", "misericorde", "faveur", "compassion", "pardon de dieu", "gratuit", "oeuvres"],
    build: () => fmt(
      "La grâce de Dieu",
      "La grâce est la faveur imméritée de Dieu. C'est le cœur même de l'Évangile.\n\n\"Car c'est par la grâce que vous êtes sauvés, par le moyen de la foi. Et cela ne vient pas de vous, c'est le don de Dieu.\" — **Éphésiens 2:8**",
      [
        "**La grâce est gratuite** : On ne peut pas la gagner par nos œuvres. \"Ce n'est point par les œuvres, afin que personne ne se glorifie\" (Éphésiens 2:9).",
        "**La grâce suffit** : \"Ma grâce te suffit, car ma puissance s'accomplit dans la faiblesse\" (2 Corinthiens 12:9). Dans nos faiblesses, la grâce de Dieu brille.",
        "**La grâce enseigne** : \"La grâce de Dieu... nous enseigne à renoncer à l'impiété et aux convoitises mondaines\" (Tite 2:11-12). La grâce ne nous rend pas laxistes, elle nous transforme.",
        "**Là où le péché abonde** : \"Là où le péché a abondé, la grâce a surabondé\" (Romains 5:20). Aucun péché n'est plus grand que la grâce de Dieu.",
        "**L'année de grâce** : Ésaïe 61:2 parle de \"l'année de grâce de l'Éternel\". C'est la saison dans laquelle nous vivons — le temps de la faveur de Dieu.",
        "**Grandir dans la grâce** : \"Croissez dans la grâce et dans la connaissance de notre Seigneur et Sauveur Jésus-Christ\" (2 Pierre 3:18)."
      ],
      ["Éphésiens 2:8-9", "2 Corinthiens 12:9", "Romains 5:20", "Tite 2:11-12", "Ésaïe 61:2", "2 Pierre 3:18"],
      "Vis dans la conscience de la grâce chaque jour. Tu n'as pas besoin d'être parfait — Dieu t'a déjà accepté en Christ.",
      "Merci Seigneur pour Ta grâce infinie. Nous ne méritons rien mais Tu nous donnes tout. Aide-nous à vivre dans cette grâce et à la manifester aux autres. Au nom de Jésus, amen."
    )
  },

  // ============ SAGESSE ============
  {
    theme: "sagesse",
    keywords: ["sagesse", "sage", "intelligence", "discernement", "conseil", "décision", "decision", "choix", "direction", "diriger", "volonté de dieu", "volonte de dieu", "plan de dieu", "appel", "vocation", "avenir", "futur", "destin", "destinée", "destinee"],
    build: () => fmt(
      "La sagesse divine et la direction de Dieu",
      "Dieu promet de nous donner la sagesse et de diriger nos pas quand nous la Lui demandons.\n\n\"Si quelqu'un d'entre vous manque de sagesse, qu'il la demande à Dieu, qui donne à tous simplement et sans reproche, et elle lui sera donnée.\" — **Jacques 1:5**",
      [
        "**La sagesse vient de Dieu** : \"Car l'Éternel donne la sagesse ; de sa bouche sortent la connaissance et l'intelligence\" (Proverbes 2:6).",
        "**Confie-toi en l'Éternel** : \"Confie-toi en l'Éternel de tout ton cœur, et ne t'appuie pas sur ta sagesse. Reconnais-le dans toutes tes voies, et il aplanira tes sentiers\" (Proverbes 3:5-6).",
        "**Dieu a un plan pour toi** : \"Car je connais les projets que j'ai formés sur vous, dit l'Éternel, projets de paix et non de malheur, afin de vous donner un avenir et de l'espérance\" (Jérémie 29:11).",
        "**L'Esprit guide** : \"Quand le consolateur sera venu, l'Esprit de vérité, il vous conduira dans toute la vérité\" (Jean 16:13).",
        "**Demande conseil** : \"Les projets s'affermissent par le conseil\" (Proverbes 20:18). Consulte ton pasteur, ton berger de cellule et des chrétiens mûrs.",
        "**La Parole éclaire** : \"Ta parole est une lampe à mes pieds, et une lumière sur mon sentier\" (Psaume 119:105)."
      ],
      ["Jacques 1:5", "Proverbes 3:5-6", "Jérémie 29:11", "Psaume 119:105", "Jean 16:13", "Proverbes 2:6", "Ésaïe 30:21"],
      "Avant toute décision importante, prie, lis la Bible, et consulte ton berger de cellule. Dieu ne te laissera pas dans la confusion.",
      "Seigneur, donne-nous Ta sagesse pour chaque décision de notre vie. Dirige nos pas selon Ton plan parfait. Que Ta volonté soit faite et non la nôtre. Au nom de Jésus, amen."
    )
  },

  // ============ MORT & VIE ÉTERNELLE ============
  {
    theme: "mort",
    keywords: ["mort", "mourir", "décès", "deces", "deuil", "enterrement", "funérailles", "funerailles", "ciel", "paradis", "enfer", "jugement", "résurrection", "resurrection", "vie éternelle", "vie eternelle", "après la mort", "apres la mort", "défunt", "defunt"],
    build: () => fmt(
      "La mort, la résurrection et la vie éternelle",
      "Pour le chrétien, la mort n'est pas la fin mais le début de l'éternité avec Dieu.\n\n\"Je suis la résurrection et la vie. Celui qui croit en moi vivra, quand même il serait mort.\" — **Jean 11:25**",
      [
        "**La mort est vaincue** : \"O mort, où est ta victoire ? O mort, où est ton aiguillon ?\" (1 Corinthiens 15:55). Par la résurrection de Christ, la mort a perdu son pouvoir.",
        "**La vie éternelle est promise** : \"Car Dieu a tant aimé le monde qu'il a donné son Fils unique, afin que quiconque croit en lui ne périsse point, mais qu'il ait la vie éternelle\" (Jean 3:16).",
        "**Le ciel nous attend** : \"Il essuiera toute larme de leurs yeux, et la mort ne sera plus, et il n'y aura plus ni deuil, ni cri, ni douleur\" (Apocalypse 21:4).",
        "**Absents du corps, présents avec le Seigneur** : \"Nous aimons mieux quitter ce corps et demeurer auprès du Seigneur\" (2 Corinthiens 5:8). Les croyants qui meurent sont immédiatement avec Christ.",
        "**Consolation dans le deuil** : \"L'Éternel est près de ceux qui ont le cœur brisé\" (Psaume 34:18). Dieu console ceux qui pleurent un être cher.",
        "**La résurrection à venir** : \"Car le Seigneur lui-même descendra du ciel... et les morts en Christ ressusciteront premièrement\" (1 Thessaloniciens 4:16-17)."
      ],
      ["Jean 11:25-26", "1 Corinthiens 15:55-57", "Apocalypse 21:4", "2 Corinthiens 5:8", "Psaume 34:18", "1 Thessaloniciens 4:16-17", "Jean 14:2-3"],
      "Si tu traverses un deuil, sache que Dieu est près de toi. N'hésite pas à contacter ton berger de cellule MDC pour un soutien. Le deuil est un processus — donne-toi le temps de guérir.",
      "Père, nous te confions ceux qui sont dans le deuil. Console-les par Ton Esprit. Donne-leur l'espérance de la résurrection et la certitude que leurs proches en Christ sont dans Ta présence. Au nom de Jésus, amen."
    )
  },
];

// Recherche le meilleur thème pour une question donnée
export function findTheme(question: string): ThemeResponse | null {
  const q = question.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  let bestMatch: ThemeResponse | null = null;
  let bestScore = 0;

  for (const theme of THEMES) {
    let score = 0;
    for (const kw of theme.keywords) {
      const kwNorm = kw.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      if (q.includes(kwNorm)) {
        score += kwNorm.length; // Les mots-clés plus longs ont plus de poids
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = theme;
    }
  }
  return bestMatch;
}
