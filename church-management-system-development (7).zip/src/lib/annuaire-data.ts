// V2.2 — Annuaire membres opt-in
import { uid } from "./data";

export interface ProfilAnnuaire {
  id: string;
  userId: string;
  nom: string;
  photoUrl?: string;
  role: "MEMBRE" | "BERGER" | "PASTEUR";
  whatsapp: string;
  quartier: string;
  visibleAnnuaire: boolean;
  dateCreation: string;
}

const ANNUAIRE_KEY = "mdc_annuaire";

const SEED_ANNUAIRE: ProfilAnnuaire[] = [
  { id: "a1", userId: "u1", nom: "Pasteur Emmanuel Biaya", role: "PASTEUR", whatsapp: "+237658842522", quartier: "Bonapriso", visibleAnnuaire: true, dateCreation: "2024-01-15" },
  { id: "a2", userId: "u3", nom: "Sœur Esther Mbongo", role: "MEMBRE", whatsapp: "+237699000003", quartier: "Akwa", visibleAnnuaire: true, dateCreation: "2024-02-01" },
  { id: "a3", userId: "u4", nom: "Frère Joseph Tcheppo", role: "BERGER", whatsapp: "+237691456789", quartier: "Bonamoussadi", visibleAnnuaire: true, dateCreation: "2024-03-10" },
  { id: "a4", userId: "u5", nom: "Frère Paul Nkeng", role: "MEMBRE", whatsapp: "+237699000005", quartier: "Ndokoti", visibleAnnuaire: false, dateCreation: "2024-05-20" },
];

export function loadAnnuaire(): ProfilAnnuaire[] {
  try {
    const raw = localStorage.getItem(ANNUAIRE_KEY);
    if (!raw) {
      localStorage.setItem(ANNUAIRE_KEY, JSON.stringify(SEED_ANNUAIRE));
      return SEED_ANNUAIRE;
    }
    return JSON.parse(raw);
  } catch {
    return SEED_ANNUAIRE;
  }
}

export function saveAnnuaire(profils: ProfilAnnuaire[]): void {
  localStorage.setItem(ANNUAIRE_KEY, JSON.stringify(profils));
}

export function getProfilsVisibles(): ProfilAnnuaire[] {
  return loadAnnuaire().filter((p) => p.visibleAnnuaire);
}

export function getMonProfil(userId: string): ProfilAnnuaire | undefined {
  return loadAnnuaire().find((p) => p.userId === userId);
}

export function saveMonProfil(userId: string, data: Partial<ProfilAnnuaire>): ProfilAnnuaire {
  const all = loadAnnuaire();
  const idx = all.findIndex((p) => p.userId === userId);
  if (idx >= 0) {
    Object.assign(all[idx], data);
    saveAnnuaire(all);
    return all[idx];
  }
  const nouveau: ProfilAnnuaire = {
    id: uid("a"),
    userId,
    nom: data.nom || "",
    role: (data.role as ProfilAnnuaire["role"]) || "MEMBRE",
    whatsapp: data.whatsapp || "",
    quartier: data.quartier || "",
    visibleAnnuaire: data.visibleAnnuaire ?? false,
    photoUrl: data.photoUrl,
    dateCreation: new Date().toISOString(),
  };
  all.push(nouveau);
  saveAnnuaire(all);
  return nouveau;
}
