// V2.2 — Cache offline pour médias (audios, PDF)
// Stockage IndexedDB via une API simple clé-valeur
// Limite : 5 audios + 5 PDF = ~200 Mo max

const DB_NAME = "mdc-offline-media";
const STORE_NAME = "medias";
const MAX_ITEMS = 10;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function cacheMedia(id: string, blob: Blob): Promise<void> {
  const db = await openDB();
  // Vérifier la limite avant d'ajouter
  const keys = await getAllKeys(db);
  if (keys.length >= MAX_ITEMS) {
    // Supprimer le plus ancien
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).delete(keys[0]);
    await new Promise((r) => { tx.oncomplete = r; });
  }
  const tx = db.transaction(STORE_NAME, "readwrite");
  tx.objectStore(STORE_NAME).put(blob, id);
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getCachedMedia(id: string): Promise<Blob | null> {
  const db = await openDB();
  const tx = db.transaction(STORE_NAME, "readonly");
  const request = tx.objectStore(STORE_NAME).get(id);
  return new Promise((resolve) => {
    request.onsuccess = () => resolve(request.result ?? null);
    request.onerror = () => resolve(null);
  });
}

export async function isCached(id: string): Promise<boolean> {
  const blob = await getCachedMedia(id);
  return blob !== null;
}

export async function removeCached(id: string): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(STORE_NAME, "readwrite");
  tx.objectStore(STORE_NAME).delete(id);
  return new Promise<void>((r) => { tx.oncomplete = () => r(); });
}

export async function getCachedIds(): Promise<string[]> {
  const db = await openDB();
  return getAllKeys(db);
}

function getAllKeys(db: IDBDatabase): Promise<string[]> {
  const tx = db.transaction(STORE_NAME, "readonly");
  const request = tx.objectStore(STORE_NAME).getAllKeys();
  return new Promise((resolve) => {
    request.onsuccess = () => resolve(request.result.map(String));
    request.onerror = () => resolve([]);
  });
}
