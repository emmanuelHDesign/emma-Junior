import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { loadDB, saveDB, uid, type Role, type User } from "./data";

interface AuthCtx {
  user: User | null;
  login: (email: string, password: string, rememberMe?: boolean) => { success: boolean; message: string; needs2FA?: boolean };
  verify2FA: (code: string) => boolean;
  logout: () => void;
  signup: (data: SignupData) => { success: boolean; message: string };
  forgotPassword: (email: string) => { success: boolean; message: string; resetToken?: string };
  resetPassword: (token: string, newPassword: string) => { success: boolean; message: string };
  updateProfile: (updates: Partial<User>) => boolean;
  changePassword: (oldPwd: string, newPwd: string) => { success: boolean; message: string };
  hasPermission: (p: Permission) => boolean;
}

export interface SignupData {
  nom: string;
  email: string;
  password: string;
  telephone: string;
}

export type Permission =
  | "voir_finances"
  | "enregistrer_dime"
  | "voir_tous_membres"
  | "gerer_membres"
  | "voir_cellule_seulement"
  | "envoyer_messages"
  | "gerer_evenements"
  | "voir_dashboard_pasteur"
  | "gerer_utilisateurs";

const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  ADMIN: ["voir_finances", "enregistrer_dime", "voir_tous_membres", "gerer_membres", "envoyer_messages", "gerer_evenements", "voir_dashboard_pasteur", "gerer_utilisateurs"],
  PASTEUR: ["voir_finances", "enregistrer_dime", "voir_tous_membres", "gerer_membres", "envoyer_messages", "gerer_evenements", "voir_dashboard_pasteur"],
  SECRETAIRE: ["enregistrer_dime", "voir_tous_membres", "gerer_membres", "envoyer_messages", "gerer_evenements"],
  CHEF_CELLULE: ["voir_cellule_seulement"],
  MEMBRE: [],
};

const AuthContext = createContext<AuthCtx | null>(null);

// Stockage des tokens de reset (en prod : table DB avec expiration)
const resetTokens = new Map<string, { userId: string; expiresAt: number }>();
// Stockage 2FA en attente
let pending2FA: { userId: string; expiresAt: number } | null = null;

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const id = localStorage.getItem("mdc_current_user") || sessionStorage.getItem("mdc_current_user");
    if (id) {
      const db = loadDB();
      const u = db.users.find((x) => x.id === id);
      if (u && u.actif) setUser(u);
    }
  }, []);

  // ====== LOGIN avec mot de passe + Remember Me ======
  const login = (email: string, password: string, rememberMe = false) => {
    const db = loadDB();
    const u = db.users.find((x) => x.email.toLowerCase() === email.toLowerCase());

    // Log tentative
    db.loginHistory.unshift({
      id: uid("lh"),
      userId: u?.id || "unknown",
      date: new Date().toISOString(),
      ip: "127.0.0.1",
      device: navigator.userAgent.split(" ")[0] || "Web",
      success: false,
    });
    if (db.loginHistory.length > 100) db.loginHistory.length = 100;

    if (!u) {
      saveDB(db);
      return { success: false, message: "Aucun compte trouvé avec cet email." };
    }

    if (!u.actif) {
      saveDB(db);
      return { success: false, message: "Ce compte a été désactivé. Contactez l'administrateur." };
    }

    if (u.password !== password) {
      saveDB(db);
      return { success: false, message: "Mot de passe incorrect." };
    }

    // Login réussi
    db.loginHistory[0].success = true;
    u.derniereConnexion = new Date().toISOString();
    saveDB(db);

    // Si 2FA activé, mettre en attente
    if (u.deuxFacteurs) {
      pending2FA = { userId: u.id, expiresAt: Date.now() + 5 * 60 * 1000 };
      return { success: true, message: "Code 2FA envoyé par SMS", needs2FA: true };
    }

    // Connexion finale
    setUser(u);
    const storage = rememberMe ? localStorage : sessionStorage;
    storage.setItem("mdc_current_user", u.id);
    if (rememberMe) sessionStorage.removeItem("mdc_current_user");
    else localStorage.removeItem("mdc_current_user");

    return { success: true, message: "Connexion réussie !" };
  };

  // ====== Vérification 2FA ======
  const verify2FA = (code: string): boolean => {
    if (!pending2FA || Date.now() > pending2FA.expiresAt) {
      pending2FA = null;
      return false;
    }
    // Code démo : 123456
    if (code !== "123456") return false;

    const db = loadDB();
    const u = db.users.find((x) => x.id === pending2FA!.userId);
    if (!u) return false;

    setUser(u);
    localStorage.setItem("mdc_current_user", u.id);
    pending2FA = null;
    return true;
  };

  // ====== INSCRIPTION ======
  const signup = (data: SignupData) => {
    const db = loadDB();

    // Vérifications
    if (data.password.length < 6) {
      return { success: false, message: "Le mot de passe doit faire au moins 6 caractères." };
    }
    if (!data.email.includes("@")) {
      return { success: false, message: "Email invalide." };
    }
    if (db.users.find((x) => x.email.toLowerCase() === data.email.toLowerCase())) {
      return { success: false, message: "Cet email est déjà utilisé." };
    }

    // Nouveau compte (par défaut : MEMBRE, à activer par l'admin)
    const newUser: User = {
      id: uid("u"),
      nom: data.nom,
      email: data.email,
      password: data.password,
      telephone: data.telephone,
      role: "MEMBRE",
      deuxFacteurs: false,
      dateCreation: new Date().toISOString(),
      actif: true, // En prod : false jusqu'à validation admin
    };

    db.users.push(newUser);

    // Notification admin
    db.notifications.unshift({
      id: uid("n"),
      type: "info",
      titre: "Nouveau compte créé",
      message: `${data.nom} (${data.email}) vient de s'inscrire à MDC.`,
      date: new Date().toISOString(),
      lu: false,
      lien: "/utilisateurs",
    });

    saveDB(db);
    return { success: true, message: "Compte créé avec succès ! Vous pouvez vous connecter." };
  };

  // ====== MOT DE PASSE OUBLIÉ ======
  const forgotPassword = (email: string) => {
    const db = loadDB();
    const u = db.users.find((x) => x.email.toLowerCase() === email.toLowerCase());

    if (!u) {
      // Pour des raisons de sécurité, ne pas révéler si l'email existe
      return { success: true, message: "Si cet email existe, un lien de réinitialisation sera envoyé." };
    }

    // Générer un token
    const token = uid("rst").replace("rst_", "");
    resetTokens.set(token, { userId: u.id, expiresAt: Date.now() + 30 * 60 * 1000 });

    return {
      success: true,
      message: `Email envoyé à ${email}. (Démo : token affiché ci-dessous)`,
      resetToken: token,
    };
  };

  const resetPassword = (token: string, newPassword: string) => {
    const data = resetTokens.get(token);
    if (!data || Date.now() > data.expiresAt) {
      return { success: false, message: "Lien invalide ou expiré." };
    }
    if (newPassword.length < 6) {
      return { success: false, message: "Le mot de passe doit faire au moins 6 caractères." };
    }

    const db = loadDB();
    const u = db.users.find((x) => x.id === data.userId);
    if (!u) return { success: false, message: "Utilisateur introuvable." };

    u.password = newPassword;
    saveDB(db);
    resetTokens.delete(token);
    return { success: true, message: "Mot de passe réinitialisé avec succès !" };
  };

  // ====== UPDATE PROFIL ======
  const updateProfile = (updates: Partial<User>): boolean => {
    if (!user) return false;
    const db = loadDB();
    const u = db.users.find((x) => x.id === user.id);
    if (!u) return false;
    Object.assign(u, updates);
    saveDB(db);
    setUser({ ...u });
    return true;
  };

  const changePassword = (oldPwd: string, newPwd: string) => {
    if (!user) return { success: false, message: "Non connecté." };
    if (user.password !== oldPwd) return { success: false, message: "Ancien mot de passe incorrect." };
    if (newPwd.length < 6) return { success: false, message: "Nouveau mot de passe trop court (min 6 car.)." };
    updateProfile({ password: newPwd });
    return { success: true, message: "Mot de passe modifié !" };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("mdc_current_user");
    sessionStorage.removeItem("mdc_current_user");
    pending2FA = null;
  };

  const hasPermission = (p: Permission): boolean => {
    if (!user) return false;
    return ROLE_PERMISSIONS[user.role].includes(p);
  };

  return (
    <AuthContext.Provider value={{
      user, login, verify2FA, logout, signup,
      forgotPassword, resetPassword, updateProfile, changePassword,
      hasPermission
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthCtx {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
