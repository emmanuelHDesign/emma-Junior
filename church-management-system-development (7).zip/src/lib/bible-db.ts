// V3.1 — Base de données biblique complète pour Esaïe IA
// 66 livres, thèmes majeurs, versets clés avec explications détaillées
// Bible Louis Segond 1910

// ============================================================
// STRUCTURE : Thèmes bibliques avec versets + explications
// ============================================================

export interface VersetBiblique {
  reference: string;
  texte: string;
  livre: string;
  chapitre: number;
  verset: number;
}

export interface ThemeBiblique {
  id: string;
  theme: string;
  motsClés: string[];
  versets: VersetBiblique[];
  explication: string;
  application: string;
  priere: string;
}

// ============================================================
// VERSETS CLÉS PAR LIVRE (sélection exhaustive)
// ============================================================

export const VERSETS_CLES: Record<string, VersetBiblique[]> = {
  genese: [
    { reference: "Genèse 1:1", texte: "Au commencement, Dieu créa les cieux et la terre.", livre: "Genèse", chapitre: 1, verset: 1 },
    { reference: "Genèse 1:27", texte: "Dieu créa l'homme à son image, il le créa à l'image de Dieu, il créa l'homme et la femme.", livre: "Genèse", chapitre: 1, verset: 27 },
    { reference: "Genèse 2:24", texte: "C'est pourquoi l'homme quittera son père et sa mère, et s'attachera à sa femme, et ils deviendront une seule chair.", livre: "Genèse", chapitre: 2, verset: 24 },
    { reference: "Genèse 12:2", texte: "Je ferai de toi une grande nation, et je te bénirai ; je rendrai ton nom grand, et tu seras une source de bénédiction.", livre: "Genèse", chapitre: 12, verset: 2 },
    { reference: "Genèse 15:6", texte: "Abram eut confiance en l'Éternel, qui le lui imputa à justice.", livre: "Genèse", chapitre: 15, verset: 6 },
    { reference: "Genèse 28:15", texte: "Voici, je suis avec toi, je te garderai partout où tu iras.", livre: "Genèse", chapitre: 28, verset: 15 },
    { reference: "Genèse 50:20", texte: "Vous aviez médité de me faire du mal : Dieu l'a changé en bien, pour accomplir ce qui arrive aujourd'hui, pour sauver la vie à un peuple nombreux.", livre: "Genèse", chapitre: 50, verset: 20 },
  ],
  exode: [
    { reference: "Exode 3:14", texte: "Dieu dit à Moïse : Je suis celui qui suis.", livre: "Exode", chapitre: 3, verset: 14 },
    { reference: "Exode 14:14", texte: "L'Éternel combattra pour vous ; et vous, gardez le silence.", livre: "Exode", chapitre: 14, verset: 14 },
    { reference: "Exode 15:26", texte: "Car je suis l'Éternel, qui te guérit.", livre: "Exode", chapitre: 15, verset: 26 },
    { reference: "Exode 20:3", texte: "Tu n'auras pas d'autres dieux devant ma face.", livre: "Exode", chapitre: 20, verset: 3 },
  ],
  josue: [
    { reference: "Josué 1:8", texte: "Que ce livre de la loi ne s'éloigne point de ta bouche ; médite-le jour et nuit, pour agir fidèlement selon tout ce qui y est écrit.", livre: "Josué", chapitre: 1, verset: 8 },
    { reference: "Josué 1:9", texte: "Ne t'ai-je pas donné cet ordre : Fortifie-toi et prends courage ? Ne t'effraie point et ne t'épouvante point, car l'Éternel, ton Dieu, est avec toi dans tout ce que tu entreprendras.", livre: "Josué", chapitre: 1, verset: 9 },
    { reference: "Josué 24:15", texte: "Moi et ma maison, nous servirons l'Éternel.", livre: "Josué", chapitre: 24, verset: 15 },
  ],
  psaumes: [
    { reference: "Psaume 1:1-2", texte: "Heureux l'homme qui ne marche pas selon le conseil des méchants... Mais qui trouve son plaisir dans la loi de l'Éternel, et qui la médite jour et nuit !", livre: "Psaumes", chapitre: 1, verset: 1 },
    { reference: "Psaume 23:1", texte: "L'Éternel est mon berger : je ne manquerai de rien.", livre: "Psaumes", chapitre: 23, verset: 1 },
    { reference: "Psaume 23:4", texte: "Quand je marche dans la vallée de l'ombre de la mort, je ne crains aucun mal, car tu es avec moi.", livre: "Psaumes", chapitre: 23, verset: 4 },
    { reference: "Psaume 27:1", texte: "L'Éternel est ma lumière et mon salut : de qui aurais-je crainte ?", livre: "Psaumes", chapitre: 27, verset: 1 },
    { reference: "Psaume 34:18", texte: "L'Éternel est près de ceux qui ont le cœur brisé, et il sauve ceux qui ont l'esprit dans l'abattement.", livre: "Psaumes", chapitre: 34, verset: 18 },
    { reference: "Psaume 37:4", texte: "Fais de l'Éternel tes délices, et il te donnera ce que ton cœur désire.", livre: "Psaumes", chapitre: 37, verset: 4 },
    { reference: "Psaume 46:10", texte: "Arrêtez, et sachez que je suis Dieu.", livre: "Psaumes", chapitre: 46, verset: 10 },
    { reference: "Psaume 51:12", texte: "O Dieu ! crée en moi un cœur pur, renouvelle en moi un esprit bien disposé.", livre: "Psaumes", chapitre: 51, verset: 12 },
    { reference: "Psaume 91:1-2", texte: "Celui qui demeure sous l'abri du Très-Haut repose à l'ombre du Tout-Puissant. Je dis à l'Éternel : Mon refuge et ma forteresse, mon Dieu en qui je me confie !", livre: "Psaumes", chapitre: 91, verset: 1 },
    { reference: "Psaume 103:2-3", texte: "Mon âme, bénis l'Éternel, et n'oublie aucun de ses bienfaits ! C'est lui qui pardonne toutes tes iniquités, qui guérit toutes tes maladies.", livre: "Psaumes", chapitre: 103, verset: 2 },
    { reference: "Psaume 119:105", texte: "Ta parole est une lampe à mes pieds, et une lumière sur mon sentier.", livre: "Psaumes", chapitre: 119, verset: 105 },
    { reference: "Psaume 121:1-2", texte: "Je lève mes yeux vers les montagnes... D'où me viendra le secours ? Mon secours vient de l'Éternel, qui a fait les cieux et la terre.", livre: "Psaumes", chapitre: 121, verset: 1 },
    { reference: "Psaume 139:14", texte: "Je te loue de ce que je suis une créature si merveilleuse. Tes œuvres sont admirables, et mon âme le reconnaît bien.", livre: "Psaumes", chapitre: 139, verset: 14 },
    { reference: "Psaume 150:6", texte: "Que tout ce qui respire loue l'Éternel ! Louez l'Éternel !", livre: "Psaumes", chapitre: 150, verset: 6 },
  ],
  proverbes: [
    { reference: "Proverbes 3:5-6", texte: "Confie-toi en l'Éternel de tout ton cœur, et ne t'appuie pas sur ta sagesse. Reconnais-le dans toutes tes voies, et il aplanira tes sentiers.", livre: "Proverbes", chapitre: 3, verset: 5 },
    { reference: "Proverbes 3:9-10", texte: "Honore l'Éternel avec tes biens, et avec les prémices de tout ton revenu : alors tes greniers seront remplis d'abondance.", livre: "Proverbes", chapitre: 3, verset: 9 },
    { reference: "Proverbes 11:25", texte: "L'âme bienfaisante sera rassasiée, et celui qui arrose sera lui-même arrosé.", livre: "Proverbes", chapitre: 11, verset: 25 },
    { reference: "Proverbes 18:21", texte: "La mort et la vie sont au pouvoir de la langue ; quiconque l'aime en mangera les fruits.", livre: "Proverbes", chapitre: 18, verset: 21 },
    { reference: "Proverbes 22:6", texte: "Instruis l'enfant selon la voie qu'il doit suivre ; et quand il sera vieux, il ne s'en détournera pas.", livre: "Proverbes", chapitre: 22, verset: 6 },
    { reference: "Proverbes 31:10", texte: "Qui peut trouver une femme vertueuse ? Elle a bien plus de valeur que les perles.", livre: "Proverbes", chapitre: 31, verset: 10 },
  ],
  esaie: [
    { reference: "Ésaïe 6:8", texte: "J'entendis la voix du Seigneur, disant : Qui enverrai-je, et qui marchera pour nous ? Je répondis : Me voici, envoie-moi.", livre: "Ésaïe", chapitre: 6, verset: 8 },
    { reference: "Ésaïe 40:31", texte: "Ceux qui se confient en l'Éternel renouvellent leur force. Ils prennent le vol comme les aigles ; ils courent, et ne se lassent point ; ils marchent, et ne se fatiguent point.", livre: "Ésaïe", chapitre: 40, verset: 31 },
    { reference: "Ésaïe 41:10", texte: "Ne crains rien, car je suis avec toi ; ne promène pas des regards inquiets, car je suis ton Dieu ; je te fortifie, je viens à ton secours, je te soutiens de ma droite triomphante.", livre: "Ésaïe", chapitre: 41, verset: 10 },
    { reference: "Ésaïe 43:2", texte: "Si tu traverses les eaux, je serai avec toi ; et les fleuves, ils ne te submergeront point ; si tu marches dans le feu, tu ne te brûleras pas.", livre: "Ésaïe", chapitre: 43, verset: 2 },
    { reference: "Ésaïe 53:5", texte: "Mais il était blessé pour nos péchés, brisé pour nos iniquités ; le châtiment qui nous donne la paix est tombé sur lui, et c'est par ses meurtrissures que nous sommes guéris.", livre: "Ésaïe", chapitre: 53, verset: 5 },
    { reference: "Ésaïe 54:17", texte: "Toute arme forgée contre toi sera sans effet ; et toute langue qui s'élèvera en justice contre toi, tu la condamneras.", livre: "Ésaïe", chapitre: 54, verset: 17 },
    { reference: "Ésaïe 55:11", texte: "Ainsi en est-il de ma parole, qui sort de ma bouche : elle ne retourne point à moi sans effet.", livre: "Ésaïe", chapitre: 55, verset: 11 },
    { reference: "Ésaïe 61:1-3", texte: "L'Esprit du Seigneur, l'Éternel, est sur moi, car l'Éternel m'a oint pour porter de bonnes nouvelles aux malheureux ; il m'a envoyé pour guérir ceux qui ont le cœur brisé, pour proclamer aux captifs la liberté, et aux prisonniers la délivrance ; pour publier une année de grâce de l'Éternel.", livre: "Ésaïe", chapitre: 61, verset: 1 },
  ],
  jeremie: [
    { reference: "Jérémie 29:11", texte: "Car je connais les projets que j'ai formés sur vous, dit l'Éternel, projets de paix et non de malheur, afin de vous donner un avenir et de l'espérance.", livre: "Jérémie", chapitre: 29, verset: 11 },
    { reference: "Jérémie 33:3", texte: "Invoque-moi, et je te répondrai ; je t'annoncerai de grandes choses, des choses cachées, que tu ne connais pas.", livre: "Jérémie", chapitre: 33, verset: 3 },
    { reference: "Jérémie 1:5", texte: "Avant que je t'eusse formé dans le ventre de ta mère, je te connaissais, et avant que tu fusses sorti de son sein, je t'avais consacré.", livre: "Jérémie", chapitre: 1, verset: 5 },
  ],
  malachie: [
    { reference: "Malachie 3:10", texte: "Apportez à la maison du trésor toutes les dîmes, afin qu'il y ait de la nourriture dans ma maison ; mettez-moi de la sorte à l'épreuve, dit l'Éternel des armées. Et vous verrez si je n'ouvre pas pour vous les écluses des cieux.", livre: "Malachie", chapitre: 3, verset: 10 },
  ],
  matthieu: [
    { reference: "Matthieu 5:14", texte: "Vous êtes la lumière du monde. Une ville située sur une montagne ne peut être cachée.", livre: "Matthieu", chapitre: 5, verset: 14 },
    { reference: "Matthieu 6:9-13", texte: "Voici donc comment vous devez prier : Notre Père qui es aux cieux ! Que ton nom soit sanctifié ; que ton règne vienne ; que ta volonté soit faite sur la terre comme au ciel. Donne-nous aujourd'hui notre pain quotidien ; pardonne-nous nos offenses, comme nous aussi nous pardonnons à ceux qui nous ont offensés ; ne nous induis pas en tentation, mais délivre-nous du malin.", livre: "Matthieu", chapitre: 6, verset: 9 },
    { reference: "Matthieu 6:33", texte: "Cherchez premièrement le royaume et la justice de Dieu ; et toutes ces choses vous seront données par-dessus.", livre: "Matthieu", chapitre: 6, verset: 33 },
    { reference: "Matthieu 7:7", texte: "Demandez, et l'on vous donnera ; cherchez, et vous trouverez ; frappez, et l'on vous ouvrira.", livre: "Matthieu", chapitre: 7, verset: 7 },
    { reference: "Matthieu 11:28", texte: "Venez à moi, vous tous qui êtes fatigués et chargés, et je vous donnerai du repos.", livre: "Matthieu", chapitre: 11, verset: 28 },
    { reference: "Matthieu 17:20", texte: "Si vous aviez de la foi comme un grain de sénevé, vous diriez à cette montagne : Transporte-toi d'ici là, et elle se transporterait ; rien ne vous serait impossible.", livre: "Matthieu", chapitre: 17, verset: 20 },
    { reference: "Matthieu 18:20", texte: "Car là où deux ou trois sont assemblés en mon nom, je suis au milieu d'eux.", livre: "Matthieu", chapitre: 18, verset: 20 },
    { reference: "Matthieu 19:26", texte: "Jésus les regarda, et leur dit : Aux hommes cela est impossible, mais à Dieu tout est possible.", livre: "Matthieu", chapitre: 19, verset: 26 },
    { reference: "Matthieu 28:19-20", texte: "Allez, faites de toutes les nations des disciples, les baptisant au nom du Père, du Fils et du Saint-Esprit, et enseignez-leur à observer tout ce que je vous ai prescrit. Et voici, je suis avec vous tous les jours, jusqu'à la fin du monde.", livre: "Matthieu", chapitre: 28, verset: 19 },
  ],
  jean: [
    { reference: "Jean 1:1", texte: "Au commencement était la Parole, et la Parole était avec Dieu, et la Parole était Dieu.", livre: "Jean", chapitre: 1, verset: 1 },
    { reference: "Jean 3:16", texte: "Car Dieu a tant aimé le monde qu'il a donné son Fils unique, afin que quiconque croit en lui ne périsse point, mais qu'il ait la vie éternelle.", livre: "Jean", chapitre: 3, verset: 16 },
    { reference: "Jean 8:32", texte: "Vous connaîtrez la vérité, et la vérité vous affranchira.", livre: "Jean", chapitre: 8, verset: 32 },
    { reference: "Jean 8:36", texte: "Si donc le Fils vous affranchit, vous serez réellement libres.", livre: "Jean", chapitre: 8, verset: 36 },
    { reference: "Jean 10:10", texte: "Le voleur ne vient que pour dérober, égorger et détruire ; moi, je suis venu afin que les brebis aient la vie, et qu'elles soient dans l'abondance.", livre: "Jean", chapitre: 10, verset: 10 },
    { reference: "Jean 11:25-26", texte: "Je suis la résurrection et la vie. Celui qui croit en moi vivra, quand même il serait mort ; et quiconque vit et croit en moi ne mourra jamais.", livre: "Jean", chapitre: 11, verset: 25 },
    { reference: "Jean 14:6", texte: "Jésus lui dit : Je suis le chemin, la vérité, et la vie. Nul ne vient au Père que par moi.", livre: "Jean", chapitre: 14, verset: 6 },
    { reference: "Jean 14:27", texte: "Je vous laisse la paix, je vous donne ma paix. Je ne vous donne pas comme le monde donne. Que votre cœur ne se trouble point, et ne s'alarme point.", livre: "Jean", chapitre: 14, verset: 27 },
    { reference: "Jean 15:5", texte: "Je suis le cep, vous êtes les sarments. Celui qui demeure en moi et en qui je demeure porte beaucoup de fruit.", livre: "Jean", chapitre: 15, verset: 5 },
    { reference: "Jean 16:33", texte: "Je vous ai dit ces choses, afin que vous ayez la paix en moi. Vous aurez des tribulations dans le monde ; mais prenez courage, j'ai vaincu le monde.", livre: "Jean", chapitre: 16, verset: 33 },
  ],
  romains: [
    { reference: "Romains 3:23", texte: "Car tous ont péché et sont privés de la gloire de Dieu.", livre: "Romains", chapitre: 3, verset: 23 },
    { reference: "Romains 5:8", texte: "Mais Dieu prouve son amour envers nous, en ce que, lorsque nous étions encore des pécheurs, Christ est mort pour nous.", livre: "Romains", chapitre: 5, verset: 8 },
    { reference: "Romains 6:23", texte: "Car le salaire du péché, c'est la mort ; mais le don gratuit de Dieu, c'est la vie éternelle en Jésus-Christ notre Seigneur.", livre: "Romains", chapitre: 6, verset: 23 },
    { reference: "Romains 8:1", texte: "Il n'y a donc maintenant aucune condamnation pour ceux qui sont en Jésus-Christ.", livre: "Romains", chapitre: 8, verset: 1 },
    { reference: "Romains 8:28", texte: "Nous savons, du reste, que toutes choses concourent au bien de ceux qui aiment Dieu, de ceux qui sont appelés selon son dessein.", livre: "Romains", chapitre: 8, verset: 28 },
    { reference: "Romains 8:31", texte: "Si Dieu est pour nous, qui sera contre nous ?", livre: "Romains", chapitre: 8, verset: 31 },
    { reference: "Romains 8:37-39", texte: "Mais dans toutes ces choses nous sommes plus que vainqueurs par celui qui nous a aimés. Car j'ai l'assurance que ni la mort ni la vie, ni les anges ni les dominations, ni les choses présentes ni les choses à venir, ne pourra nous séparer de l'amour de Dieu manifesté en Jésus-Christ notre Seigneur.", livre: "Romains", chapitre: 8, verset: 37 },
    { reference: "Romains 10:9", texte: "Si tu confesses de ta bouche le Seigneur Jésus, et si tu crois dans ton cœur que Dieu l'a ressuscité des morts, tu seras sauvé.", livre: "Romains", chapitre: 10, verset: 9 },
    { reference: "Romains 10:17", texte: "Ainsi la foi vient de ce qu'on entend, et ce qu'on entend vient de la parole de Christ.", livre: "Romains", chapitre: 10, verset: 17 },
    { reference: "Romains 12:2", texte: "Ne vous conformez pas au siècle présent, mais soyez transformés par le renouvellement de l'intelligence.", livre: "Romains", chapitre: 12, verset: 2 },
  ],
  corinthiens1: [
    { reference: "1 Corinthiens 10:13", texte: "Aucune tentation ne vous est survenue qui n'ait été humaine, et Dieu, qui est fidèle, ne permettra pas que vous soyez tentés au-delà de vos forces.", livre: "1 Corinthiens", chapitre: 10, verset: 13 },
    { reference: "1 Corinthiens 13:4-7", texte: "L'amour est patient, il est plein de bonté ; l'amour n'est point envieux ; l'amour ne se vante point, il ne s'enfle point d'orgueil. Il ne fait rien de malhonnête, il ne cherche point son intérêt, il ne s'irrite point, il ne soupçonne point le mal. Il ne se réjouit point de l'injustice, mais il se réjouit de la vérité. Il excuse tout, il croit tout, il espère tout, il supporte tout.", livre: "1 Corinthiens", chapitre: 13, verset: 4 },
    { reference: "1 Corinthiens 15:55-57", texte: "O mort, où est ta victoire ? O mort, où est ton aiguillon ? L'aiguillon de la mort, c'est le péché. Mais grâces soient rendues à Dieu, qui nous donne la victoire par notre Seigneur Jésus-Christ.", livre: "1 Corinthiens", chapitre: 15, verset: 55 },
  ],
  corinthiens2: [
    { reference: "2 Corinthiens 4:17", texte: "Car nos légères afflictions du moment présent produisent pour nous, au-delà de toute mesure, un poids éternel de gloire.", livre: "2 Corinthiens", chapitre: 4, verset: 17 },
    { reference: "2 Corinthiens 5:17", texte: "Si quelqu'un est en Christ, il est une nouvelle créature. Les choses anciennes sont passées ; voici, toutes choses sont devenues nouvelles.", livre: "2 Corinthiens", chapitre: 5, verset: 17 },
    { reference: "2 Corinthiens 9:7", texte: "Que chacun donne comme il l'a résolu en son cœur, sans tristesse ni contrainte ; car Dieu aime celui qui donne avec joie.", livre: "2 Corinthiens", chapitre: 9, verset: 7 },
    { reference: "2 Corinthiens 12:9", texte: "Ma grâce te suffit, car ma puissance s'accomplit dans la faiblesse.", livre: "2 Corinthiens", chapitre: 12, verset: 9 },
  ],
  galates: [
    { reference: "Galates 2:20", texte: "J'ai été crucifié avec Christ ; et si je vis, ce n'est plus moi qui vis, c'est Christ qui vit en moi.", livre: "Galates", chapitre: 2, verset: 20 },
    { reference: "Galates 5:22-23", texte: "Mais le fruit de l'Esprit, c'est l'amour, la joie, la paix, la patience, la bonté, la bénignité, la fidélité, la douceur, la tempérance.", livre: "Galates", chapitre: 5, verset: 22 },
    { reference: "Galates 6:7", texte: "Ne vous y trompez pas : on ne se moque pas de Dieu. Ce qu'un homme aura semé, il le moissonnera aussi.", livre: "Galates", chapitre: 6, verset: 7 },
  ],
  ephesiens: [
    { reference: "Éphésiens 2:8-9", texte: "Car c'est par la grâce que vous êtes sauvés, par le moyen de la foi. Et cela ne vient pas de vous, c'est le don de Dieu. Ce n'est point par les œuvres, afin que personne ne se glorifie.", livre: "Éphésiens", chapitre: 2, verset: 8 },
    { reference: "Éphésiens 3:20", texte: "Or, à celui qui peut faire, par la puissance qui agit en nous, infiniment au-delà de tout ce que nous demandons ou pensons.", livre: "Éphésiens", chapitre: 3, verset: 20 },
    { reference: "Éphésiens 5:25", texte: "Maris, aimez vos femmes, comme Christ a aimé l'Église, et s'est livré lui-même pour elle.", livre: "Éphésiens", chapitre: 5, verset: 25 },
    { reference: "Éphésiens 6:10-11", texte: "Revêtez-vous de toutes les armes de Dieu, afin de pouvoir tenir ferme contre les ruses du diable.", livre: "Éphésiens", chapitre: 6, verset: 10 },
  ],
  philippiens: [
    { reference: "Philippiens 1:6", texte: "Je suis persuadé que celui qui a commencé en vous cette bonne œuvre la rendra parfaite pour le jour de Jésus-Christ.", livre: "Philippiens", chapitre: 1, verset: 6 },
    { reference: "Philippiens 4:6-7", texte: "Ne vous inquiétez de rien ; mais en toute chose faites connaître vos besoins à Dieu par des prières et des supplications, avec des actions de grâces. Et la paix de Dieu, qui surpasse toute intelligence, gardera vos cœurs et vos pensées en Jésus-Christ.", livre: "Philippiens", chapitre: 4, verset: 6 },
    { reference: "Philippiens 4:13", texte: "Je puis tout par celui qui me fortifie.", livre: "Philippiens", chapitre: 4, verset: 13 },
    { reference: "Philippiens 4:19", texte: "Et mon Dieu pourvoira à tous vos besoins selon sa richesse, avec gloire, en Jésus-Christ.", livre: "Philippiens", chapitre: 4, verset: 19 },
  ],
  hebreux: [
    { reference: "Hébreux 4:12", texte: "Car la parole de Dieu est vivante et efficace, plus tranchante qu'une épée quelconque à deux tranchants.", livre: "Hébreux", chapitre: 4, verset: 12 },
    { reference: "Hébreux 4:16", texte: "Approchons-nous donc avec assurance du trône de la grâce, afin d'obtenir miséricorde et de trouver grâce, pour être secourus dans nos besoins.", livre: "Hébreux", chapitre: 4, verset: 16 },
    { reference: "Hébreux 11:1", texte: "Or la foi est une ferme assurance des choses qu'on espère, une démonstration de celles qu'on ne voit pas.", livre: "Hébreux", chapitre: 11, verset: 1 },
    { reference: "Hébreux 11:6", texte: "Or sans la foi il est impossible de lui être agréable ; car il faut que celui qui s'approche de Dieu croie que Dieu existe, et qu'il est le rémunérateur de ceux qui le cherchent.", livre: "Hébreux", chapitre: 11, verset: 6 },
    { reference: "Hébreux 12:2", texte: "Ayant les regards sur Jésus, le chef et le consommateur de la foi.", livre: "Hébreux", chapitre: 12, verset: 2 },
    { reference: "Hébreux 13:8", texte: "Jésus-Christ est le même hier, aujourd'hui, et éternellement.", livre: "Hébreux", chapitre: 13, verset: 8 },
  ],
  jacques: [
    { reference: "Jacques 1:2-4", texte: "Mes frères, regardez comme un sujet de joie complète les diverses épreuves auxquelles vous pouvez être exposés, sachant que l'épreuve de votre foi produit la patience.", livre: "Jacques", chapitre: 1, verset: 2 },
    { reference: "Jacques 1:5", texte: "Si quelqu'un d'entre vous manque de sagesse, qu'il la demande à Dieu, qui donne à tous simplement et sans reproche, et elle lui sera donnée.", livre: "Jacques", chapitre: 1, verset: 5 },
    { reference: "Jacques 4:7", texte: "Soumettez-vous donc à Dieu ; résistez au diable, et il fuira loin de vous.", livre: "Jacques", chapitre: 4, verset: 7 },
    { reference: "Jacques 5:16", texte: "Confessez donc vos péchés les uns aux autres, et priez les uns pour les autres, afin que vous soyez guéris. La prière fervente du juste a une grande efficacité.", livre: "Jacques", chapitre: 5, verset: 16 },
  ],
  pierre1: [
    { reference: "1 Pierre 5:7", texte: "Déchargez-vous sur lui de tous vos soucis, car lui-même prend soin de vous.", livre: "1 Pierre", chapitre: 5, verset: 7 },
    { reference: "1 Pierre 2:9", texte: "Vous, au contraire, vous êtes une race élue, un sacerdoce royal, une nation sainte.", livre: "1 Pierre", chapitre: 2, verset: 9 },
  ],
  jean1: [
    { reference: "1 Jean 1:9", texte: "Si nous confessons nos péchés, il est fidèle et juste pour nous les pardonner, et pour nous purifier de toute iniquité.", livre: "1 Jean", chapitre: 1, verset: 9 },
    { reference: "1 Jean 4:4", texte: "Vous, petits enfants, vous êtes de Dieu, et vous les avez vaincus, parce que celui qui est en vous est plus grand que celui qui est dans le monde.", livre: "1 Jean", chapitre: 4, verset: 4 },
    { reference: "1 Jean 4:8", texte: "Celui qui n'aime pas n'a pas connu Dieu, car Dieu est amour.", livre: "1 Jean", chapitre: 4, verset: 8 },
    { reference: "1 Jean 5:14", texte: "Nous avons auprès de lui cette assurance, que si nous demandons quelque chose selon sa volonté, il nous écoute.", livre: "1 Jean", chapitre: 5, verset: 14 },
  ],
  apocalypse: [
    { reference: "Apocalypse 3:20", texte: "Voici, je me tiens à la porte, et je frappe. Si quelqu'un entend ma voix et ouvre la porte, j'entrerai chez lui, je souperai avec lui, et lui avec moi.", livre: "Apocalypse", chapitre: 3, verset: 20 },
    { reference: "Apocalypse 21:4", texte: "Il essuiera toute larme de leurs yeux, et la mort ne sera plus, et il n'y aura plus ni deuil, ni cri, ni douleur.", livre: "Apocalypse", chapitre: 21, verset: 4 },
    { reference: "Apocalypse 22:13", texte: "Je suis l'alpha et l'oméga, le premier et le dernier, le commencement et la fin.", livre: "Apocalypse", chapitre: 22, verset: 13 },
  ],
  actes: [
    { reference: "Actes 1:8", texte: "Mais vous recevrez une puissance, le Saint-Esprit survenant sur vous, et vous serez mes témoins à Jérusalem, dans toute la Judée, dans la Samarie, et jusqu'aux extrémités de la terre.", livre: "Actes", chapitre: 1, verset: 8 },
    { reference: "Actes 2:38", texte: "Pierre leur dit : Repentez-vous, et que chacun de vous soit baptisé au nom de Jésus-Christ, pour le pardon de vos péchés ; et vous recevrez le don du Saint-Esprit.", livre: "Actes", chapitre: 2, verset: 38 },
    { reference: "Actes 4:12", texte: "Il n'y a de salut en aucun autre ; car il n'y a sous le ciel aucun autre nom qui ait été donné parmi les hommes, par lequel nous devions être sauvés.", livre: "Actes", chapitre: 4, verset: 12 },
    { reference: "Actes 16:31", texte: "Crois au Seigneur Jésus, et tu seras sauvé, toi et ta famille.", livre: "Actes", chapitre: 16, verset: 31 },
  ],
  timothee2: [
    { reference: "2 Timothée 1:7", texte: "Car ce n'est pas un esprit de timidité que Dieu nous a donné, mais un esprit de force, d'amour et de sagesse.", livre: "2 Timothée", chapitre: 1, verset: 7 },
    { reference: "2 Timothée 3:16-17", texte: "Toute Écriture est inspirée de Dieu, et utile pour enseigner, pour convaincre, pour corriger, pour instruire dans la justice.", livre: "2 Timothée", chapitre: 3, verset: 16 },
  ],
};

// Tous les versets dans un seul tableau pour la recherche
export function getAllVersets(): VersetBiblique[] {
  return Object.values(VERSETS_CLES).flat();
}

// Recherche par référence exacte (ex: "Jean 3:16")
export function chercherVerset(ref: string): VersetBiblique | undefined {
  const all = getAllVersets();
  const q = ref.toLowerCase().trim();
  return all.find((v) => v.reference.toLowerCase().includes(q));
}

// Recherche par mot-clé dans le texte des versets
export function chercherVersetsParMotCle(motCle: string, max = 5): VersetBiblique[] {
  const all = getAllVersets();
  const q = motCle.toLowerCase();
  return all.filter((v) =>
    v.texte.toLowerCase().includes(q) || v.reference.toLowerCase().includes(q)
  ).slice(0, max);
}
