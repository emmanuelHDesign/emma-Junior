// V3.1 — Moteur IA biblique complet pour Esaïe IA
// Utilise bible-db.ts (versets) + bible-themes.ts (thèmes détaillés)
// Recherche sémantique par mots-clés + réponses détaillées avec versets exacts

import { uid } from "./data";
import { findTheme } from "./bible-themes";
import { chercherVerset, chercherVersetsParMotCle, type VersetBiblique } from "./bible-db";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

// ============================================================
// MOTEUR DE RÉPONSE INTELLIGENT
// ============================================================

function buildVersetResponse(versets: VersetBiblique[]): string {
  if (versets.length === 0) return "";
  let response = `📖 **Voici ce que dit la Bible :**\n\n`;
  for (const v of versets) {
    response += `**${v.reference}** :\n"${v.texte}"\n\n`;
  }
  response += `📌 **${versets.length} verset${versets.length > 1 ? "s" : ""} trouvé${versets.length > 1 ? "s" : ""}** : ${versets.map((v) => v.reference).join(" · ")}\n\n`;
  response += `💡 **Pour aller plus loin :** Lisez le contexte complet de ce${versets.length > 1 ? "s" : ""} passage${versets.length > 1 ? "s" : ""} dans votre Bible. Méditez-le${versets.length > 1 ? "s" : ""} cette semaine.\n\n`;
  response += `🙏 *Seigneur, grave Ta Parole dans nos cœurs. Que chaque verset transforme notre vie. Au nom de Jésus, amen.*`;
  return response;
}

const BLOCKED_RESPONSE = `Je ne suis qualifié que pour les questions bibliques et spirituelles.

Pour ce type de sujet, je vous invite à contacter directement votre pasteur ou votre berger de cellule MDC.

📌 "Si quelqu'un d'entre vous manque de sagesse, qu'il la demande à Dieu" — Jacques 1:5

🙏 *Seigneur, donne-nous Ta sagesse divine pour chaque situation de notre vie. Amen.*`;

const DEFAULT_RESPONSE = `📖 C'est une question intéressante ! Bien que je n'aie pas de réponse pré-formatée exacte pour cette question, voici ce que la Bible enseigne de manière générale :

**"Toute Écriture est inspirée de Dieu, et utile pour enseigner, pour convaincre, pour corriger, pour instruire dans la justice."** — **2 Timothée 3:16**

La Parole de Dieu est notre guide suprême. Pour approfondir ce sujet :

1. **Lisez votre Bible** : "Ta parole est une lampe à mes pieds, et une lumière sur mon sentier" (Psaume 119:105)
2. **Priez pour la compréhension** : "Ouvre mes yeux, pour que je contemple les merveilles de ta loi !" (Psaume 119:18)
3. **Consultez votre berger** : Rejoignez une cellule MDC pour étudier la Parole ensemble
4. **Posez la question au pasteur** dimanche au culte à Bonapriso

📌 Versets : 2 Timothée 3:16-17 · Psaume 119:105 · Psaume 119:18

💡 **Essayez de me poser la question autrement**, ou demandez-moi un thème précis comme : foi, prière, dîme, mariage, guérison, Saint-Esprit, pardon, combat spirituel, etc.

🙏 *Seigneur, éclaire notre intelligence par Ton Esprit Saint pour que nous comprenions Ta Parole. Guide-nous dans toute la vérité. Au nom de Jésus, amen.*`;

function findBestResponse(question: string): string {
  const q = question.toLowerCase().trim();

  // 1. Chercher une référence exacte (ex: "Jean 3:16", "Psaume 23")
  const refMatch = q.match(/(\d?\s*[a-zéèêëàâîïôùûüç]+)\s+(\d+)[:\s.]?\s*(\d*)/i);
  if (refMatch) {
    const searchRef = refMatch[0].trim();
    const verset = chercherVerset(searchRef);
    if (verset) {
      return buildVersetResponse([verset]);
    }
    // Chercher par livre
    const versetsLivre = chercherVersetsParMotCle(searchRef, 8);
    if (versetsLivre.length > 0) {
      return buildVersetResponse(versetsLivre);
    }
  }

  // 2. Chercher un thème biblique (réponse détaillée)
  const theme = findTheme(question);
  if (theme) {
    return theme.build();
  }

  // 3. Chercher des mots-clés dans les versets
  const mots = q.split(/\s+/).filter((m) => m.length > 3);
  for (const mot of mots) {
    const versetsMotCle = chercherVersetsParMotCle(mot, 5);
    if (versetsMotCle.length > 0) {
      return buildVersetResponse(versetsMotCle);
    }
  }

  // 4. Réponse par défaut
  return DEFAULT_RESPONSE;
}

// ============================================================
// STREAMING DE RÉPONSE (caractère par caractère)
// ============================================================

export async function* streamAIResponse(
  question: string,
  _userId: string
): AsyncGenerator<string> {
  // Vérification sécurité
  const { isQuestionAutorisee } = await import("./ai-system-prompt");
  if (!isQuestionAutorisee(question)) {
    for (const char of BLOCKED_RESPONSE) {
      yield char;
      await new Promise((r) => setTimeout(r, 3));
    }
    return;
  }

  const response = findBestResponse(question);
  // Streaming par mots pour un rendu plus naturel et plus rapide sur 3G
  const words = response.split(/(\s+)/);
  for (const word of words) {
    yield word;
    await new Promise((r) => setTimeout(r, 15));
  }
}

// ============================================================
// HISTORIQUE DE CHAT
// ============================================================

const CHAT_KEY = "mdc_chat_history";

export function getChatHistory(userId: string): ChatMessage[] {
  try {
    const raw = localStorage.getItem(`${CHAT_KEY}_${userId}`);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveChatMessage(userId: string, message: ChatMessage): void {
  const history = getChatHistory(userId);
  history.push(message);
  const trimmed = history.slice(-100);
  localStorage.setItem(`${CHAT_KEY}_${userId}`, JSON.stringify(trimmed));
}

export function clearChatHistory(userId: string): void {
  localStorage.removeItem(`${CHAT_KEY}_${userId}`);
}

export function createMessage(role: "user" | "assistant", content: string): ChatMessage {
  return {
    id: uid("msg"),
    role,
    content,
    timestamp: new Date().toISOString(),
  };
}

// ============================================================
// LIMITES QUOTIDIENNES (50 messages/jour au lieu de 20)
// ============================================================

export function getRemainingMessages(userId: string): number {
  const key = `mdc_ai_limit_${userId}_${new Date().toISOString().slice(0, 10)}`;
  const count = parseInt(localStorage.getItem(key) || "0");
  return Math.max(0, 50 - count);
}

export function incrementMessageCount(userId: string): void {
  const key = `mdc_ai_limit_${userId}_${new Date().toISOString().slice(0, 10)}`;
  const count = parseInt(localStorage.getItem(key) || "0");
  localStorage.setItem(key, String(count + 1));
}
