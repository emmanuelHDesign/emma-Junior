// V2.1 — Cellules avec quartiers de Douala et bergers
export interface CelluleQuartier {
  id: string;
  quartier: string;
  nom: string;
  berger: string;
  phone: string;
  photo: string; // initiales
  adresse: string;
  jour: string;
  heure: string;
  couleur: string;
}

export const CELLULES_QUARTIERS: CelluleQuartier[] = [
  {
    id: "cq1",
    quartier: "Bonapriso",
    nom: "Cellule Bethléem",
    berger: "Pasteur Jean Mboua",
    phone: "+237658842522",
    photo: "JM",
    adresse: "Rue de l'Hôpital Général, Bonapriso",
    jour: "Mercredi",
    heure: "18h00",
    couleur: "#1E3A8A",
  },
  {
    id: "cq2",
    quartier: "Akwa",
    nom: "Cellule Béthanie",
    berger: "Sœur Marie Ekambi",
    phone: "+237677234567",
    photo: "ME",
    adresse: "Rue Joss, Akwa Centre",
    jour: "Jeudi",
    heure: "18h30",
    couleur: "#D4AF37",
  },
  {
    id: "cq3",
    quartier: "Bali",
    nom: "Cellule Emmanuel",
    berger: "Frère Simon Tagne",
    phone: "+237691456789",
    photo: "ST",
    adresse: "Carrefour Bali, près du marché",
    jour: "Mardi",
    heure: "18h00",
    couleur: "#10B981",
  },
  {
    id: "cq4",
    quartier: "Ndokoti",
    nom: "Cellule Horeb",
    berger: "Diacre Paul Nkeng",
    phone: "+237656789012",
    photo: "PN",
    adresse: "Face station Total Ndokoti",
    jour: "Mercredi",
    heure: "18h30",
    couleur: "#7C3AED",
  },
  {
    id: "cq5",
    quartier: "PK14 - Bonabéri",
    nom: "Cellule Silo",
    berger: "Sœur Ruth Fotso",
    phone: "+237655345678",
    photo: "RF",
    adresse: "Carrefour PK14, Bonabéri",
    jour: "Jeudi",
    heure: "18h00",
    couleur: "#F97316",
  },
  {
    id: "cq6",
    quartier: "Bonamoussadi",
    nom: "Cellule Béthel",
    berger: "Frère Joseph Tcheppo",
    phone: "+237691456789",
    photo: "JT",
    adresse: "Bonamoussadi, Rue 2132",
    jour: "Mercredi",
    heure: "18h00",
    couleur: "#EF4444",
  },
];
