// V2.1 — Store global Zustand (Mode Culte, Push, UI globale)
import { create } from "zustand";
import { persist } from "zustand/middleware";

interface AppStore {
  // Mode Culte
  modeCulte: boolean;
  toggleModeCulte: () => void;
  // Push
  pushEnabled: boolean;
  setPushEnabled: (v: boolean) => void;
  // Version
  version: string;
}

export const useAppStore = create<AppStore>()(
  persist(
    (set) => ({
      modeCulte: false,
      toggleModeCulte: () => set((s) => ({ modeCulte: !s.modeCulte })),
      pushEnabled: false,
      setPushEnabled: (v: boolean) => set({ pushEnabled: v }),
      version: "2.1.0",
    }),
    { name: "mdc-app-store" }
  )
);
