// V2.1 — Types et données pour Dîme Mobile Money
import { loadDB, saveDB, uid, logAudit } from "./data";

export type TypeDon = "Dîme" | "Offrande" | "Action de grâce";
export type ReseauMomo = "MTN Mobile Money" | "Orange Money";
export type StatutPaiement = "en_attente" | "succès" | "échec";

export interface DonMobileMoney {
  id: string;
  userId: string;
  membreNom: string;
  type: TypeDon;
  montant: number;
  reseau: ReseauMomo;
  telephone: string;
  reference: string;
  statut: StatutPaiement;
  date: string;
  recuGenere: boolean;
}

const DONS_KEY = "mdc_dons_momo";

export function loadDons(): DonMobileMoney[] {
  try {
    const raw = localStorage.getItem(DONS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveDons(dons: DonMobileMoney[]): void {
  localStorage.setItem(DONS_KEY, JSON.stringify(dons));
}

export function enregistrerDon(don: Omit<DonMobileMoney, "id" | "reference" | "date" | "statut" | "recuGenere">): DonMobileMoney {
  const dons = loadDons();
  const nouveau: DonMobileMoney = {
    ...don,
    id: uid("don"),
    reference: `MDC-${Date.now().toString(36).toUpperCase()}`,
    date: new Date().toISOString(),
    statut: "succès",
    recuGenere: false,
  };
  dons.unshift(nouveau);
  saveDons(dons);

  // Log audit dans la DB principale
  const db = loadDB();
  logAudit(db, don.userId, "PAIEMENT_MOMO", "FINANCE", `${don.type} ${don.montant} FCFA via ${don.reseau} — ${don.membreNom}`);
  db.notifications.unshift({
    id: uid("n"),
    userId: don.userId,
    type: "success",
    titre: `${don.type} enregistrée`,
    message: `Merci pour votre ${don.type.toLowerCase()} de ${don.montant.toLocaleString("fr-FR")} FCFA. Réf: ${nouveau.reference}`,
    date: new Date().toISOString(),
    lu: false,
    lien: "/dime-mobile",
  });
  saveDB(db);

  return nouveau;
}
