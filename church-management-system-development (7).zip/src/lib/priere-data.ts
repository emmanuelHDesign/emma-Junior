// V2.2 — Données carnet de prière chiffré côté client
import { encrypt, decrypt } from "./crypto";
import { uid } from "./data";

export interface PriereEntry {
  id: string;
  userId: string;
  contenuEncrypte: string;
  date: string;
}

const PRIERE_KEY = "mdc_prieres";

export function loadPrieres(): PriereEntry[] {
  try {
    const raw = localStorage.getItem(PRIERE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function savePrieres(prieres: PriereEntry[]): void {
  localStorage.setItem(PRIERE_KEY, JSON.stringify(prieres));
}

export function getMesPrieres(userId: string): { id: string; contenu: string; date: string }[] {
  const all = loadPrieres();
  return all
    .filter((p) => p.userId === userId)
    .map((p) => ({
      id: p.id,
      contenu: decrypt(p.contenuEncrypte, userId),
      date: p.date,
    }))
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
}

export function savePriere(userId: string, contenu: string, existingId?: string): void {
  const all = loadPrieres();
  const encrypted = encrypt(contenu, userId);

  if (existingId) {
    const idx = all.findIndex((p) => p.id === existingId && p.userId === userId);
    if (idx >= 0) {
      all[idx].contenuEncrypte = encrypted;
      all[idx].date = new Date().toISOString();
    }
  } else {
    all.unshift({
      id: uid("pr"),
      userId,
      contenuEncrypte: encrypted,
      date: new Date().toISOString(),
    });
  }
  savePrieres(all);
}

export function deletePriere(userId: string, priereId: string): void {
  const all = loadPrieres();
  savePrieres(all.filter((p) => !(p.id === priereId && p.userId === userId)));
}
