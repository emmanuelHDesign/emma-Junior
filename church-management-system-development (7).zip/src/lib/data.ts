// Données et types métier MDC
// Persistance localStorage pour simuler l'API FastAPI

export type Role = "ADMIN" | "PASTEUR" | "SECRETAIRE" | "CHEF_CELLULE" | "MEMBRE";

export type StatutSpirituel = "Nouveau converti" | "Baptisé" | "Engagé" | "Archivé";

export interface Membre {
  id: string;
  nom: string;
  prenom: string;
  telephone: string;
  email?: string;
  photo?: string; // emoji ou initiales
  statut: StatutSpirituel;
  departementId?: string;
  celluleId?: string;
  dateIntegration: string; // ISO
  dateNaissance?: string;
  adresse?: string;
  consentementPhoto: boolean;
  consentementSMS: boolean;
  archived: boolean;
}

export interface Cellule {
  id: string;
  nom: string;
  chefId: string;
  adresse: string;
  jourRencontre: string;
  heureRencontre: string;
  zone: string;
}

export interface Departement {
  id: string;
  nom: string;
  responsableId?: string;
  description: string;
  couleur: string;
}

export interface Presence {
  id: string;
  membreId: string;
  type: "Dimanche" | "Étude biblique" | "Prière";
  date: string; // ISO date only
  culteId: string;
  heureArrivee?: string; // ISO time HH:MM:SS
  methode?: "manuelle" | "qr_code" | "self_scan";
}

export interface Culte {
  id: string;
  date: string;
  type: "Dimanche" | "Étude biblique" | "Prière";
  predicateur?: string;
}

export interface Dime {
  id: string;
  membreId: string;
  montant: number;
  type: "Dîme" | "Offrande" | "Action de grâce" | "Offrande spéciale";
  date: string;
  mode: "Cash" | "MTN Mobile Money" | "Orange Money";
  reference?: string;
  enregistrePar: string; // userId
}

export interface Evenement {
  id: string;
  nom: string;
  type: "Camp" | "Séminaire" | "Mariage" | "Conférence" | "Retraite";
  dateDebut: string;
  dateFin: string;
  lieu: string;
  budget: number;
  participants: string[]; // membreIds
  description: string;
}

export interface Message {
  id: string;
  canal: "SMS" | "WhatsApp";
  cible: string; // "Tous" | départementId | celluleId
  contenu: string;
  dateEnvoi: string;
  destinataires: number;
  statut: "Envoyé" | "En attente" | "Échec";
}

export interface AuditLog {
  id: string;
  userId: string;
  action: string;
  module: string;
  details: string;
  date: string;
}

export interface User {
  id: string;
  nom: string;
  role: Role;
  email: string;
  password: string; // V2 : mot de passe (hashé en prod)
  telephone?: string;
  deuxFacteurs: boolean;
  avatar?: string; // initiales ou URL
  photoUrl?: string; // base64 data URL de la photo de profil
  coverUrl?: string; // base64 data URL de la photo de couverture
  dateCreation: string;
  derniereConnexion?: string;
  actif: boolean;
  membreId?: string; // lien vers profil membre
}

export interface LoginHistory {
  id: string;
  userId: string;
  date: string;
  ip: string;
  device: string;
  success: boolean;
}

export interface Notification {
  id: string;
  userId?: string; // si null = pour tous
  type: "info" | "success" | "warning" | "alert" | "rappel";
  titre: string;
  message: string;
  date: string;
  lu: boolean;
  lien?: string;
}

// ============ SEED DATA ============

const SEED_USERS: User[] = [
  { id: "u1", nom: "Pasteur Emmanuel Biaya", role: "PASTEUR", email: "pasteur@mdc.cm", password: "demo123", telephone: "+237 699 00 00 01", deuxFacteurs: true, dateCreation: "2024-01-15", actif: true, membreId: undefined },
  { id: "u2", nom: "Admin Système", role: "ADMIN", email: "admin@mdc.cm", password: "demo123", telephone: "+237 699 00 00 02", deuxFacteurs: true, dateCreation: "2024-01-15", actif: true },
  { id: "u3", nom: "Sœur Esther Mbongo", role: "SECRETAIRE", email: "secretaire@mdc.cm", password: "demo123", telephone: "+237 699 00 00 03", deuxFacteurs: false, dateCreation: "2024-02-01", actif: true, membreId: "m3" },
  { id: "u4", nom: "Frère Joseph Tcheppo", role: "CHEF_CELLULE", email: "chef1@mdc.cm", password: "demo123", telephone: "+237 699 00 00 04", deuxFacteurs: false, dateCreation: "2024-03-10", actif: true, membreId: "m4" },
  { id: "u5", nom: "Frère Paul Nkeng", role: "MEMBRE", email: "membre@mdc.cm", password: "demo123", telephone: "+237 699 00 00 05", deuxFacteurs: false, dateCreation: "2024-05-20", actif: true, membreId: "m1" },
];

const SEED_DEPARTEMENTS: Departement[] = [
  { id: "d1", nom: "Louange", responsableId: "m3", description: "Ministère de louange et adoration", couleur: "#1E3A8A" },
  { id: "d2", nom: "Protocole", responsableId: "m4", description: "Accueil et organisation des cultes", couleur: "#D4AF37" },
  { id: "d3", nom: "Intercession", responsableId: "m5", description: "Cellule de prière et intercession", couleur: "#7C3AED" },
  { id: "d4", nom: "Enfants", responsableId: "m6", description: "École du dimanche", couleur: "#10B981" },
];

const SEED_CELLULES: Cellule[] = [
  { id: "c1", nom: "Cellule Béthel", chefId: "m4", adresse: "Bonamoussadi, Rue 2132", jourRencontre: "Mercredi", heureRencontre: "18:00", zone: "Bonamoussadi" },
  { id: "c2", nom: "Cellule Eben-Ezer", chefId: "m7", adresse: "Akwa, Avenue de Gaulle", jourRencontre: "Jeudi", heureRencontre: "18:30", zone: "Akwa" },
  { id: "c3", nom: "Cellule Shalom", chefId: "m8", adresse: "New-Bell, Cité SIC", jourRencontre: "Mardi", heureRencontre: "18:00", zone: "New-Bell" },
];

const SEED_MEMBRES: Membre[] = [
  { id: "m1", nom: "Ndongo", prenom: "Grace", telephone: "+237 699 12 34 56", email: "grace.ndongo@mail.cm", statut: "Engagé", departementId: "d1", celluleId: "c1", dateIntegration: "2022-03-15", dateNaissance: "1992-07-22", adresse: "Bonamoussadi", consentementPhoto: true, consentementSMS: true, archived: false },
  { id: "m2", nom: "Tchinda", prenom: "Samuel", telephone: "+237 677 23 45 67", statut: "Baptisé", departementId: "d2", celluleId: "c1", dateIntegration: "2023-01-10", consentementPhoto: true, consentementSMS: true, archived: false },
  { id: "m3", nom: "Fotso", prenom: "Ruth", telephone: "+237 655 34 56 78", statut: "Engagé", departementId: "d1", celluleId: "c2", dateIntegration: "2020-09-05", consentementPhoto: true, consentementSMS: true, archived: false },
  { id: "m4", nom: "Tcheppo", prenom: "Joseph", telephone: "+237 691 45 67 89", statut: "Engagé", departementId: "d2", celluleId: "c1", dateIntegration: "2019-05-20", consentementPhoto: true, consentementSMS: true, archived: false },
  { id: "m5", nom: "Mbarga", prenom: "Deborah", telephone: "+237 678 56 78 90", statut: "Engagé", departementId: "d3", celluleId: "c2", dateIntegration: "2021-11-14", consentementPhoto: true, consentementSMS: true, archived: false },
  { id: "m6", nom: "Eyinga", prenom: "Rachel", telephone: "+237 694 67 89 01", statut: "Baptisé", departementId: "d4", celluleId: "c3", dateIntegration: "2022-08-30", consentementPhoto: true, consentementSMS: true, archived: false },
  { id: "m7", nom: "Kamga", prenom: "David", telephone: "+237 656 78 90 12", statut: "Engagé", celluleId: "c2", dateIntegration: "2020-02-18", consentementPhoto: true, consentementSMS: true, archived: false },
  { id: "m8", nom: "Ngo Nyemb", prenom: "Esther", telephone: "+237 693 89 01 23", statut: "Engagé", departementId: "d3", celluleId: "c3", dateIntegration: "2021-04-25", consentementPhoto: true, consentementSMS: true, archived: false },
  { id: "m9", nom: "Tabi", prenom: "Jonas", telephone: "+237 670 90 12 34", statut: "Nouveau converti", celluleId: "c1", dateIntegration: "2025-09-14", consentementPhoto: false, consentementSMS: true, archived: false },
  { id: "m10", nom: "Mboua", prenom: "Prisca", telephone: "+237 695 01 23 45", statut: "Nouveau converti", celluleId: "c3", dateIntegration: "2025-10-02", consentementPhoto: true, consentementSMS: true, archived: false },
];

const today = new Date();
const dim = new Date(today);
dim.setDate(today.getDate() - today.getDay());

const SEED_CULTES: Culte[] = [
  { id: "cu1", date: dim.toISOString().slice(0, 10), type: "Dimanche", predicateur: "Pasteur Emmanuel Biaya" },
];

const SEED_PRESENCES: Presence[] = [
  { id: "p1", membreId: "m1", type: "Dimanche", date: dim.toISOString().slice(0, 10), culteId: "cu1" },
  { id: "p2", membreId: "m3", type: "Dimanche", date: dim.toISOString().slice(0, 10), culteId: "cu1" },
  { id: "p3", membreId: "m4", type: "Dimanche", date: dim.toISOString().slice(0, 10), culteId: "cu1" },
  { id: "p4", membreId: "m5", type: "Dimanche", date: dim.toISOString().slice(0, 10), culteId: "cu1" },
  { id: "p5", membreId: "m7", type: "Dimanche", date: dim.toISOString().slice(0, 10), culteId: "cu1" },
];

const SEED_DIMES: Dime[] = [
  { id: "dm1", membreId: "m1", montant: 25000, type: "Dîme", date: dim.toISOString().slice(0, 10), mode: "Cash", enregistrePar: "u3" },
  { id: "dm2", membreId: "m3", montant: 50000, type: "Dîme", date: dim.toISOString().slice(0, 10), mode: "MTN Mobile Money", reference: "MM-2025-10-001", enregistrePar: "u3" },
  { id: "dm3", membreId: "m4", montant: 15000, type: "Offrande", date: dim.toISOString().slice(0, 10), mode: "Cash", enregistrePar: "u3" },
  { id: "dm4", membreId: "m5", montant: 30000, type: "Dîme", date: dim.toISOString().slice(0, 10), mode: "Orange Money", reference: "OM-2025-10-023", enregistrePar: "u3" },
  { id: "dm5", membreId: "m7", montant: 10000, type: "Action de grâce", date: dim.toISOString().slice(0, 10), mode: "Cash", enregistrePar: "u3" },
  { id: "dm6", membreId: "m2", montant: 20000, type: "Dîme", date: dim.toISOString().slice(0, 10), mode: "Cash", enregistrePar: "u3" },
];

const SEED_EVENTS: Evenement[] = [
  { id: "e1", nom: "Camp annuel Jeunesse 2025", type: "Camp", dateDebut: "2025-12-20", dateFin: "2025-12-27", lieu: "Centre de retraite Kribi", budget: 2500000, participants: ["m1", "m2", "m3", "m9"], description: "Thème : L'année de la grâce du Seigneur - Ésaïe 61:1-3" },
  { id: "e2", nom: "Séminaire couples", type: "Séminaire", dateDebut: "2025-11-15", dateFin: "2025-11-15", lieu: "Temple MDC Douala", budget: 500000, participants: ["m4", "m5"], description: "Enseignement sur le mariage chrétien" },
];

const SEED_MESSAGES: Message[] = [
  { id: "msg1", canal: "SMS", cible: "Tous", contenu: "Culte ce Dimanche à 8h. Venez nombreux ! - MDC", dateEnvoi: new Date().toISOString(), destinataires: 487, statut: "Envoyé" },
  { id: "msg2", canal: "WhatsApp", cible: "d1", contenu: "Répétition louange samedi 15h. Merci de confirmer.", dateEnvoi: new Date().toISOString(), destinataires: 34, statut: "Envoyé" },
];

// ============ STORAGE ============

export interface DB {
  users: User[];
  membres: Membre[];
  cellules: Cellule[];
  departements: Departement[];
  cultes: Culte[];
  presences: Presence[];
  dimes: Dime[];
  evenements: Evenement[];
  messages: Message[];
  audit: AuditLog[];
  loginHistory: LoginHistory[];
  notifications: Notification[];
}

const KEY = "mdc_db_v2"; // V2 : nouvelle clé pour migration

const SEED_NOTIFICATIONS: Notification[] = [
  { id: "n1", type: "rappel", titre: "Culte ce dimanche", message: "N'oubliez pas le culte dominical à 8h au temple MDC.", date: new Date().toISOString(), lu: false, lien: "/presence" },
  { id: "n2", type: "success", titre: "Nouveau membre", message: "Prisca Mboua vient de rejoindre MDC. Soyez bénie !", date: new Date(Date.now() - 86400000).toISOString(), lu: false, lien: "/membres" },
  { id: "n3", type: "info", titre: "Mise à jour V2", message: "L'application MDC est désormais en version 2.0 avec de nouvelles fonctionnalités !", date: new Date(Date.now() - 172800000).toISOString(), lu: true },
];

function seed(): DB {
  return {
    users: SEED_USERS,
    membres: SEED_MEMBRES,
    cellules: SEED_CELLULES,
    departements: SEED_DEPARTEMENTS,
    cultes: SEED_CULTES,
    presences: SEED_PRESENCES,
    dimes: SEED_DIMES,
    evenements: SEED_EVENTS,
    messages: SEED_MESSAGES,
    audit: [],
    loginHistory: [],
    notifications: SEED_NOTIFICATIONS,
  };
}

export function loadDB(): DB {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) {
      const s = seed();
      localStorage.setItem(KEY, JSON.stringify(s));
      return s;
    }
    const parsed = JSON.parse(raw) as DB;
    // Migration : assurer la rétro-compatibilité avec V1
    if (!parsed.loginHistory) parsed.loginHistory = [];
    if (!parsed.notifications) parsed.notifications = SEED_NOTIFICATIONS;
    return parsed;
  } catch {
    return seed();
  }
}

export function saveDB(db: DB): void {
  localStorage.setItem(KEY, JSON.stringify(db));
}

export function resetDB(): DB {
  const s = seed();
  localStorage.setItem(KEY, JSON.stringify(s));
  return s;
}

export function uid(prefix = "id"): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

export function logAudit(db: DB, userId: string, action: string, module: string, details: string): void {
  db.audit.unshift({
    id: uid("log"),
    userId, action, module, details,
    date: new Date().toISOString(),
  });
  if (db.audit.length > 500) db.audit.length = 500;
}
