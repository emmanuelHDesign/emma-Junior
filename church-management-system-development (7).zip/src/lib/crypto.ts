// V2.2 — Chiffrement côté client pour le carnet de prière
// AES-256 via crypto-js. La clé ne quitte jamais le navigateur.
import CryptoJS from "crypto-js";

const APP_SECRET = "mdc-eglise-esaie61-2025";

function deriveKey(userId: string): string {
  return CryptoJS.SHA256(`${userId}:${APP_SECRET}`).toString();
}

export function encrypt(plaintext: string, userId: string): string {
  const key = deriveKey(userId);
  return CryptoJS.AES.encrypt(plaintext, key).toString();
}

export function decrypt(ciphertext: string, userId: string): string {
  const key = deriveKey(userId);
  const bytes = CryptoJS.AES.decrypt(ciphertext, key);
  return bytes.toString(CryptoJS.enc.Utf8);
}
