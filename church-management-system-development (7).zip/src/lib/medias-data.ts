// V2.2 — Données des médias (prédications audio, vidéo, PDF)
import { uid } from "./data";

export interface Media {
  id: string;
  titre: string;
  pasteur: string;
  dateCulte: string;
  type: "audio" | "video" | "pdf";
  url: string;
  coverUrl?: string;
  duree?: string; // ex: "45:23"
  taille?: string; // ex: "12 Mo"
}

const SEED_MEDIAS: Media[] = [
  { id: "med1", titre: "L'onction qui brise les jougs", pasteur: "Pasteur Emmanuel Biaya", dateCulte: "2025-10-12", type: "audio", url: "#", duree: "52:18", taille: "24 Mo" },
  { id: "med2", titre: "La puissance de la prière", pasteur: "Pasteur Emmanuel Biaya", dateCulte: "2025-10-05", type: "audio", url: "#", duree: "48:05", taille: "22 Mo" },
  { id: "med3", titre: "Marcher dans la foi", pasteur: "Évangéliste David Kamga", dateCulte: "2025-09-28", type: "audio", url: "#", duree: "41:32", taille: "19 Mo" },
  { id: "med4", titre: "La délivrance totale", pasteur: "Pasteur Emmanuel Biaya", dateCulte: "2025-09-21", type: "video", url: "#", duree: "1:12:45", taille: "180 Mo" },
  { id: "med5", titre: "Notes : L'onction qui brise les jougs", pasteur: "Pasteur Emmanuel Biaya", dateCulte: "2025-10-12", type: "pdf", url: "#", taille: "2 Mo" },
  { id: "med6", titre: "Notes : La puissance de la prière", pasteur: "Pasteur Emmanuel Biaya", dateCulte: "2025-10-05", type: "pdf", url: "#", taille: "1.5 Mo" },
  { id: "med7", titre: "Ésaïe 61 — L'année de grâce", pasteur: "Pasteur Emmanuel Biaya", dateCulte: "2025-01-07", type: "audio", url: "#", duree: "55:10", taille: "26 Mo" },
  { id: "med8", titre: "Le combat spirituel", pasteur: "Pasteur Emmanuel Biaya", dateCulte: "2025-08-17", type: "video", url: "#", duree: "1:05:20", taille: "150 Mo" },
];

const MEDIAS_KEY = "mdc_medias";

export function loadMedias(): Media[] {
  try {
    const raw = localStorage.getItem(MEDIAS_KEY);
    if (!raw) {
      localStorage.setItem(MEDIAS_KEY, JSON.stringify(SEED_MEDIAS));
      return SEED_MEDIAS;
    }
    return JSON.parse(raw);
  } catch {
    return SEED_MEDIAS;
  }
}

export function saveMedias(medias: Media[]): void {
  localStorage.setItem(MEDIAS_KEY, JSON.stringify(medias));
}

export function addMedia(media: Omit<Media, "id">): Media {
  const medias = loadMedias();
  const nouveau: Media = { ...media, id: uid("med") };
  medias.unshift(nouveau);
  saveMedias(medias);
  return nouveau;
}
